<?php
$server="localhost";
$user="u178459083_chekmate";
$password="U178459083_chekmate";
//$user="root";
//$password="";
$dbname="u178459083_chekmate";
$conn=new mysqli($server, $user, $password, $dbname);
if($conn->connect_error){
	die("Connection Failed: ".$conn->connect_error);
}
if(!$conn){
die("connection Failed:" .mysqli_connect_error());
}




?>