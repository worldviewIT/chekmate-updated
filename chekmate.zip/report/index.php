<?php
ob_start();
session_start();
if(!isset($_SESSION['uid']))
{
		header('location:../');
}
?>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="responsive.css">
<style>


@media only screen and (min-width: 470px){
    .tick-icons{
    width:70px !important;
    height:70px;
    }
}

@media only screen and (max-width: 468px){
    
    .tick-icons{
        width:38px !important;
        height:37px !important;
    }
}


</style>
	
</head>
<body  ><!-- oncontextmenu="return false;" -->
	<?php
	include "../conn.php";
	
	
		if(isset($_POST['accept_orderfirst']))
	{
		$sqd="Update tasks set status='Accepted' where taskid='".$_SESSION['tid']."'";
		if($conn->query($sqd))
		{
			$sa="Select mobile,id,arrears,email from user where id='".$_SESSION['uid']."'";
			$res2=$conn->query($sa);
			$rro=$res2->fetch_assoc();
		//	$amt=$rro['arrears']+=850;
		//	$ert="Update user set arrears='".$amt."' where id='".$_SESSION['uid']."'";
		//	$conn->query($ert);
			
					
				//SMS OTP
$msisdn = "923432435000";
$password = "thisisalongenoughpassword123!";

$url = "https://telenorcsms.com.pk:27677/corporate_sms2/api/auth.jsp?msisdn=".$msisdn."&password=".$password;
$xmlResponseString = file_get_contents($url);
$xmlResponse = simplexml_load_string($xmlResponseString);
$array=json_decode(json_encode((array)$xmlResponse),True);
//$sessionID = $xmlResponse->corpsms->data;
print_r($array['data']);
$tid=$_SESSION['tid'];
$msg="We're glad you're happy with your Chekmate report! The product will be delivered in 2-5 working days. We hope to help you find the right product, always.";
echo $mobile=$rro['mobile'];
$url2 = "https://telenorcsms.com.pk:27677/corporate_sms2/api/sendsms.jsp?session_id=".$array['data']."&mask=CHEKMATE&to=".$mobile."&text=".urlencode($msg);
$xmlResponseString2 = file_get_contents($url2);
$xmlResponse2 = simplexml_load_string($xmlResponseString2);

				
				// use wordwrap() if lines are longer than 70 characters
				$msg = wordwrap($msg,150);

				// send email
				$e=$rro['email'];
				
			$to = $e; 
$from = 'chekmate@worldviewit.com'; 
$fromName = "Chekmate"; 
 
$subject = "Chekmate Notification"; 
 
			$htmlContent = ' 
    <!DOCTYPE html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
@media screen and (max-width: 786px) {
  .body {
    margin-left: 0px !important;
  }
  .img01 
  {
  width: 270px !important;
  height: 53px !important;
  }
  .img02
  {
  width: 270px !important;
  height: 53px !important;
  }
  .para
  {
  font-size: 11px !important;
  margin-left: 12px !important;
  }
  
}
</style>
</head>

<body class="body" style="width: 765px;margin-left: 235px;margin-top: 120px;"> 
<div style="margin: 50px;">
<a href="https://chekmate.worldviewit.com">
<img class="img01" src="https://www.worldviewit.com/chekmate/mail/Header.png" width="712" height="140px" alt="Chekmate Logo" style="display:block" title="Logo"> </a>
<p class="para" style="margin-top: 42px;margin-left: 35px;font-size: 14px;">
 We are glad you are happy with your Chekmate report! The product will be delivered in 2-5 working days. We hope to help you find the right product, always.</div>
<footer>
<div style="margin: 50px;">
<img class="img02" src="https://www.worldviewit.com/chekmate/mail/Pattiwithtext.png" width="712" height="140px" alt="Chekmate Footer" style="display:block !important; width:712px; height:140px;" title="Email Footer">
</div>
</footer>
</body>
</html>'; 
			
	// Set content-type header for sending HTML email 
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
 // Additional headers 
$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 		
			
		// Send email 
if(mail($to, $subject, $htmlContent, $headers)){ 
   // echo 'Email has sent successfully.'; 
}else{ 
 //  echo 'Email sending failed.'; 
}		
				
				
			//mail($e,"ChekMate Order",$msg);
				
		header('location:../?order');	
			
			
		}
	}

	
	
	
	if(isset($_POST['accept_order']))
	{
		$sqd="Update tasks set status='Accepted' where taskid='".$_SESSION['tid']."'";
		if($conn->query($sqd))
		{
			$sa="Select mobile,id,arrears,email from user where id='".$_SESSION['uid']."'";
			$res2=$conn->query($sa);
			$rro=$res2->fetch_assoc();
			$amt=$rro['arrears']+=850;
			$ert="Update user set arrears='".$amt."' where id='".$_SESSION['uid']."'";
			$conn->query($ert);
			
					
				//SMS OTP
$msisdn = "923432435000";
$password = "thisisalongenoughpassword123!";

$url = "https://telenorcsms.com.pk:27677/corporate_sms2/api/auth.jsp?msisdn=".$msisdn."&password=".$password;
$xmlResponseString = file_get_contents($url);
$xmlResponse = simplexml_load_string($xmlResponseString);
$array=json_decode(json_encode((array)$xmlResponse),True);
//$sessionID = $xmlResponse->corpsms->data;
print_r($array['data']);
$tid=$_SESSION['tid'];
$msg="We're glad you're happy with your Chekmate report! The product will be delivered in 2-5 working days. We hope to help you find the right product, always.";
echo $mobile=$rro['mobile'];
$url2 = "https://telenorcsms.com.pk:27677/corporate_sms2/api/sendsms.jsp?session_id=".$array['data']."&mask=CHEKMATE&to=".$mobile."&text=".urlencode($msg);
$xmlResponseString2 = file_get_contents($url2);
$xmlResponse2 = simplexml_load_string($xmlResponseString2);

				
				// use wordwrap() if lines are longer than 70 characters
				$msg = wordwrap($msg,150);

				// send email
				$e=$rro['email'];
			
	
			$to = $e; 
$from = 'chekmate@worldviewit.com'; 
$fromName = "Chekmate"; 
 
$subject = "Chekmate Notification"; 
 
			$htmlContent = ' 
    <!DOCTYPE html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
@media screen and (max-width: 786px) {
  .body {
    margin-left: 0px !important;
  }
  .img01 
  {
  width: 270px !important;
  height: 53px !important;
  }
  .img02
  {
  width: 270px !important;
  height: 53px !important;
  }
  .para
  {
  font-size: 11px !important;
  margin-left: 12px !important;
  }
  
}
</style>
</head>

<body class="body" style="width: 765px;margin-left: 235px;margin-top: 120px;"> 
<div style="margin: 50px;">
<a href="https://chekmate.worldviewit.com">
<img class="img01" src="https://www.worldviewit.com/chekmate/mail/Header.png" width="712" height="140px" alt="Chekmate Logo" style="display:block" title="Logo"> </a>
<p class="para" style="margin-top: 42px;margin-left: 35px;font-size: 14px;">
 We are glad you are happy with your Chekmate report! The product will be delivered in 2-5 working days. We hope to help you find the right product, always.</div>
<footer>
<div style="margin: 50px;">
<img class="img02" src="https://www.worldviewit.com/chekmate/mail/Pattiwithtext.png" width="712" height="140px" alt="Chekmate Footer" style="display:block !important; width:712px; height:140px;" title="Email Footer">
</div>
</footer>
</body>
</html>'; 
			
	// Set content-type header for sending HTML email 
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
 // Additional headers 
$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 		
			
		// Send email 
if(mail($to, $subject, $htmlContent, $headers)){ 
   // echo 'Email has sent successfully.'; 
}else{ 
 //  echo 'Email sending failed.'; 
}		
						
			
			//	mail($e,"ChekMate Order",$msg);
				
		header('location:../?order');	
			
			
		}
	}
	
	
	if(isset($_POST['cancel_order2']))
	{
		$sqd="Update tasks set status='Cancelled' where taskid='".$_SESSION['tid']."'";
		if($conn->query($sqd))
		{
			$sa="Select mobile,id,arrears,email from user where id='".$_SESSION['uid']."'";
			$res2=$conn->query($sa);
			$rro=$res2->fetch_assoc();
			$amt=$rro['arrears']+=850;
			$ert="Update user set arrears='".$amt."' where id='".$_SESSION['uid']."'";
			$conn->query($ert);
			
					
				//SMS OTP
$msisdn = "923432435000";
$password = "thisisalongenoughpassword123!";

$url = "https://telenorcsms.com.pk:27677/corporate_sms2/api/auth.jsp?msisdn=".$msisdn."&password=".$password;
$xmlResponseString = file_get_contents($url);
$xmlResponse = simplexml_load_string($xmlResponseString);
$array=json_decode(json_encode((array)$xmlResponse),True);
//$sessionID = $xmlResponse->corpsms->data;
print_r($array['data']);
$tid=$_SESSION['tid'];
$msg="It's too bad you had to cancel the order. Chekmate looks forward to helping you find a better product next time.";
 $mobile=$rro['mobile'];
$url2 = "https://telenorcsms.com.pk:27677/corporate_sms2/api/sendsms.jsp?session_id=".$array['data']."&mask=CHEKMATE&to=".$mobile."&text=".urlencode($msg);
$xmlResponseString2 = file_get_contents($url2);
$xmlResponse2 = simplexml_load_string($xmlResponseString2);

				
				// use wordwrap() if lines are longer than 70 characters
				$msg = wordwrap($msg,150);

				// send email
				$e=$rro['email'];
	
			$to = $e; 
$from = 'chekmate@worldviewit.com'; 
$fromName = "Chekmate"; 
 
$subject = "Chekmate Notification"; 
 
			$htmlContent = ' 
    <!DOCTYPE html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
@media screen and (max-width: 786px) {
  .body {
    margin-left: 0px !important;
  }
  .img01 
  {
  width: 270px !important;
  height: 53px !important;
  }
  .img02
  {
  width: 270px !important;
  height: 53px !important;
  }
  .para
  {
  font-size: 11px !important;
  margin-left: 12px !important;
  }
  
}
</style>
</head>

<body class="body" style="width: 765px;margin-left: 235px;margin-top: 120px;"> 
<div style="margin: 50px;">
<a href="https://chekmate.worldviewit.com">
<img class="img01" src="https://www.worldviewit.com/chekmate/mail/Header.png" width="712" height="140px" alt="Chekmate Logo" style="display:block" title="Logo"> </a>
<p class="para" style="margin-top: 42px;margin-left: 35px;font-size: 14px;">
 It is too bad you had to cancel the order. Chekmate looks forward to helping you find a better product next time.</div>
<footer>
<div style="margin: 50px;">
<img class="img02" src="https://www.worldviewit.com/chekmate/mail/Pattiwithtext.png" width="712" height="140px" alt="Chekmate Footer" style="display:block !important; width:712px; height:140px;" title="Email Footer">
</div>
</footer>
</body>
</html>'; 
			
	// Set content-type header for sending HTML email 
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
 // Additional headers 
$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 		
			
		// Send email 
if(mail($to, $subject, $htmlContent, $headers)){ 
   // echo 'Email has sent successfully.'; 
}else{ 
 //  echo 'Email sending failed.'; 
}		
						
			
			
			
			//	mail($e,"ChekMate Order",$msg);
				
		header('location:../?order');	
			
			
		}
	}
	
	
	if(isset($_POST['cancel_orderfirst']))
	{
		$sqd="Update tasks set status='Cancelled' where taskid='".$_SESSION['tid']."'";
		if($conn->query($sqd))
		{
			$sa="Select mobile,id,arrears,email from user where id='".$_SESSION['uid']."'";
			$res2=$conn->query($sa);
			$rro=$res2->fetch_assoc();
			
					
				//SMS OTP
$msisdn = "923432435000";
$password = "thisisalongenoughpassword123!";

$url = "https://telenorcsms.com.pk:27677/corporate_sms2/api/auth.jsp?msisdn=".$msisdn."&password=".$password;
$xmlResponseString = file_get_contents($url);
$xmlResponse = simplexml_load_string($xmlResponseString);
$array=json_decode(json_encode((array)$xmlResponse),True);
//$sessionID = $xmlResponse->corpsms->data;
print_r($array['data']);
$tid=$_SESSION['tid'];
$msg="It's too bad you had to cancel the order. Chekmate looks forward to helping you find a better product next time.";
echo $mobile=$rro['mobile'];
$url2 = "https://telenorcsms.com.pk:27677/corporate_sms2/api/sendsms.jsp?session_id=".$array['data']."&mask=CHEKMATE&to=".$mobile."&text=".urlencode($msg);
$xmlResponseString2 = file_get_contents($url2);
$xmlResponse2 = simplexml_load_string($xmlResponseString2);

				
				// use wordwrap() if lines are longer than 70 characters
				$msg = wordwrap($msg,150);

				// send email
				$e=$rro['email'];
			$to = $e; 
$from = 'chekmate@worldviewit.com'; 
$fromName = "Chekmate"; 
 
$subject = "Chekmate Notification"; 
 
			$htmlContent = ' 
    <!DOCTYPE html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
@media screen and (max-width: 786px) {
  .body {
    margin-left: 0px !important;
  }
  .img01 
  {
  width: 270px !important;
  height: 53px !important;
  }
  .img02
  {
  width: 270px !important;
  height: 53px !important;
  }
  .para
  {
  font-size: 11px !important;
  margin-left: 12px !important;
  }
  
}
</style>
</head>

<body class="body" style="width: 765px;margin-left: 235px;margin-top: 120px;"> 
<div style="margin: 50px;">
<a href="https://chekmate.worldviewit.com">
<img class="img01" src="https://www.worldviewit.com/chekmate/mail/Header.png" width="712" height="140px" alt="Chekmate Logo" style="display:block" title="Logo"> </a>
<p class="para" style="margin-top: 42px;margin-left: 35px;font-size: 14px;">
 It is too bad you had to cancel the order. Chekmate looks forward to helping you find a better product next time.</div>
<footer>
<div style="margin: 50px;">
<img class="img02" src="https://www.worldviewit.com/chekmate/mail/Pattiwithtext.png" width="712" height="140px" alt="Chekmate Footer" style="display:block !important; width:712px; height:140px;" title="Email Footer">
</div>
</footer>
</body>
</html>'; 
			
	// Set content-type header for sending HTML email 
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
 // Additional headers 
$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 		
			
		// Send email 
if(mail($to, $subject, $htmlContent, $headers)){ 
   // echo 'Email has sent successfully.'; 
}else{ 
 //  echo 'Email sending failed.'; 
}		
				
				
				
				//mail($e,"ChekMate Order",$msg);
				
		header('location:../?order');	
			
			
		}
	}
	
	
	if(isset($_POST['cancel_order']))
	{
		$sqd="Update tasks set status='Cancelled' where taskid='".$_SESSION['tid']."'";
		if($conn->query($sqd))
		{
			$sa="Select mobile,id,email from user where id='".$_SESSION['uid']."'";
			$res2=$conn->query($sa);
			$rro=$res2->fetch_assoc();
			
					
				//SMS OTP
$msisdn = "923432435000";
$password = "thisisalongenoughpassword123!";

$url = "https://telenorcsms.com.pk:27677/corporate_sms2/api/auth.jsp?msisdn=".$msisdn."&password=".$password;
$xmlResponseString = file_get_contents($url);
$xmlResponse = simplexml_load_string($xmlResponseString);
$array=json_decode(json_encode((array)$xmlResponse),True);
//$sessionID = $xmlResponse->corpsms->data;
print_r($array['data']);
$tid=$_SESSION['tid'];
$msg="Your Order ID: $tid has been cancelled. Thanks for choosing chekmate.";
echo $mobile=$rro['mobile'];
$url2 = "https://telenorcsms.com.pk:27677/corporate_sms2/api/sendsms.jsp?session_id=".$array['data']."&mask=CHEKMATE&to=".$mobile."&text=".urlencode($msg);
$xmlResponseString2 = file_get_contents($url2);
$xmlResponse2 = simplexml_load_string($xmlResponseString2);

				

				// use wordwrap() if lines are longer than 70 characters
				$msg = wordwrap($msg,150);

				// send email
				$e=$rro['email'];
				
				$to = $e; 
$from = 'chekmate@worldviewit.com'; 
$fromName = "Chekmate"; 
 
$subject = "Chekmate Notification"; 
 
			$htmlContent = ' 
    <!DOCTYPE html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
@media screen and (max-width: 786px) {
  .body {
    margin-left: 0px !important;
  }
  .img01 
  {
  width: 270px !important;
  height: 53px !important;
  }
  .img02
  {
  width: 270px !important;
  height: 53px !important;
  }
  .para
  {
  font-size: 11px !important;
  margin-left: 12px !important;
  }
  
}
</style>
</head>

<body class="body" style="width: 765px;margin-left: 235px;margin-top: 120px;"> 
<div style="margin: 50px;">
<a href="https://chekmate.worldviewit.com">
<img class="img01" src="https://www.worldviewit.com/chekmate/mail/Header.png" width="712" height="140px" alt="Chekmate Logo" style="display:block" title="Logo"> </a>
<p class="para" style="margin-top: 42px;margin-left: 35px;font-size: 14px;">
 It is too bad you had to cancel the order. Chekmate looks forward to helping you find a better product next time./div>
<footer>
<div style="margin: 50px;">
<img class="img02" src="https://www.worldviewit.com/chekmate/mail/Pattiwithtext.png" width="712" height="140px" alt="Chekmate Footer" style="display:block !important; width:712px; height:140px;" title="Email Footer">
</div>
</footer>
</body>
</html>'; 
			
	// Set content-type header for sending HTML email 
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
 // Additional headers 
$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 		
			
		// Send email 
if(mail($to, $subject, $htmlContent, $headers)){ 
   // echo 'Email has sent successfully.'; 
}else{ 
 //  echo 'Email sending failed.'; 
}		
			
				
				
				//mail($e,"ChekMate Order",$msg);
				
				
		header('location:../?order');	
			
			
		}
	}
	$status="";
	$showmodel="";
			if(!isset($_SESSION['tid']))
			{
				$sas="Select * from tasks where taskid='".$_GET['task']."' and userid='".$_SESSION['uid']."'";
				$red=$conn->query($sas);
				if($red->num_rows>0)
				{
					
				$_SESSION['tid']=$_GET['task'];
				}else
				{
					header('../');
				}
			}else{
				//session exists
				$sas="Select * from tasks where taskid='".$_GET['task']."' and userid='".$_SESSION['uid']."'";
				$red=$conn->query($sas);
				if($red->num_rows>0)
				{	
				$_SESSION['tid']=$_GET['task'];
				}
			}
			$ordercount="0";
			$orderstatus="";
			$numbering='';
			$producttype='';
			$ordertype='';
			$taskdate='';
			$diagnosticstest='';
			$workingtest='';
			$cosmetictest='';
			$turn_on='';
			$fully_functional='';
			$repair_history='';
			$warrenty='';
			$battery_check='';
			$network_check='';
			$audio_check='';
			$display_check='';
			$gps_check='';
			$camera_check='';
			$automated_check='';
			$sensor_check='';
			$warrenty_charger='';
			$headphone_cover='';
			$productname='';
			$adds_on='';
			$working='';
			$diagnostic_network='';
			$diagnostic_automated='';
			$diagnostic_camera='';
			$diagnostic_audio='';
			$diagnostic_display='';
			$diagnostic_gps ='';
			$diagnostic_sensor ='';
			$diagnostic_battery ='';
			$rating='';
			$true_to_dimension="";
			$length="";
			$width="";
			$height="";
			$size="";
			$tag="";
			$colar="";
			$tts="";
			$waist="";
			$sizendimension="";
			$true_to_size="";
			$fheight="";
			$fweight="";
			$stamp='';
			$dt='';
			$user='';
			
		$sqly="Select userid from tasks where userid='".$_SESSION['uid']."'";
	$resu=$conn->query($sqly);
	if($resu->num_rows>0)
	{
		while($ty=$resu->fetch_assoc())
		{
			$ordercount++;
			$fuser="Select id,Name from user where id='".$ty['userid']."'";
			$re=$conn->query($fuser);
			if($re->num_rows>0)
			{
			$urow=$re->fetch_assoc();
			$user=$urow['Name'];
			}
		}
	}

date_default_timezone_set("Asia/Karachi");
	$sql="Select * from tasks where taskid='".$_SESSION['tid']."'";
	$result=$conn->query($sql);
	if($result->num_rows>0)
	{
		$row=$result->fetch_assoc();
		
	$dto=$row['submission_date'];

	$minutes_to_add = 720;

	$time = new DateTime($dto);
	$time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
	$stamp = $time->format('Y-m-d h:i:sa');
	$dt=date('Y-m-d h:i:sa');
	$dt=strtotime($dt);
		
		
		$orderstatus=$row['status'];
		$producttype=$row['product_type'];
		$productname=$row['product_name'];
		$taskdate=$row['taskdate'];
		$rating=$row['rating'];
		$status=$row['status'];
		$fd="Select * from report where taskid='".$_SESSION['tid']."'";
		$res=$conn->query($fd);
		if($res->num_rows>0)
		{
			while($rrow=$res->fetch_assoc())
			{
			
				
				if($rrow['property']=='FHeight')
					$fheight=$rrow['property_value'];
				
				if($rrow['property']=='FWeight')
					$fweight=$rrow['property_value'];
				
				if($rrow['property']=='Size')
					$size=$rrow['property_value'];
				
				if($rrow['property']=='Tag')
					$tag=$rrow['property_value'];
				
				if($rrow['property']=='Colar')
					$colar=$rrow['property_value'];
				
				if($rrow['property']=='Waist')
					$waist=$rrow['property_value'];
				
				if($rrow['property']=='Length')
					$length=$rrow['property_value'];
				
				if($rrow['property']=='Width')
					$width=$rrow['property_value'];
				
				if($rrow['property']=='Height')
					$height=$rrow['property_value'];
				
				if($rrow['property']=='True_To_Dimention')
					$true_to_dimension=$rrow['property_value'];
				
				if($true_to_dimension!="" || $height!="" || $width!="" || $length!="")
				{
					$sizendimension="yes";
				}
				if($true_to_size!="" || $fheight!="" || $fweight!="" || $colar!="")
				{
					$tts="yes";
				}
				
				
				if($rrow['property']=='True_To_Size')
					$true_to_size=$rrow['property_value'];
				
				if($rrow['property']=='Order Type')
					$ordertype=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostics Test')
					$diagnosticstest=$rrow['property_value'];
				
				if($rrow['property']=='Cosmetic Test')
					$cosmetictest=$rrow['property_value'];
				
				if($rrow['property']=='Working Conditions')
					$workingtest=$rrow['property_value'];
				
				if($rrow['property']=='Turn On')
					$turn_on=$rrow['property_value'];
				
				if($rrow['property']=='Fully Functional')
					$fully_functional=$rrow['property_value'];
				
				if($rrow['property']=='Repair History')
					$repair_history=$rrow['property_value'];
				
				if($rrow['property']=='Warrenty')
					$warrenty=$rrow['property_value'];
				
				if($rrow['property']=='Battery Check')
					$battery_check=$rrow['property_value'];
				
				if($rrow['property']=='Network Check')
					$network_check=$rrow['property_value'];
				
				if($rrow['property']=='Audio Check')
					$audio_check=$rrow['property_value'];
				
				if($rrow['property']=='Display Check')
					$display_check=$rrow['property_value'];
				
				if($rrow['property']=='Gps Check')
					$gps_check=$rrow['property_value'];
				
				if($rrow['property']=='Camera Check')
					$camera_check=$rrow['property_value'];
				
				if($rrow['property']=='Automated Check')
					$automated_check=$rrow['property_value'];
				
				if($rrow['property']=='Sensor Check')
					$sensor_check=$rrow['property_value'];
				
				if($rrow['property']=='Warrenty Charger')
					$warrenty_charger=$rrow['property_value'];
				
				if($rrow['property']=='Headphone Cover')
					$headphone_cover=$rrow['property_value'];
				if($rrow['property']=='ADD-ONs')
					$adds_on=$rrow['property_value'];	
				if($rrow['property']=='Working')
					$working=$rrow['property_value'];	
				
				if($rrow['property']=='Diagnostic Network')
					$diagnostic_network=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Audio')
					$diagnostic_audio=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Gps')
					$diagnostic_gps=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Display')
					$diagnostic_display=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Sensor')
					$diagnostic_sensor=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Battery')
					$diagnostic_battery=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Automatic')
					$diagnostic_automated=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Camera')
					$diagnostic_camera=$rrow['property_value'];
				
				
			}
			
			
		}
	}else{
		header('location:../index.php?order');
	}

			?>



	 <!-- Header -->
<div class="container-fluid">

<?php
$typo="";
if(strtotime($stamp)<$dt){
$typo="Invalid";
?>
	<center>
	<div class="invalid">
	</div>
	</center>
	<?php
}
elseif($status=="Cancelled")
{
?>
<center>
	<div class="cancel">
	</div>
	</center>

<?php
}
?>

<div class="row">
<div class="header">
	<div class="col-sm-6 col-md-8 col-lg-8 logo ">
	<img src="CHEKMATE LOGO FINAL 4JAN22-01.png" class="img-fluid">
	</div>
	
	
	
	<div class="col-sm-6 col-md-4 col-lg-4  text-center asesmnt-dtal">
	<h3 ><b>Assessment Details</b></h3>
	 <span><b> Customer: </b><?php  echo $user;?></span><br> 
	<span><b> ID No.</b> 00<?php echo $_SESSION['tid'];?></span><br>
	<span><b><?php echo $taskdate;?></b></span>
	</div>
		<hr style="margin:0px;">
	</div>





<div class="data col-sm-12 col-md-12 col-lg-12">
	<p style="line-height:0.5;"><b>Product Type:</b> <?php echo $producttype;?></p>
	<p style="line-height:0.5;"><b>Model:</b> <?php echo $productname;?></p>
	<p style="line-height:0.5;"><b>Condition:</b> <?php echo $ordertype;?></p>
	
<div class="img" >
	<center>
	<?php
	$rating=round($rating);
	$picto='';
	$msg="FIT TO SHIP";
	if($diagnosticstest>=3 || $workingtest>=3 || $cosmetictest>=3)	
	{
		$picto='sign.png';
		$saq="Update tasks set status='Unfit To Ship' where taskid='".$_SESSION['tid']."'";
		$conn->query($saq);
		$msg="NOT FIT TO SHIP";
		$showmodel="Unfit";
		if($rating==1)
			echo '<img src="1.png" height="400px" width="400px">';
		
		if($rating==2)
			echo '<img src="2.png" height="400px" width="400px">';
		
		if($rating==3)
			echo '<img src="3.png" height="400px" width="400px">';
		
		if($rating==4)
			echo '<img src="4.png" height="400px" width="400px">';
		
		if($rating==5)
			echo '<img src="5.png" height="400px" width="400px">';
		
		if($rating==6)
			echo '<img src="6.png" height="400px" width="400px">';
		
		if($rating==7)
			echo '<img src="7.png" height="400px" width="400px">';
		
		if($rating==8)
			echo '<img src="8.png" height="400px" width="400px">';
		
		if($rating==9)
			echo '<img src="9.png" height="400px" width="400px">';
		
		if($rating==10)
			echo '<img src="10.png" height="400px" width="400px">';
	}else{
if($rating>=0 && $rating<=3.5)
{
	$picto='tick-report.png';
	$saq="Update tasks set status='Unfit To Ship' where taskid='".$_SESSION['tid']."'";
		$conn->query($saq);
	
		if($rating==1)
		{
			echo '<img src="1.png" height="400px" width="400px">';
			$msg="NOT FIT TO SHIP";
		}
		if($rating==2)
		{
			echo '<img src="2.png" height="400px" width="400px">';
			$msg="NOT FIT TO SHIP";
		}
		if($rating==3)
		{
			echo '<img src="3.png" height="400px" width="400px">';
		$msg="NOT FIT TO SHIP";
		}
}elseif($rating>3.5 && $rating<=8.5)
{
	$picto='tick-report.png';
	if($rating==4)
			echo '<img src="s4.png" height="400px" width="400px">';
		
		if($rating==5)
			echo '<img src="s5.png" height="400px" width="400px">';
		
		if($rating==6)
			echo '<img src="s6.png" height="400px" width="400px">';
		
		if($rating==7)
			echo '<img src="s7.png" height="400px" width="400px">';
		
		if($rating==8)
			echo '<img src="s8.png" height="400px" width="400px">';
		
}
elseif($rating>8.5 && $rating<=10)
{
	$picto='tick-report.png';
		if($rating==9)
			echo '<img src="e9.png" height="400px" width="400px">';
		
		if($rating==10)
			echo '<img src="e10.png" height="400px" width="400px">';
}
	}
	?>
	
	
	</center><br>
	<center><img src="<?php echo $picto;?>" class="tick-icons" style="margin-top:-20px;"><b class="active-x"><?php echo $msg;?></b></center>
	
</div>
	
</div>
	<div class="col-sm-12 col-md-12 col-lg-12">
			<div class="des">
				<h3 style="line-height:0.9;font-weight:bold;">ASSESSMENT<br> DETAILS</h3>
			</div>
	</div>
</div>

<div class="container-fluid">	
	
	
	
			<?php
			if($cosmetictest!='')
			{
			?>
			<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 no-padd">
				<h3 class="heading bdr"><b>COSMETIC CONDITION</b></h3>
						<div class="spacer">
					<div class="spacer">
				<h4 class="heading lh">True to description?</h4>
					<p class="contnt"> <span <?php
					if($cosmetictest=='0'){
					?> class="active-x" <?php } ?> >Yes</span> | <span <?php
					if($cosmetictest>='3'){
					?> class="active-x" <?php } ?>>No</span> | <span <?php
					if($cosmetictest=='1' || $cosmetictest=='2'){
					?> class="active-x" <?php } ?>>Somewhat</span> </p>
				</div>	
				</div>	
		</div>
		<?php
			}
		?>
		
	
			<?php
			    $sqa="Select * from report where taskid='".$_SESSION['tid']."' and (property='Front-Picture' || 
				property='Back-Picture' || property='LS-Picture' || property='RS-Picture' ||
				property='TS-Picture' || property='BS-Picture')";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{
					?>
					
		<div class="b-img">
					<?php
					while($crow=$re->fetch_assoc())
					{
						?>
			<div class="col-sm-4 col-md-4 col-lg-4 col-xs-4">
				<img src="../report-pics/<?php echo $crow['property_value'];?>" height="200px" width="100%">
			
				</div>
						<?php
					}
					?>
					</div>
					<?php
				}
			?>
		
		

	<div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 no-padd bttts">
			
			<?php
			if($workingtest!='')
			{
			?>
			<h3 class="heading bdr"><b>WORKING CONDITION</b></h3>
			<div class="spacer">
			<h4 class="heading lh">True to description?</h4>
			<p class="contnt"> <span <?php
			if($workingtest=='0'){
			?> class="active-x" <?php } ?> > Yes </span> | <span <?php
			if($workingtest>='3'){
			?> class="active-x" <?php } ?>> No </span> | <span <?php
			if($workingtest=='1' || $workingtest=='2'){
			?> class="active-x" <?php } ?>> Somewhat </span> </p>
			</div>	
			<?php
			}
		
		if($turn_on!="")
		{	
	
			?>
			<div class="spacer">
				<h4 class="heading lh">Does it turn on?</h4>
				<p class="contnt"> <span  <?php
			if($turn_on=='Yes'){
			?> class="active-x" <?php } ?> >Yes</span> | <span <?php
			if($turn_on=='No'){
			?> class="active-x" <?php } ?> >No</span> </p>
			</div>
		<?php
		}
		if($fully_functional!="")
		{	
		?>
			<div class="spacer">
				<h4 class="heading lh">Fully functional and/or everything lights up correctly?</h4>
				<p class="contnt"> <span <?php
			if($fully_functional=='Yes'){
			?> class="active-x" <?php } ?>>Yes</span> | <span <?php
			if($fully_functional=='No'){
			?> class="active-x" <?php } ?>>No</span> </p>
			</div>
		<?php
		}
		if($repair_history!="")
		{
		?>			
			<div class="spacer">
				<h4 class="heading lh">Any repair history?</h4>
				<p class="contnt"> <span <?php
			if($repair_history=='Yes'){
			?> class="active-x" <?php } ?>>Yes</span> | <span <?php
			if($repair_history=='No'){
			?> class="active-x" <?php } ?>>No</span> </p>
			</div>
			
			<?php
		}
			if($warrenty!="")
		{
			?>
			<div class="spacer">
				<h4 class="heading lh">Comes with warranty?</h4>
				<p class="contnt"> <span <?php
			if($warrenty=='Yes'){
			?> class="active-x" <?php } ?>>Yes</span> | <span <?php
			if($warrenty=='No'){
			?> class="active-x" <?php } ?>>No</span> </p>
			</div>
		<?php
		}
		?>		
			<?php
			if($producttype=='Mobile Device' || $producttype=='Laptops & Computers')
				{	
			?>
		<h3 class="heading bdr"><b>DEEP DIAGNOSTICS</b></h3>
		<?php
		if($battery_check!="")
		{
		?>
		<div class="spacer">
		<h4 class="heading lh">Battery Check</h4>
			<p class="contnt"> <span <?php
			if($battery_check=='Yes'){
			?> class="active-x" <?php } ?>>Pass</span> | <span <?php
			if($battery_check=='No'){
			?> class="active-x" <?php } ?>>Fail</span>  </p>
		</div>	
		<?php
		}
		
		if($network_check!="")
		{
		?>
		<div class="spacer">
		<h4 class="heading lh">Network Check</h4>
			<p class="contnt"> <span <?php
			if($network_check=='Yes'){
			?> class="active-x" <?php } ?>>Pass</span> | <span <?php
			if($network_check=='No'){
			?> class="active-x" <?php } ?>>Fail</span>  </p>
		</div>	
		<?php
		}
		if($audio_check!="")
		{
		?>
		<div class="spacer">
		<h4 class="heading lh">Audio Check</h4>
			<p class="contnt"> <span <?php
			if($audio_check=='Yes'){
			?> class="active-x" <?php } ?>>Pass</span> | <span <?php
			if($audio_check=='No'){
			?> class="active-x" <?php } ?>>Fail</span>  </p>
		</div>
		<?php
		}
		if($display_check!="")
		{
		?>
		<div class="spacer">
		<h4 class="heading lh">Display Check</h4>
			<p class="contnt"> <span <?php
			if($display_check=='Yes'){
			?> class="active-x" <?php } ?>>Pass</span> | <span <?php
			if($display_check=='No'){
			?> class="active-x" <?php } ?>>Fail</span>  </p>
		</div>
		<?php
		}
		if($gps_check!="")
		{
		?>
		<div class="spacer">
		<h4 class="heading lh">GPS Check</h4>
			<p class="contnt"> <span <?php
			if($gps_check=='Yes'){
			?> class="active-x" <?php } ?>>Pass</span> | <span <?php
			if($gps_check=='No'){
			?> class="active-x" <?php } ?>>Fail</span>  </p>
		</div>	
		<?php
		}
		if($camera_check!="")
		{
		?>
		<div class="spacer">
		<h4 class="heading lh">Camera Check</h4>
			<p class="contnt"> <span <?php
			if($camera_check=='Yes'){
			?> class="active-x" <?php } ?>>Pass</span> | <span <?php
			if($camera_check=='No'){
			?> class="active-x" <?php } ?>>Fail</span>  </p>
		</div>	
		<?php
		}
		if($automated_check!="")
		{
		?>
		<div class="spacer">
		<h4 class="heading lh">Automated Check</h4>
			<p class="contnt"> <span <?php
			if($automated_check=='Yes'){
			?> class="active-x" <?php } ?>>Pass</span> | <span <?php
			if($automated_check=='No'){
			?> class="active-x" <?php } ?>>Fail</span>  </p>
		</div>	
		<?php
		}
		if($sensor_check!="")
		{
		?>
		<div class="spacer">
		<h4 class="heading lh">Censor Check</h4>
			<p class="contnt"> <span <?php
			if($sensor_check=='Yes'){
			?> class="active-x" <?php } ?>>Pass</span> | <span <?php
			if($sensor_check=='No'){
			?> class="active-x" <?php } ?>>Fail</span>  </p>
		</div>	
		<?php
		}
			if($adds_on!="")
			{
		?>
		<h3 class="heading bdr2"><b>ADD-ONs</b></h3>
			<div class="spacer">
			<h4 class="heading lh"><?php echo $adds_on; ?></h4>
			</div>
		
		<?php
			}
		}
		?>
		
			
		<h3 class="heading bdr3 deefct"><b>DEFECTS/ISSUES</b></h3>
			
			
			<?php
				$sqa="Select * from report where property='Cosmetic Scratches' and taskid='".$_SESSION['tid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{
					?>
					<h4 class="heading lh csmcts" style="color:#d32e0e !important">COSMETIC</h4>
				<div class="spacer">
			<p class="contnt"> <span><b>Scratches</b>:</span>  </p>
			</div>
			<center>	
					
<?php
					while($crow=$re->fetch_assoc())
					{
						?>
			
			<div class="col-sm-6 col-md-4 col-lg-4">
				<img src="../report-pics/<?php echo $crow['property_value'];?>" width="80%" height="200px">
			</div>
			<?php
					}
				?>
			</center>
			<div style="clear:both;"></div>
				<?php
				}
			?>


			<?php
				$sqa="Select * from report where property='Dents' and taskid='".$_SESSION['tid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{
					?>
				<div class="spacer">
			<p class="contnt" style="margin-top:10px;"> <span><b>Dents</b>:</span>  </p>
			</div>
			<center>	
					
			<?php
					while($crow=$re->fetch_assoc())
					{
			?>
			
			<div class="col-sm-6 col-md-4 col-lg-4">
				<img src="../report-pics/<?php echo $crow['property_value'];?>" width="80%" height="200px">
			</div>
			<?php
					}
			?>
			</center>
			
			<div style="clear:both;"></div>
			<?php
				}
			?>
		

			<?php
				$sqa="Select * from report where property='Discoloration' and taskid='".$_SESSION['tid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{
					?>
				<div class="spacer">
				<p class="contnt" style="margin-top:10px;"> <span><b>Discoloration</b>:</span>  </p>
				</div>
			<center>	
					
<?php
					while($crow=$re->fetch_assoc())
					{
?>			
			<div class="col-sm-6 col-md-4 col-lg-4">
				<img src="../report-pics/<?php echo $crow['property_value'];?>" width="80%" height="200px">
			</div>
				<?php
					}
				?>
			</center>
			
			<div style="clear:both;"></div>
				<?php
				}
				?>
				
				
		

			<?php
				$sqa="Select * from report where property='Scuffs' and taskid='".$_SESSION['tid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{
					?>
				<div class="spacer">
				<p class="contnt" style="margin-top:10px;"> <span><b>Scuffs</b>:</span>  </p>
				</div>
			<center>	
					
<?php
					while($crow=$re->fetch_assoc())
					{
?>			
			<div class="col-sm-6 col-md-4 col-lg-4">
				<img src="../report-pics/<?php echo $crow['property_value'];?>" width="80%" height="200px">
			</div>
				<?php
					}
				?>
			</center>
			<div style="clear:both;"></div>
				<?php
				}
				?>

		<?php
				$sqa="Select * from report where property='Bends' and taskid='".$_SESSION['tid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{
					?>
				<div class="spacer">
				<p class="contnt" style="margin-top:10px;"> <span><b>Bends</b>:</span>  </p>
				</div>
			<center>	
					
<?php
					while($crow=$re->fetch_assoc())
					{
?>			
			<div class="col-sm-6 col-md-4 col-lg-4">
				<img src="../report-pics/<?php echo $crow['property_value'];?>" width="80%" height="200px">
			</div>
				<?php
					}
				?>
			</center>
			<div style="clear:both;"></div>
				<?php
				}
				?>
		

		<?php
				$sqa="Select * from report where property='Torn' and taskid='".$_SESSION['tid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{
					?>
				<div class="spacer">
				<p class="contnt" style="margin-top:10px;"> <span><b>Torn</b>:</span>  </p>
				</div>
			<center>	
					
<?php
					while($crow=$re->fetch_assoc())
					{
?>			
			<div class="col-sm-6 col-md-4 col-lg-4">
				<img src="../report-pics/<?php echo $crow['property_value'];?>" width="80%" height="200px">
			</div>
				<?php
					}
				?>
			</center>
			<div style="clear:both;"></div>
				<?php
				}
				?>
				
	

		<?php
				$sqa="Select * from report where property='Faded' and taskid='".$_SESSION['tid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{
					?>
				<div class="spacer">
				<p class="contnt" style="margin-top:10px;"> <span><b>Faded</b>:</span>  </p>
				</div>
			<center>	
					
<?php
					while($crow=$re->fetch_assoc())
					{
?>			
			<div class="col-sm-6 col-md-4 col-lg-4">
				<img src="../report-pics/<?php echo $crow['property_value'];?>" width="80%" height="200px">
			</div>
				<?php
					}
				?>
			</center>
			<div style="clear:both;"></div>
				<?php
				}
				?>
						

			
		<?php
				$sqa="Select * from report where property='Cracks' and taskid='".$_SESSION['tid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{
					?>
				<div class="spacer">
				<p class="contnt" style="margin-top:10px;"> <span><b>Cracks</b>:</span>  </p>
				</div>
			<center>	
					
<?php
					while($crow=$re->fetch_assoc())
					{
?>			
			<div class="col-sm-6 col-md-4 col-lg-4">
				<img src="../report-pics/<?php echo $crow['property_value'];?>" width="80%" height="200px">
			</div>
				<?php
					}
				?>
			</center>
			<div style="clear:both;"></div>
				<?php
				}
				?>	

				<!--		<div class="spacer" style="clear:both;">
			<br><br><br>
			</div>-->

		<?php
				$sqa="Select * from report where property='Broken' and taskid='".$_SESSION['tid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{
					?>
				<div class="spacer">
				<p class="contnt" style="margin-top:10px;"> <span><b>Broken</b>:</span>  </p>
				</div>
			<center>	
					
<?php
					while($crow=$re->fetch_assoc())
					{
?>			
			<div class="col-sm-6 col-md-4 col-lg-4">
				<img src="../report-pics/<?php echo $crow['property_value'];?>" width="80%" height="200px">
			</div>
				<?php
					}
				?>
			</center>
			<div style="clear:both;"></div>
				<?php
				}
				?>
				
		
		<?php  
		if($sizendimension!="")
		{
		?>
		<div class="spacer" style="clear:both;">
		<h3 class="heading lh" style="color:#d32e0e !important"><b>Dimention & Specification</b></h3>
		
			<!--<p class="contnt"> <span><?php echo $sizendimension;?></span>  </p>-->
		</div>
		<?php
		}
		?>
			<div class="spacer" style="">
			
			<?php
			if($height!="")
			{
			?>
			<p class="contnt"> <span><b>Height:</b> <br><br><br><br><br><br><br><?php echo $height;?></span>  </p>
			<br>
			<?php
			}
			?>
			
			<?php
			if($width!="")
			{
			?>
			<p class="contnt"> <span><b>Width:</b> <br><br><br><br><br><br><br><?php echo $width;?></span>  </p>
			<br>
			<?php
			}
			?>
			<?php
			if($length!="")
			{
			?>
			<p class="contnt"> <span><b>Length:</b> <br><br><br><br><br><br><br><?php echo $length;?></span>  </p>
			<?php
			}
			if($true_to_dimension!="")
			{
			?>
			<h4 class="heading lh"><br>True To Scale Picture</h4>
			<div class="col-sm-6 col-md-4 col-lg-4">
				<img src="../report-pics/<?php echo $true_to_dimension;?>" width="80%" height="200px">
			</div>	
		<?php
			}
		?>
			</div>
			
		
		
		
		<?php  
		if($tts!="")
		{
		?>
		<div class="spacer" style="clear:both;">
		<h3 class="heading lh mt-3" style="color:#d32e0e !important" ><b>Size</b></h3>
		
			<!--<p class="contnt"> <span><?php //echo $sizendimension;?></span>  </p>-->
		</div>
		<?php
		}
		?>
			<div class="spacer" style="">
			
			<?php
		
			if($fheight!="")
			{
			?>
			<p class="contnt"> <span><b>Height</b> <br><br><br><br><br><br><br> <?php echo $fheight;?></span>  </p>
			<br>
			<?php
			}
			?>
			
			<?php
			if($fweight!="")
			{
			?>
			<p class="contnt"> <span><b>Weight</b> <br><br><br><br><br><br><br><?php echo $fweight;?></span>  </p>
			<br>
			<?php
			}
			?>
			<?php
			if($waist!="")
			{
			?>
			<p class="contnt"> <span><b>Length/Waist</b> <br><br><br><br><br><br><br><?php echo $waist;?></span>  </p>
			<br>
			<?php
			}
			
			if($colar!="")
			{
			?>
			<p class="contnt"> <span><b>Colar Size</b> <br><br><br><br><br><br><br><?php echo $colar;?></span>  </p>
			<?php
			}
			
			
			if($tag!="")
			{
			?>
			<p class="contnt"> <span><b>Size as per the tag</b> <br><br><br><br><br><br><br><?php echo $tag;?></span>  </p>
			<?php
			}
			
			if($true_to_size!="")
			{
			?>
			<h4 class="heading lh"><br>True Scale Image</h4>
			<div class="col-sm-6 col-md-4 col-lg-4">
				<img src="../report-pics/<?php echo $true_to_size;?>" width="80%" height="200px">
			</div>	
			<div style="clear:both;"></div>
		<?php
			}
		
			if($size!="")
			{
			?>
			<p class="contnt" style="margin-top:20px;"> <span><b>Size True to description</b> <br><br><br><br><br><br><br><?php echo $size;?></span>  </p>
			<?php
			}
		?>
			</div>
			
		
		
		
		
		<?php  
		if($working!="")
		{
		?>
		<div class="spacer" style="clear:both;">
		<h4 class="heading lh" style="color:#d32e0e !important"><br>WORKING CHECK</h4>
			<p class="contnt"> <span><?php echo $working;?></span>  </p>
		</div>
		<?php
		}
		//if($diagnostic_network!="" || $diagnostic_audio!="")
		//{
		?>
			<div class="spacer" style="">
			
			<h4 class="heading lh" style="color:#d32e0e !important">DIAGNOSTICS</h4>
			<?php
			if($diagnostic_network!="" && $network_check=='No')
			{
			?>
			<p class="contnt"> <span><b>Network:</b> <br><br><br><br><br><br><br><?php echo $diagnostic_network;?></span>  </p>
			<?php
			}
			?>
			<br>
			<?php
			if($diagnostic_audio!="" && $audio_check=='No')
			{
			?>
			<p class="contnt"> <span><b>Audio:</b> <br><br><br><br><br><br><br><?php echo $diagnostic_audio;?></span>  </p>
			<?php
			}
			?>
			<?php
			if($diagnostic_gps!="" && $gps_check=='No')
			{
			?><br>
			<p class="contnt"> <span><b>GPS:</b> <br><br><br><br><br><br><br><?php echo $diagnostic_gps;?></span>  </p>
			<?php
			}
			?>
			<?php
			if($diagnostic_display!="" && $display_check=='No')
			{
			?><br>
			<p class="contnt"> <span><b>Display:</b> <br><br><br><br><br><br><br><?php echo $diagnostic_display;?></span>  </p>
			<?php
			}
			?>
			<?php
			if($diagnostic_sensor!="" && $sensor_check=='No')
			{
			?><br>
			<p class="contnt"> <span><b>Sensor:</b> <br><br><br><br><br><br><br><?php echo $diagnostic_sensor;?></span>  </p>
			<?php
			}
			?>
			<?php
			if($diagnostic_automated!="" && $automated_check=='No')
			{
			?><br>
			<p class="contnt"> <span><b>Automatic:</b> <br><br><br><br><br><br><br><?php echo $diagnostic_automated;?></span>  </p>
			<?php
			}
			?>
			<?php
			if($diagnostic_battery!="" && $battery_check=='No')
			{
			?><br>
			<p class="contnt"> <span><b>Battery:</b> <br><br><br><br><br><br><br><?php echo $diagnostic_battery;?></span>  </p>
			<?php
			}
			?>
			<?php
			if($diagnostic_camera!="" && $camera_check=='No')
			{
			?><br>
			<p class="contnt"> <span><b>Camera:</b> <br><br><br><br><br><br><br><?php echo $diagnostic_camera;?></span>  </p>
			<?php
			}
			?>
			</div>
<?php
	//}
?>			
			<div class="col-sm-12 col-md-12 col-lg-12 h3 text-center end-of-report"><p class=""><b>END OF REPORT</b></p> </div>
	</div>
	<div class="col-sm-12 col-md-3 col-lg-3"></div>
	<?php
	if($orderstatus=="Underverification" && $showmodel!="Unfit" && $typo!="Invalid")
	{
	?>
	
	
	<style>
		/* @media only screen and (max-width:768px){
			.moda{
				display:block;position:fixed !important; bottom:0 !important;
			}
			.mod2{
				display:none; position:absolute;width:90%;left:0%;top:-10%;
		 color:white !important;margin-top:50px;
			}
			.go_chekmate{
				margin-left:-10px;
			}
		} */
		/* @media only screen and (min-width:768px){
		.moda{
			display:block;position:fixed !important; bottom:0 !important;left:30%;right:30%;
			}
			.mod2{
				display:none; position:absolute;width:80%;left:10%;top:10%;
		 color:white !important;margin-top:50px;
			}
		} */
		</style>
		
			<div style="position:sticky;bottom:0px; padding:0;margin:0;" class="alert alert-dismissible fade in order">
	
		   <div class="moda "  style="" >
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content" style="background:#423c3cd9;border:2px solid white;border-radius:30px;">
                        <div class="modal-body">
							<center>
							<div class="" style="border-radius:20px;z-index:1;margin-left:10%;margin-right:10%;">
								<br><br>
									<p align=center style="color:white;font-size:16px;">
									<b class="h4 congros"><b>Congratulations!</b></b><br>
									This Inspection is complete.<br>
									In order to proceed please make a selection:<br><br>
									<form action="" method="post">	
									<!--	<button type="submit" name="accept_order" class="btn btn-lg bg-orange"
										style="color:white;border-radius:17px;width:200px;" >Accept & Proceed</button>-->
					
			
			<button type="button" style="color:white;border-radius:17px;width:200px;"
			class="btn btn-lg bg-orange"  onclick="myFunction()" >Accept & Proceed</button>	
		
<?php

if($ordercount<="1")
{
?>
		
		 <div class="alert modal-body mod2" id="md" style="display:none;color:white;">
    
      <!-- Modal content-->
      <div class="modal-content bg-orange" style="border:1px solid white;padding:20px;border-radius:25px">
		<p>	Chekmate inspection & delivery is FREE this time only! <br> This product will be purchased on your behalf, 
		<br> and its cost will be collected at COD</p>
		<button type="button"  onclick="myFunction()" class="btn btn-sm"
			style="background:transparent;color:white;
			border:1px solid white;border-radius:10px;width:104px;font-weight:700;">Go Back </button>
		&nbsp &nbsp &nbsp
		<button type="submit" name="accept_orderfirst" class="btn btn-sm go_chekmate"
					style="color:#d32e0e;background:white;border-radius:10px;width:114px;font-weight:800;" >Go Chekmate!</button>
			<p style="margin-top:5px;">	By completing this order, I agree to all <b>terms & conditions.</b>	</p>				
			</div>
			</div>		
			
<?php
}else{
	
?>	

	<div class="alert modal-body mod2 cncl-fit-ordr" id="md" style="display:none;color:white;">
      <!-- Modal content-->
      <div class="modal-content bg-orange" style="border:1px solid white;padding:20px;border-radius:25px">
		<p>	This product will be purchased on your behalf, <br> and its cost plus the Chekmate inspection fee of Rs. 850 <br> will be collected at COD</p>
		<button type="button"  onclick="myFunction()" class="btn btn-sm"
			style="background:transparent;color:white;border:1px solid white;border-radius:10px;width:104px;
			font-weight:700;">Go Back </button>
		&nbsp &nbsp &nbsp
		<button type="submit" name="accept_order" class="btn btn-sm go_chekmate"
			style="color:#d32e0e;background:white;border-radius:10px;width:114px;font-weight:800;" >Go Chekmate!</button>
			<p style="margin-top:5px;">	By completing this order, I agree to all <b type="button" data-toggle="modal" data-target="#exampleModal">terms & conditions.</b>	</p>				
	  </div>
	</div>	
		


<?php
}
?>		
		
 <div class="alert modal-body mod2 cncl-fit-ordr" id="mdd" style="display:none;color:white;">
    

      <div class="modal-content bg-orange" style="border:1px solid white;padding:20px;border-radius:25px">
		<p>	If you cancel an order "<i>Fit to Ship</i>", the pending<br>Chekmate inspection fee of Rs. 850 <br> will be collected at on your next order delivery.<br> Are you sure you want to cancel the order?</p>
		<?php

if($ordercount<="1")
{
?>
		<button type="submit" name="cancel_order2" class="btn btn-sm" 
		style="background:transparent;color:white;border:1px solid white;border-radius:10px;width:104px;font-weight:700;">Cancel Anyway</button>
	<?php
}else{
?>	
		<button type="submit" name="cancel_orderfirst" class="btn btn-sm" 
		style="background:transparent;color:white;border:1px solid white;border-radius:10px;width:104px;font-weight:700;">Cancel Anyway</button>

<?php
}
?>
		&nbsp &nbsp &nbsp
		<button  onclick="myFunction2()" class="btn btn-sm" type="button"
				style="background:white;color:#d32e0e;border-radius:10px;width:114px;font-weight:800;" >Don't Cancel</button>	
			</div>
			</div>	
	

	
	


					
										<br><br>
										<button type="button" onclick="myFunction2()" class="btn btn-lg"
										style="background:grey;color:white;border-radius:17px;width:200px;" >Cancel Order</button>
							
									</form>
									</p>
							</div>
							</center>
						
				   </div>
                </div>
            </div>
		</div>
	</div>
		<script>
function myFunction() {
  var x = document.getElementById("md");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
function myFunction2() {
  var y = document.getElementById("mdd");
  if (y.style.display === "none") {
    y.style.display = "block";
  } else {
    y.style.display = "none";
  }
}
</script>
	

	
		<?php }
if($showmodel=='Unfit')
{
		?>
		
		<style>
		@media only screen and (max-width:768px){
			.moda{
				display:block;position:fixed !important; bottom:0 !important;
			}
		}
		@media only screen and (min-width:768px){
		.moda{
			display:block;position:fixed !important; bottom:0 !important;left:30%;right:30%;
		}
		}
		</style>
		
			<div style="position:sticky;bottom:0px;" class="alert alert-dismissible fade in order">
	
		   <div class="moda cheeka"  style="" >
                <div class="modal-dialog modal-dialog-centered warningg" style="    width: 101vw !important;
    margin: -3px 0 0 -2px;">
                    <div class="modal-content bg-orang" style="background:#808080d1;    height: 100vh;
    position: relative;">
                        <div class="modal-body">
							<center>
							<div class="bg-orang bg-transparent"
							style="border-radius:20px;z-index:1;margin-left:10%;margin-right:10%;">
							
								
								<i style="color:white;font-size:30px;font-weight:bold;" class="fa fa-warning"></i>
								<br><br>
									<p align=center style="color:white;font-size:14px;">
									<b>UNFORTUNATELY, THIS PRODUCT SEEMS UNFIT TO SHIP.</b><br>
									We hope to help you in finding a better product next time.<br><br>
									You were not charged for this Chekmate inspection.<br><br>
									<form action="../index.php?order" method="post">	
										<button type="button"  data-dismiss="alert" aria-label="close" class="btn btn-lg"
										style="background:transparent;color:white;border:1px solid white;border-radius:15px;width:140px;">Ok</button>
									</form>
									</p>
							</div>
							</center>
						
				   </div>
                </div>
            </div>
		</div>	
	</div>
	<?php
}
	?>
</div>	
	

</div>


<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog  opsi">
    <div class="modal-content " style="    border-radius: 33px;
    padding-top: 20px;">
      <!-- <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>

      </div> -->

      <div class="modal-body rprt-mdl-bdy">
	  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
	  <p style="font-size:24px;font-weight:600;color:#1F1F1F;" align=center><i>Term & Conditions</i> </p>
										<p style="font-size:14px;color:#1F1F1F;">
											This document, as well as the documents mentioned therein, states our terms and conditions on which we supply any of the products (Products) whether contracted to us privately for inspection or those listed on our website, Android and iOS apps (“Our Site and Apps”) to you. Please read these terms and conditions carefully before ordering any Products from Us, Our Site and Apps. You should understand that by ordering any of our Products, you agree to be bound by these terms and conditions.
											Chekmate Logistics (PVT) Ltd is a company that inspects, 
											purchases, delivers and accredits products that are bought 
											and sold on peer-peer marketplaces, social media or web .We 
											are registered in Pakistan under company number 0151427.
											<br><br>
											By ordering from Us, Our Site and Apps, 
											you are deemed to have accepted these terms and conditions.
											<br><br>
										<b>	1.	Your Status As A Buyer and Seller (Our Customer)</b>
											<br><br>
											a)	By placing an order through Our Site and Apps, you warrant that:<br>
											&nbsp &nbsp 1)	You are legally capable of entering into binding contracts; and<br>
										&nbsp &nbsp	2)	You are at least 18 years old; we will not inspect for, sell or deliver to anyone who is, or appears to be, under the age of 18; 				we reserve the right not to deliver if we are unsure of this. A Valid CNIC or other ID will be required.
										&nbsp &nbsp 3)	You do not intend to use Our Site and Apps or service for the sale or delivery of any form of alcohol and prohibited 					drugs/narcotics. We will refuse deliver any such products to anyone
										<br><br>
										<b>	2.	Process for Customers who are Buyers:</b>
											<br>
											(a)	When a customer wants to purchase a used/new product they share the product details with us. We inspect the product at the 			seller’s location and purchase it after approval of inspection from the buyer (our customer) on the basis of a generated report. 			We inspect as per the seller’s listing and validate their claims as advertised. We assure the customer that the product reaches 			them in the same condition as at the time of inspection.
										<br>	(b)	Chekmate reserves the right to set/cap and vary the maximum purchase amount paid on the buyer’s behalf to the seller at its 			own discretion.
										<br>
										<b>	3.	Process for Customers who are Sellers:</b>
										<br>
											(a)	When an individual seller, small brand, or an unbranded store wants to maintain a quality check to gain buyer trust, they 				engage us as a quality assurance and inspection service through which they secure a Chekmate accreditation.
										<br>
	
							a.	After placing an order for inspection, you will receive a notification from us acknowledging that we have received your order. 			Please note that this does not mean that your order has been accepted. Your order constitutes an offer to us to buy /inspect a 			Product. All orders are subject to acceptance by us, and we will confirm such acceptance to you by sending you a notification 			that confirms that the Product has been scheduled for inspection and delivery following the inspection. (The Dispatch 					Confirmation). The contract between us (Contract) will only be formed when we send you the Dispatch Confirmation. We reserve 		the right to refuse any order or cancel a delivery at any time without giving a reason.
							<br>b.	The Contract will relate only to those Products whose /inspection dispatch we have confirmed in the Dispatch Confirmation. We 		will not be obliged to supply or inspect any other Products, which may have been part of your order until the 						inspection/dispatch of such Products has been confirmed in a separate Inspection/Dispatch Confirmation.
							<br>c.	Please note that once you have made your order and your payment has been authorized you will not be able to cancel your 			order for inspection/collection/delivery and that refunds may be given at the discretion of the management.
							<br><br>
							<b>5.	Our Status</b>
							<br><br>	a.	We may provide links on Our Site and Apps to the websites of other companies (other websites), or listings of products 				supplied by other companies, whether affiliated with us or not. We cannot give any undertaking, that products you 					purchase from companies to whose website we have provided a link on Our Site and Apps, will be of satisfactory quality, 				and any such warranties are DISCLAIMED by us absolutely. This DISCLAIMER does not affect your statutory rights against 				the third party. The status/business of Chekmate is solely to provide delivery/inspection of the aforementioned products 				and not to provide any warranties/guarantees of the quality and/or packaging of the said products.
							<br>	b.	All questions regarding goods shown on Our Site and Apps should be directed to the affiliate company.
							<br><br>
							<b>6.	Inspection, Availability of Product and Delivery</b>
							<br><br>	a.	Your order will be fulfilled by the inspection delivery date/time set out in the Dispatch Confirmation.
							<br>	b.	Delivery periods quoted by our Delivery Partners at the time of ordering are approximate only and may vary. Products will 				be delivered to the address designated by you at the time of ordering. You agree to take particular care when providing 				our Delivery Partners with your details and warrant that these details are accurate and complete at the time of ordering.
							<br>	c.	In case of a late delivery, the delivery charge will neither be voided nor refunded, and it is the responsibility of our Delivery 				Partners.
							<br>	d.	If you fail to accept delivery of a Product at the time they are ready for delivery after inspection, or we are unable to deliver 			at the nominated time due to your failure to provide appropriate instructions, or authorizations, then such Products shall be 			deemed to have been delivered to you and all risk and responsibility in relation to such Products shall pass to you. Any 				storage, insurance and other costs, which we incur as a result of the inability to deliver, shall be your responsibility and 				you shall indemnify us in full for such cost.
							<br><br>
							<b>7.	Risk and Title</b>
							<br><br>
							a.	The Products will be your responsibility from the time of delivery by our delivery partners.

							<br>b.	Ownership of the Products will only pass to you when we receive full payment of all sums due in respect of the Products, 				including inspection and delivery charges. It is the responsibility of the customer (whether buyer or seller) to thoroughly 				check the Inspected Products before agreeing to pay for an order.
							<br>	c.	Cash on delivery, bank transfer credit or debit card, The Chekmate Payment Portal or any other payment method(s) that 				we make available on Our Site and Apps from time to time must make payment for all Products.
							<br>d.	Refunds for payments will be made via Chekmate Portal, or, at our discretion, the original payment method for the order.
							<br>e.	You consent to receive all disclosures, notices, change in terms, and other documents related to these Terms & Conditions 				and use of Chekmate Payment portals electronically. As the customer you also agree that Chekmate may provide notices 				concerning these Terms by posting the material on Our Site and Apps, through electronic notice given to any electronic 				mailbox it maintains for you or to any other email address or telephone number you provide to us.
							<br>f.	Chekmate is not responsible for any errors, delays, or the inability to use Chekmate’s payment methods for any transaction.
							<br>g.	The Customer is responsible for maintaining the confidentiality of his/her Chekmate Payment Portal information and any 				underlying financial information. You should keep all credentials secure and confidential. Do not share your credentials with 			any other person. Information you provide to any mobile wallet provider is subject to that provider’s agreements and is not 			governed by these Terms.
							<br>h.	Chekmate reserves the right to terminate the User’s usage of his/her Chekmate Payment Portal at any time with or without 			notice. Chekmate may terminate or amend these Terms at any time without notice unless required by law. The User’s use of 			Chekmate Pay after Chekmate has made such changes will be deemed your consent to the changes.
							<br>i.	The laws of Pakistan govern this Agreement. This Agreement is the sole understanding of the parties with respect to the 				stated subject matter. If any provision of this Agreement is held by a court of competent jurisdiction to be invalid or 					unenforceable, such provision will be enforced to the fullest extent that it is valid and enforceable under applicable law. All 				provision of this Agreement relating to ownership, indemnification, and limitations of liability shall remain in full force and 				effect after termination of this Agreement. Chekmate may assign these Terms. You may not assign these Terms.
							<br>j.	CHEKMATE IS NOT AND SHALL NOT BE LIABLE FOR ANY LOSS, DAMAGE OR INJURY OR FOR ANY DIRECT, INDIRECT, 					SPECIAL, INCIDENTAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING FROM OR RELATED 			TO YOUR ACCESS OR USE OF CHEKMATE’S ONLINE PORTALS.
							<br>k.	Chekmate shall incur no liability if it is unable to complete a transaction in a timely manner because: (i) your account does 				not contain sufficient funds to complete the transaction or the transaction exceeds the limit of your overdraft protection 				options; (ii) the Chekmate Pay is not working properly and you knew or were advised about the problem before completing 			the transaction; (iii) circumstances beyond Chekmate ’s control (such as, but not limited to, telecommunication failure, fire, 				flood, or interference from an outside force) that prevent or delay the transaction; (v) Chekmate  has reason to believe the 				transaction is unauthorized by you; and/or (vi) there may be other exceptions stated in our agreement(s) with you.
							<br><br>
							<b>8.	Our Liability</b><br>
							<br>
							Our Internal processes pertain to Riders and our Partners.	
							<br><br>
							<b>9.	Process for Riders/Inspectors:</b>
							<br><br>
							<br><b>10.	Once the process of inspection is started, the riders/inspectors reach the
							seller’s site and conduct an inspection of the requested 
							product through a mobile app on the location. The assessment score in the report depends
							on the input of the inspector and 	their observations to determine the final score of the assessment.
							We are not responsible to the Seller for the inspection report generated or the views of the inspector.
							</b><br><br>
							<b>11.	The assessment report is then shared with the buyer and if the product is fit to ship as per the assessment being accepted by the 		buyer, the product is purchased by Chekmate on the buyer’s behalf and brought to our designated Chekmate HUB.
							</b><br><br>
							<b>Process for Delivery Partners:</b>
							<br><br>
							<b>12.	Our Delivery partners collect the product from our HUB, deliver it to the buyer and collect cash on delivery (COD) that includes 			the price of the product as well as the inspection fee. The Delivery partners are responsible for any breakage, accidental 				damages etc. during the delivery process from our HUB to the buyer.
							</b><br>
							<b>13.	We warrant to you that any Product purchased through Us is of satisfactory quality and reasonably fit for all the purposes for 			which products of the kind are commonly supplied.
							</b>	<br><br>a.	We are not responsible for indirect losses which happen as a side effect of the main loss or damage, including but not 				limited to:
							<br>	i.	Loss of income or revenue
							<br>	ii.	Loss of business
							<br>	iii.	Loss of profits or contracts
							<br>	iv.	Loss of anticipated savings
							<br>	v.	Loss of data, or
							<br>	vi.	Waste of management or office time however arising and whether caused by tort (including negligence), breach 					of contract or otherwise;
							<br>	b.	Great care has been taken to ensure that the information available on Our Site and Apps is correct and error free. We 				apologize for any errors or omissions that may have occurred. We cannot warrant that use of Our Site and Apps will be 				error free or fit for purpose, timely, that defects will be corrected, or that our Site and Apps or the server that makes it 					available are free of viruses or bugs or represents the full functionality, accuracy, reliability of Our Site and Apps and we do 			not make any warranty whatsoever, whether express or implied, relating to fitness for purpose, or accuracy.
							<br>	c.	By accepting these terms of use you agree to relieve us from any liability after the goods reach our HUB where the goods 				are collected by the Delivery Partners.
							<br>	d.	We do not accept any liability for any delays, failures, errors or omissions or loss of transmitted information, viruses or other 			contamination or destructive properties transmitted to you or your computer system via Our Site and Apps.	
							<br><br>
							<b>	14.	Written communications</b>
							<br>a.	Applicable laws require that some of the information or communications we send to you should be in writing. When using 				Our Site and Apps, you accept that communication with us will be mainly electronic. We will contact you by e-mail or 					provide you with information by posting notices on our website or your Chekmate account with us. For contractual 					purposes, you agree to this electronic means of communication and you acknowledge that all contracts, notices, 					information and other communications that we provide to you electronically comply with any legal requirement that such 				communications be in writing. This condition does not affect your statutory rights.
							<br><br>
							<b>15.	Notices</b>
							<br>	a.	All notices given by you to us must be given to us via email at ______. We may give notice to you at either the 					e-mail or postal address you provide to us when placing an order. Notice will be deemed to have been received 						and properly served immediately when posted on our website, 24 hours after an e-mail is sent, or three days after the date 			of posting of any letter. 
							<br><br>
							<b>16.	Transfer of rights and obligations</b>
							<br><br>	a.	The contract between you and us is binding on you and us and on our respective successors and assigns.
							<br>	b.	You may not transfer, assign, charge or otherwise dispose of a Contract, or any of your rights or obligations arising under it, 			without our prior written consent.
							<br>	c.	We may transfer, assign, charge, sub-contract or otherwise dispose of a Contract, or any of our rights or obligations arising 			under it, at any time during the term of the Contract.
							<br><br><b>	16-A Data Protection</b> 
							<br><br>	Our team takes great care when processing data of Data Subjects, when processing Personal Data. “Personal Data” means any 		information relating to any Data Subject connected with the performance of this Contract. “DPR” means any data protection 			regulations applicable to the Parties in relation to the performance of this Contract, including those in Pakistan.
							<br>	We ensure compliance with the DPR in respect of Personal Data, with particular regard to:
							<br>(i) Its collection and use;
							<br>(ii) its safeguarding;
							<br>(iii) any transfer to third parties;
							<br>(iv) its retention; and
							<br>(v) the protection of Data Subjects’ rights.
							<br>(b) You shall have proper notification and response procedures for any Personal Data breach.
							<br><br>
							<b>17.	Events outside our control</b>
							<br><br>	a.	We will not be liable or responsible for any failure to perform, or delay in performance of, any of our obligations under a 				Contract that is caused by events outside our reasonable control (Force Majeure Event).
							<br>	b.	A Force Majeure Event includes any act, event, non-happening, omission or accident beyond our reasonable control and
							includes in particular (without limitation) the following:
							<br>i.	Strikes, lockouts or other industrial action.
							<br>	ii.	Civil commotion, riot, invasion, terrorist attack or threat of terrorist attack, war (whether declared or not) or threat or 					preparation for war.
							<br>	iii.	Fire, explosion, storm, flood, earthquake, subsidence, epidemic or other natural disaster.
							<br>	iv.	Impossibility of the use of railways, shipping, aircraft, motor transport or other means of public or private transport.
							<br>	v.	Impossibility of the use of public or private telecommunications networks.
							<br>	vi.	The acts, decrees, legislation, regulations or restrictions of any government.
							<br>	vii.	Our performance under any Contract is deemed to be suspended for the period that the Force Majeure Event continues, 				and we will have an extension of time for performance for the duration of that period. We will use our reasonable 					endeavors to bring the Force Majeure Event to a close or to find a solution by which our obligations under the Contract 				may be performed despite the Force Majeure Event.
							<br><br>
							<b>18.	Waiver</b>
							<br><br>	a.	A waiver by us of any default shall not constitute a waiver of any subsequent default.
							<br>	b.	No waiver by us of any of these terms and conditions shall be effective unless it is expressly stated to be a waiver and is 				communicated to you in writing.

							<b>19.	Severability</b>
							<br><br>	a.	If any of these terms and Conditions or any provisions of a Contract are determined by any competent authority to be 				invalid, unlawful or unenforceable to any extent, such term, condition or provision will to that extent be severed from 					the remaining terms, conditions and provisions which will continue to be valid to the fullest extent permitted by law.
							<br><br>
							<b>20.	Entire agreement</b>
							<br><br>	a.	These terms and conditions and any document expressly referred to in them constitute the whole agreement between us 				and supersede any previous arrangement, understanding or agreement between us, relating to the subject matter of any 				Contract.
							<br>	b.	We each acknowledge that, in entering into a Contract, (and the documents referred to in it); neither of us relies on any 				statement, representation, assurance or warranty (Representation) of any person (whether a party to that Contract or not) 				other than as expressly set out in these terms and conditions.
							<br>	c.	Each of us agrees that the only rights and remedies available to us arising out of or in connection with a Representation 				shall be for breach of contract as provided in these terms and conditions.
							<br>	d.	Nothing in this clause shall limit or exclude any liability for fraud.
							<br><br>
							<b>21.	Our right to vary these terms and conditions</b>
							<br><br>	a.	We have the right to revise and amend these terms and conditions from time to time.	
							<br>b.	You will be subject to the policies and terms and conditions in force at the time that you order products from us, unless any 			change to those policies or these terms and conditions is required to be made by law or governmental authority (in which 				case it will apply to orders previously placed by you), or if we notify you of the change to those policies or these terms 					and conditions before we send you the Inspection/Dispatch Confirmation (in which case we have the right to assume that 				you have accepted the change to the terms and conditions, unless you notify us to the contrary within seven working days 				of receipt by you of the Products).
							<br><br>
							<b>22.	Law and jurisdiction</b>
							<br><br>
							a.	Contracts for the purchase of Products through Our Site and Apps and any
							dispute or claim arising out of or in connection with them or their subject matter or formation 
							(including non-contractual disputes or claims) will be governed by Pakistani law. 
							Any dispute or claim arising out of or in connection with such Contracts or their formation (including	non-contractual disputes or claims) shall be subject
							to the non-exclusive jurisdiction of the courts of Pakistan.
							</p>
							<div class="text-center">
							<button type="button" class="btn bg-orange rprt-trmmdl" data-dismiss="modal">Ok</button>
							</div>

      </div>
      <!-- <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div> -->
    </div>
  </div>
</div>
	<script>
	document.addEventListener('keyup', (e) => {
    if (e.key == 'PrintScreen') {
        navigator.clipboard.writeText('');
       // alert('Screenshots disabled!');
    }
});
document.onkeydown = function (e) {
        return false;
}
/** TO DISABLE PRINTS WHIT CTRL+P **/
document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key == 'p' ) {
      //  alert('This section is not allowed to print or export to PDF');
        e.cancelBubble = true;
        e.preventDefault();
        e.stopImmediatePropagation();
    }
});
</script>
    <script src="../js/aos.js"></script>
    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/main.js"></script>
</body>
</html>