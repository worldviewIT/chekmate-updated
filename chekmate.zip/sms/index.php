<?php

$msisdn = "923432435000";
$password = "thisisalongenoughpassword123!";

$url = "https://telenorcsms.com.pk:27677/corporate_sms2/api/auth.jsp?msisdn=".$msisdn."&password=".$password;
$xmlResponseString = file_get_contents($url);
$xmlResponse = simplexml_load_string($xmlResponseString);
$array=json_decode(json_encode((array)$xmlResponse),True);
//$sessionID = $xmlResponse->corpsms->data;
print_r($array['data']);
$msg="Welcome TO ChekMate";
$url2 = "https://telenorcsms.com.pk:27677/corporate_sms2/api/sendsms.jsp?session_id=".$array['data']."&mask=CHEKMATE&to=923156075941&text=".urlencode($msg);
$xmlResponseString2 = file_get_contents($url2);
$xmlResponse2 = simplexml_load_string($xmlResponseString2);


print_r($xmlResponse2);
?>