-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 22, 2022 at 08:03 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `checkmate`
--

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `taskid` int(11) NOT NULL,
  `property` varchar(200) DEFAULT NULL,
  `property_value` text NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`taskid`, `property`, `property_value`, `id`) VALUES
(1, 'Order Type', 'Pre Loved', 1),
(1, 'Diagnostics Test', '1', 2),
(1, 'Cosmetic Test', '1', 3),
(1, 'Working Conditions', '1', 4),
(1, 'Front-Picture', '1324355375bambu-utensils-longspoon-bare-removebg-preview.png', 5),
(1, 'Back-Picture', '1807623204bambu-utensils-longspoon-bare-removebg-preview.png', 6),
(1, 'LS-Picture', '1146811084آج ہی آرڈر کریں۔.png', 7),
(1, 'RS-Picture', '1968797280bambu-utensils-longspoon-bare-removebg-preview.png', 8),
(1, 'TS-Picture', '384858638آج ہی آرڈر کریں۔.png', 9),
(1, 'BS-Picture', '1710767879r5uf6j121ecdb276.jpeg', 10),
(1, 'Turn On', 'Yes', 11),
(1, 'Fully Functional', 'Yes', 12),
(1, 'Repair History', 'No', 13),
(1, 'Warrenty', 'No', 14),
(1, 'Battery Check', 'Yes', 15),
(1, 'Network Check', 'No', 16),
(1, 'Audio Check', 'Yes', 17),
(1, 'Display Check', 'Yes', 18),
(1, 'Gps Check', 'Yes', 19),
(1, 'Camera Check', 'No', 20),
(1, 'Automated Check', 'Yes', 21),
(1, 'Sensor Check', 'Yes', 22),
(1, 'ADD-ONs', 'Bluetooth not turn on', 23),
(1, 'Cosmetic Scratches', '803420700pngwing.com (25).png', 24),
(1, 'Dents', '1997841097pngwing.com (25).png', 25),
(1, 'Cracks', '989191727pngwing.com (25).png', 26),
(1, 'Cracks', '736480962pngwing.com (25).png', 27),
(1, 'Working', 'All over working is good.', 28),
(1, 'Diagnostic Network', ' Bluetooth is missing.', 29),
(1, 'Diagnostic Camera', 'Front Cam is not working ', 30);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `taskid` int(3) NOT NULL,
  `link` varchar(200) DEFAULT NULL,
  `userid` int(4) DEFAULT NULL,
  `contact` varchar(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `taskdate` text DEFAULT NULL,
  `amt` varchar(40) DEFAULT NULL,
  `riderid` int(11) DEFAULT NULL,
  `details` varchar(500) DEFAULT NULL,
  `status` text DEFAULT NULL,
  `assign_date` varchar(30) DEFAULT NULL,
  `product_type` varchar(50) DEFAULT NULL,
  `rating` varchar(20) DEFAULT NULL,
  `address` varchar(600) DEFAULT NULL,
  `product_name` varchar(200) DEFAULT NULL,
  `submission_date` varchar(50) DEFAULT NULL,
  `task_condition` varchar(100) DEFAULT NULL,
  `task_health` varchar(100) DEFAULT NULL,
  `seller_contact` varchar(14) DEFAULT NULL,
  `seller_email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`taskid`, `link`, `userid`, `contact`, `email`, `taskdate`, `amt`, `riderid`, `details`, `status`, `assign_date`, `product_type`, `rating`, `address`, `product_name`, `submission_date`, `task_condition`, `task_health`, `seller_contact`, `seller_email`) VALUES
(1, 'https://facebook.com/worldviewit', 80, '03156075941', 'ana.miler001@gmail.com', '21-01-2022', '1800', 85, '', 'Cancelled', '2022-01-21', 'Mobile Device', '6.33', 'New Bahira AP 207', 'Samsung S3', '2022-01-21 07:58:13pm', 'Front Camera Not Working', 'Pass', '03156075941', 'ana.miler001@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(4) NOT NULL,
  `mobile` varchar(70) DEFAULT NULL,
  `Name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `type` varchar(30) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `otp` varchar(20) DEFAULT NULL,
  `arrears` varchar(30) DEFAULT NULL,
  `account_hold` varchar(30) DEFAULT NULL,
  `forget_otp` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `mobile`, `Name`, `email`, `password`, `type`, `address`, `otp`, `arrears`, `account_hold`, `forget_otp`) VALUES
(53, '03156075941', 'M.Yousaf(Admin)', 'admin@checkmate.com', 'admin', 'admin', NULL, NULL, NULL, NULL, NULL),
(54, '03156075941', 'Yousaf(Rider)', 'user@gmail.com', '1234', 'Rider', NULL, NULL, NULL, NULL, NULL),
(79, '03092316694', 'Guest-User', 'ablman@gamail.com', '1234', 'User', 'Old Bulberg Lahore', '', NULL, NULL, NULL),
(80, '03156075941', 'Muhammad Yousaf', 'ana.miler001@gmail.com', '11223', 'User', 'Shah Rukne', '', '4250', NULL, ''),
(82, '0344454545', 'Ali', 'ali@gmail.com', '1234', 'User', NULL, '', NULL, NULL, NULL),
(84, '03156075941', 'muhammad Yousaf', 'ana.miler001@gmail.com', '12345', 'User', 'New Shah rukne alam', '', NULL, 'yes', NULL),
(85, '03002232121', 'Ali', 'ali@chekmate.com', '1234', 'Rider', NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`taskid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `taskid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
