(function() {
    "use strict";

    /**
     * Animation on scroll
     */
    window.addEventListener('load', () => {
        AOS.init({
            duration: 2000,
            easing: 'ease-in-out',
            // once: true,
            mirror: false
        })
    });

});



// gsap.registerPlugin(ScrollTrigger);

// ScrollTrigger.create({
//     trigger: ".buying",
//     animation: anim,
//     markers: true,
//     start: "top center",
//     end: "top 100px",
//     toggleClass: "active",
//     pin: true,
//     scrub: 1,
//   });


function isScrolledIntoView(elem) {
    var docViewTop = $(window).scrollTop();
    var docViewBottom = docViewTop + $(window).height();

    var elemTop = $(elem).offset().top;
    var elemBottom = elemTop + $(elem).height();

    return ((elemBottom <= docViewBottom) && (elemTop >= docViewTop));
}

$(window).scroll(function () {
    $('.sec4-bg img:nth-child(1)').each(function () {
        if (isScrolledIntoView(this) === true) {
            $(this).addClass('animate-bg');
        } else {
            $(this).removeClass('animate-bg');
        }
    });

});
$(window).scroll(function () {
    $('.sec4-bg img:nth-child(2)').each(function () {
        if (isScrolledIntoView(this) === true) {
            $(this).addClass('animate-bg-opst');
        } else {
            $(this).removeClass('animate-bg-opst');
        }
    });
});

$(window).scroll(function () {
    $('.bg-fit img:nth-child(1)').each(function () {
        if (isScrolledIntoView(this) === true) {
            $(this).addClass('animate-bg');
        } else {
            $(this).removeClass('animate-bg');
        }
    });

});
$(window).scroll(function () {
    $('.bg-fit img:nth-child(2)').each(function () {
        if (isScrolledIntoView(this) === true) {
            $(this).addClass('animate-bg-opst');
        } else {
            $(this).removeClass('animate-bg-opst');
        }
    });
});
$(window).scroll(function () {
    $('span.num-area-1-text-in.athvr-two.hover-forth-sec-four').each(function () {
        if (isScrolledIntoView(this) === true) {
            $(this).addClass('nomi');
        } else {
            $(this).removeClass('nomi');
        }
    });
    $('.num-area-2 .hover-forth-sec').each(function () {
        if (isScrolledIntoView(this) === true) {
            $(this).addClass('nomi1');
        } else {
            $(this).removeClass('nomi1');
        }
    });
});

if (window.matchMedia('(min-width: 1500px)').matches) {
    function bigImg(x) {
        $("span.num-area-1-text-in.athvr-two.hover-forth-sec-four").css({
            "background-color": "white",
            "color": "red",
            'font-size': "44px",
            "padding":" 0px 21px",
            "margin": "4px 0px 0 -3px",
            "transition":" all .5s",
        });
        $(".num-area-2:hover .hover-forth-sec").css({
            "opacity":" 1 ",
            "transition":" all 1s"
        })
      }
    
      function bigImg1(x) {
        $("span.num-area-1-text-in.athvr-four.hover-forth-sec-four:hover").css({
            "background-color": "white",
            "color": "red",
            'font-size': "44px",
            "padding":" 0px 21px",
            "margin": "4px 0px 0 -3px",
            "transition":" all .5s",
        });
        $(".num-area-4:hover .hover-forth-sec").css({
            "opacity":" 1 ",
            "transition":" all 1s"
        })
      }
    
      function bigImg2(x) {
        $("span.num-area-1-text-in.athvr-three.hover-forth-sec-four:hover").css({
            "background-color": "white",
            "color": "red",
            'font-size': "44px",
            "padding":" 0px 21px",
            "margin": "4px 0px 0 -3px",
            "transition":" all .5s",
        });
        $(".num-area-3:hover .hover-forth-sec").css({
            "opacity":" 1 ",
            "transition":" all 1s"
        })
      }
    
      function bigImg3(x) {
        $("span.num-area-1-text-in.athvr-one.hover-forth-sec-four:hover").css({
            "background-color": "white",
            "color": "red",
            'font-size': "44px",
            "padding":" 0px 23px",
            "margin": "4px 0px 0 -3px",
            "transition":" all .5s",
        });
        $(".num-area-1:hover .hover-forth-sec").css({
            "opacity":" 1 ",
            "transition":" all 1s"
        })
      }
}

//   $(window).resize(function() {
    if (window.matchMedia('(max-width: 1400px)').matches) {
        function bigImg(x) {
            $("span.num-area-1-text-in.athvr-two.hover-forth-sec-four").css({
                "background-color": "white",
                "color": "red",
                'font-size': "28px",
                "padding":" 0px 12px",
                "margin": "4px 0px 0 -3px",
                "transition":" all .5s",
            });
            $(".num-area-2:hover .hover-forth-sec").css({
                "opacity":" 1 ",
                "transition":" all 1s"
            })
          }
        
          function bigImg1(x) {
            $("span.num-area-1-text-in.athvr-four.hover-forth-sec-four:hover").css({
                "background-color": "white",
                "color": "red",
                'font-size': "28px",
                "padding":" 0px 12px",
                "margin": "4px 0px 0 -3px",
                "transition":" all .5s",
            });
            $(".num-area-4:hover .hover-forth-sec").css({
                "opacity":" 1 ",
                "transition":" all 1s"
            })
          }
        
          function bigImg2(x) {
            $("span.num-area-1-text-in.athvr-three.hover-forth-sec-four:hover").css({
                "background-color": "white",
                "color": "red",
                'font-size': "28px",
                "padding":" 0px 12px",
                "margin": "4px 0px 0 -3px",
                "transition":" all .5s",
            });
            $(".num-area-3:hover .hover-forth-sec").css({
                "opacity":" 1 ",
                "transition":" all 1s"
            })
          }
        
          function bigImg3(x) {
            $("span.num-area-1-text-in.athvr-one.hover-forth-sec-four:hover").css({
                "background-color": "white",
                "color": "red",
                'font-size': "28px",
                "padding":" 0px 16px",
                "margin": "4px 0px 0 -3px",
                "transition":" all .5s",
            });
            $(".num-area-1:hover .hover-forth-sec").css({
                "opacity":" 1 ",
                "transition":" all 1s"
            })
          }
    }
//   });


//   $(window).resize(function() {
    if (window.matchMedia('(max-width: 600px)').matches) {
        function bigImg(x) {
            $("span.num-area-1-text-in.athvr-two.hover-forth-sec-four").css({
                "background-color": "white",
                "color": "red",
                'font-size': "16px",
                "padding":" 3px 12px",
                "margin": "4px 0px 0px 0px",
                "transition":" all .5s",
            });
            $(".num-area-2:hover .hover-forth-sec").css({
                "opacity":" 1 ",
                "transition":" all 1s"
            })
          }
        
          function bigImg1(x) {
            $("span.num-area-1-text-in.athvr-four.hover-forth-sec-four:hover").css({
                "background-color": "white",
                "color": "red",
                "padding":" 0px 10px",
                "margin": "4px 0px 0px 0px",
                "font-size": "14px!important",
                "transition":" all .5s",
            });
            $(".num-area-4:hover .hover-forth-sec").css({
                "opacity":" 1 ",
                "transition":" all 1s"
            })
          }
        
          function bigImg2(x) {
            $("span.num-area-1-text-in.athvr-three.hover-forth-sec-four:hover").css({
                "background-color": "white",
                "color": "red",
                'font-size': "16px",
                "padding":" 3px 12px",
                "margin": "4px 0px 0px 0px",
                "transition":" all .5s",
            });
            $(".num-area-3:hover .hover-forth-sec").css({
                "opacity":" 1 ",
                "transition":" all 1s"
            })
          }
        
          function bigImg3(x) {
            $("span.num-area-1-text-in.athvr-one.hover-forth-sec-four:hover").css({
                "background-color": "white",
                "color": "red",
                'font-size': "16px",
                "padding":" 3px 12px",
                "margin": "4px 0px 0px 0px",
                "transition":" all .5s",
            });
            $(".num-area-1:hover .hover-forth-sec").css({
                "opacity":" 1 ",
                "transition":" all 1s"
            })
          }
    }
//   });