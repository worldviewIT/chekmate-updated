<?php
ob_start();
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php include "title.php"; ?> Signup</title>
    <!-- Core CSS - Include with every page -->
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
   <link href="assets/css/style.css" rel="stylesheet" />
      <link href="assets/css/main-style.css" rel="stylesheet" />

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script async custom-element="amp-auto-ads"
        src="https://cdn.ampproject.org/v0/amp-auto-ads-0.1.js">
</script>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

</head>

<body>
<div class="body-Login-back">
<img src="assets/img/bg.jpg" height=100% width=100% />
</div>
    <div class="container">
        
        <div class="row" id="formf">
            
            <div class="col-md-10 col-md-offset-5 text-center logo-margin" style="text-shadow: 2px 2px black;color:#5cb85c;">
            <span><h1> MF SOURCE </h1></span>
            <h3>ONLINE WORK</h3>
                </div>
               
            <div class="col-md-8 col-md-offset-6 text-center">
                <div class="login-panel panel panel-default" style="height:0px;">                  
                    <div class="panel-heading">
                         <br>
                        <h3 class="panel-title"><b><a href="index.php">User Sign In</a></b></h3>
                    </div>
                    <div class="panel-body">
                        <form action="" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control"  placeholder="Name" name="name" type="text" autofocus required>
                                </div>
								 <div class="form-group">
									<select class="form-control" name="gender" required>
									<option value="">Gender</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
									</select>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Mobile" name="mobile" type="text" required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="City" name="city" type="text" required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control"  placeholder="Login ID" name="email" type="text" autofocus required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="text" required>
                                </div>
								<div class="form-group">
                                    <input class="form-control btn-success" value="Login" name="log" type="submit" >
                                </div>
                            
                                <!-- Change this to a button or input when using this as a form -->
                            
                                <p style="color:black;" align=center>&nbsp &nbsp Copyright<a href="#" style="color:black;font-size:16px;"> <u>Mf-Source</u> </a>. &nbsp &nbsp &nbsp</p>    
                            </fieldset>
                        </form>
						<?php
						
							Session_Start();
						if(isset($_POST['log'])){
							include"conn.php";
						$u=$_POST['email'];
						$p=$_POST['password'];
						$mysql="Select * from department where Username='$u'";
						$res=$conn->query($mysql);
						if($res->num_rows>0){
							$row=$res->fetch_assoc();
							if($row['status']=='admin')
							{
								echo '<h3 class="alert alert-info">Account Already Exists</h3>';
							}
							elseif($row['status']=='user')
							{
								echo '<h3 class="alert alert-info">Account Already Exists</h3>';
							}else{
								echo"<p style='color:black;' align=center>You are Not Able to login</p>";
							}
							
						}else{
							$rand=rand();
							$sql="INSERT INTO `department`( `Depname`, `Name`, `Username`, `password`, `Bio`,`City`, `status`,`otp`) 
							VALUES ('".$_POST['name']."','".$_POST['mobile']."','".$_POST['email']."','".$_POST['password']."','".$_POST['gender']."','".$_POST['city']."','user','$rand')";
							if($conn->query($sql))
						{
							  // the message
$msg = "MF-SOURCE Email Otp is:" . $rand ;

// use wordwrap() if lines are longer than 70 characters
$msg = wordwrap($msg,150);

// send email
$e=$_POST['email'];
mail($e,"MF-SOURCE OTP",$msg);
							
							$_SESSION['user-email']=$_POST['email'];
								header('location:otp.php');
						}else{
								echo "<h3 align=center>Please Try Again Later!<h3>".$conn->error;		
						}
						}
						}
						?>
                    </div>
                </div>
            </div>
        </div>
        <amp-auto-ads type="adsense"
              data-ad-client="ca-pub-9558982913422036">
</amp-auto-ads>
    </div>

     <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>

</body>

</html>
