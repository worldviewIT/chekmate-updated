<?php
ob_start();
?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link href="css/aos.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <title>ChekMate</title>
</head>

<body>
  
    <nav class="navbar navbar-expand-lg navbar-expand-sm navbar-expand-xs navbar-dark bg-dark mynav">
        <div class="container-fluid">
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <div class="col">
                    <!--<ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <span class="navbar-toggler-icon"></span>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item active" href="#">Home</a></li>
                                <li><a class="dropdown-item" href="#2">How To Chekmate</a></li>
                                <li><a class="dropdown-item" href="#3">Company</a></li>
                                <li><a class="dropdown-item" href="#4">FAQs</a></li>
                                <li><a class="dropdown-item" href="#5">Contact</a></li>
                            </ul>
                        </li>
                    </ul>-->
                </div>
                <div class="logo-img text-center">
                    <a href="#"><img src="images/Chekmate-Logo1.png" class="top-logo" ></a>
                </div>
                <div class="col">
                   <!-- <div class="navbar-nav my-end">
                        <div class="btn-group" role="group" aria-label="Vertical radio toggle button group">
                            <button type="button" class="btn-check" data-bs-toggle="modal" data-bs-target="#exampleProfile" name="vbtn-radio" id="vbtn-radio0" autocomplete="off" checked=""></button>
                            <label class="btn btn-outline-danger" style="color:white;" for="vbtn-radio0">Profile</label>
                            <input type="radio" class="btn-check" name="vbtn-radio" id="vbtn-radio1" autocomplete="off" checked="">
                            <label class="btn btn-outline-danger" for="vbtn-radio1">BUY</label>
                            <input type="radio" class="btn-check" name="vbtn-radio" id="vbtn-radio2" autocomplete="off">
                            <label class="btn btn-outline-danger" for="vbtn-radio2">SELL</label>
                        </div>
                    </div>-->
                </div>
            </div>
        </div>
    </nav>

  
  
    <section id="1">
        <div class="container">
          



          <div class="modal fade mt-4" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="display:block;opacity:1;overflow:hidden;">
                <div class="modal-dialog modal-dialog-centered" style="margin-top:60px;">
                    <div class="modal-content mt-4" >
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="popup-heading">
                                        <h2 align=center>Rider Login</h2>
										<form action="" method="post">
                                       
                                        <div class="mb-4">
                                            <input type="email" name="email" class="form-control footer-input" id="exampleFormControlInput1" required placeholder="Email">
                                        </div>
                                        <div class="mb-4">
                                            <input type="password" name="password" class="form-control footer-input" id="exampleFormControlInput1" required placeholder="password">
                                        </div>
										 <center>
                                        <button class="btn btn-success border-rad-popup mt-1" name="log" type="submit">Login</button>
										
										 </center>
										</form>
										<?php
						if(isset($_POST['log'])){
							include"conn.php";
						$u=$_POST['email'];
						$p=$_POST['password'];
						$mysql="Select * from user where email='$u' and password='$p' and type='Rider'";
						$res=$conn->query($mysql);
						if($res->num_rows>0){
							
							Session_Start();
							$row=$res->fetch_assoc();
							
							$_SESSION['rider']=$row['Name'];
							$_SESSION['rider_id']=$row['id'];
							header('location:rider/index.php');
							}else{
									echo"<p style='color:white;' align=center>You are Not Able to login</p>";
							}
							
						
						}
						?>
                                       <!-- <p class="mt-2"> Are You Rider?
										<span> <button class="btn btn-orange btn-sm" type="button" id="button-addon1" data-bs-toggle="modal" data-bs-target="#exampleLogin">Rider Login</button></span></p>
                                       -->
                                    </div>
                                </div>
                              
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           
     




		</div>
    </section>

    <script src="js/aos.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/main.js"></script>

</body>

</html>