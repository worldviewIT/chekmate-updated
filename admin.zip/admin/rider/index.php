<?php 
ob_start();
Session_Start();
if(!isset($_SESSION['rider']))
header("location:\logout.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php include "title.php"?></title>
    <!-- Core CSS - Include with every page -->
    <link href="../assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="../assets/css/style.css" rel="stylesheet" />
    <link href="../assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="../assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
	<style>
#dept_anchor{
		text-decoration:none;
	}	
#dept:hover{
	opacity:0.8;
	color:black;
}

	</style>
   </head>
<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
<?php  include "header.php"; ?>
        <!-- end navbar top -->
    
        <!-- navbar side -->
      
                  
                  <?php include "sidebar.php"; ?>
               
            <!-- end sidebar-collapse -->
    
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

          
                <!--quick info section -->
			
                <!--end quick info section -->
           <div class="row">
              
				<div class="panel-heading" align=center>
                        <h2 class="panel-titl" style="color:green;"><?php
                        if(isset($_GET['fback'])){
                         echo   $_GET['fback'];
                            
                        }
                        
                        ?></h2>
                    </div>
				            </div>
                       
                       
				<div class="panel-heading" align=center>
                        <h2 class="panel-titl"><b><i>Rider Panel</i></b></h2>
                    </div>
					
					<?php
					include "conn.php";
			?>
					
			   <div class="col-lg-3">
                    <div class="panel panel-primary text-center no-boder">
                        <div class="panel-body blue">
                            <i class="fa fa-bar-chart-o fa-3x"></i>
                            <h3><i class="fa fa-arrow-down"></i></h3>
                        </div>
                        <div class="panel-footer">
                            <span class="panel-eyecandy-title"><a class="text-dark font-weight-bold" href="linksummary.php"><b><i>New Tasks</i></b></a> 
                            </span>
                        </div>
                    </div>
					</div>
					<div class="col-lg-3">
                    <div class="panel panel-primary text-center no-boder">
                        <div class="panel-body" style="background-color:orange;color:white;">
                            <i class="fa fa-envelope-o fa-3x"></i>
                            <h3><i class="fa fa-arrow-down"></i></h3>
                        </div>
                        <div class="panel-footer">
                            <span class="panel-eyecandy-title"><a class="text-dark font-weight-bold" href="linksummary2.php"><b><i>Task Reports</i></b></a>
                            </span>
                        </div>
                    </div>
					</div>
		
					<br>
				<!--	<div class="col-lg-12" style="float:center;text-align:center;height:100px;">
					 <a href="\assets/dcmcms.apk">   <h4 class="btn btn" style="padding-top:40px;height:100%;width:50%;border:2px groove white;color:white;background-color:#354c48;">Get Android App</h4></a>
					    </div>-->
         </div>
               
	
        <!-- end page-wrapper -->

    </div>
    <?php
    include "footer.php";
    ?>
    <!-- end wrapper -->
    <!-- Core Scripts - Include with every page -->
    <script src="../assets/plugins/jquery-1.10.2.js"></script>
    <script src="../assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../assets/plugins/pace/pace.js"></script>
    <script src="../assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="../assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="../assets/plugins/morris/morris.js"></script>
    <script src="../assets/scripts/dashboard-demo.js"></script>
  
</body>

</html>
