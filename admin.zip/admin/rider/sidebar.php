  
        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
  <ul class="nav" id="side-menu">
  <li>
                        <!-- user image section-->
<?php
									if(isset($_SESSION['rider'])){
										$use=$_SESSION['rider_id'];
									$n="Select * from user where id='$use'";
										if($reslt=$conn->query($n)){
											$nrow=$reslt->fetch_assoc();
                       echo' <div class="user-section">
                            <div style="padding-left:70px;">
                                <img src="../assets/img/rider.png" height="100px" width="100px" style="border-radius:50%;" alt="your profile not loaded">
                            </div>
                            <div class="user-info">
                                <div>
												<strong>' . $nrow['Name'] . '  </strong></div>';
												}
									}
									?>
                            </div>
                        </div>
                        <!--end user image section-->
                    </li>
  <li class="sidebar-search">
                        <!-- search section-->
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search Task...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <!--end search section-->
                    </li>
                                    <li>
				  <a href="profile.php">Profile</a>
				  </li>
                  <li>
				  <a href="index.php">Dashboard</a>
				  </li>
				  <li>
				  <a href="linksummary.php">New Tasks</a>
				  </li>
				  <li>
				  <a href="linksummary2.php">Tasks Report</a>
				  </li>
				
				    <li>
				  <a href="logout.php">Logout</a>
				  </li>
				  </nav>