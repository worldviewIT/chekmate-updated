<?php 
ob_start();
Session_Start();
if(!isset($_SESSION['rider']))
header("location:\logout.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php include "title.php"?> </title>
    <!-- Core CSS - Include with every page -->
    <link href="../assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="../assets/css/style.css" rel="stylesheet" />
    <link href="../assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="../assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
	<style>
#dept_anchor{
		text-decoration:none;
	}	
#dept:hover{
	opacity:0.8;
	color:black;
}
	</style>
	

   </head>
<body>
    <div id="wrapper">
    <!--  wrapper -->
       <?php include "header.php" ?>
    
        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
                   
                   <?php   
				   include "sidebar.php";
				   ?>
               
            <!-- end sidebar-collapse -->
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

          
                <!--quick info section -->
			
                <!--end quick info section -->
           <div class="row">
              
				<div class="panel-heading" align=center>
                        <h2 class="panel-titl" style="color:green;"><?php
                        if(isset($_GET['fback']))
						{
                         echo   $_GET['fback'];    
                        }        
                        ?>
						</h2>
                </div>
				            </div>
                       
                       
				<div class="panel-heading" align=center>
                        <h2 class="panel-titl">Tasks Report</h2>
                    </div>
					
		 
		
			  <div class="col-lg-12">
					
				<form action="" method="post" class="form-inline">
						<label class="h5"><b>Choose Date</b></label>
							<input type="date" name="sd" class="form-control" style="width:30%;" value="<?php echo date('Y-m-d');?>">
							<input type="date" name="ed" class="form-control" style="width:30%;" value="">
							<button type="submit" name="search" class="btn btn-info text-dark"><b>Generate Report </b></button>
					</form>

                </div>
		<div class="table table-responsive">
			<table class="table table-bordered">
				 <thead>
                                        <tr>
                                            <th>Task ID:</th>
                                            <th>Assigned Date</th>
                                            <th>Link</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php
										include "conn.php";
											$subscribed=0;
											$subscriber=0;
							if(isset($_POST['sd']) && !empty($_POST['ed']))
							{
								$sd=strtotime($_POST['sd']);
								$sd=date('d-m-Y',$sd);
								$ed=strtotime($_POST['ed']);
								$ed=date('d-m-Y',$ed);
								
								$all="Select * from tasks where riderid='".$_SESSION['rider_id']."' and taskdate between '$sd' and '$ed' order by taskdate asc";
							}else{
								$all="Select * from tasks where riderid='".$_SESSION['rider_id']."' order by taskid desc";
							}
									$res=$conn->query($all);
										if($res->num_rows>0){
										while($row=$res->fetch_assoc()){
										echo' <tr>
										<td> '.$row['taskid'].'</td>
										<td> ' . $row['taskdate'] . ' </td>
										<td> ' . $row['link'] . ' </td>
										<td> ' . $row['amt'] . ' </td>
										<td> ' . $row['status'] . ' </td>';
										echo'</tr>';		
					?>					
						
		
										
					<?php					
										}
										}else{
											echo '<tr>
												<td colspan=5 align=center ><b>No Task Assigned Try Again Later</b></td>
											</tr>';
										}
										
										?>
									  
                                    </tbody>
                                </table>

			</table>
		</div>
			
			
		 </div>
               
        <!-- end page-wrapper -->

    </div>
    <?php
    include "footer.php";
    ?>
    <!-- end wrapper -->
    <!-- Core Scripts - Include with every page -->
    <script src="../assets/plugins/jquery-1.10.2.js"></script>
    <script src="../assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../assets/plugins/pace/pace.js"></script>
    <script src="../assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="../assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="../assets/plugins/morris/morris.js"></script>
    <script src="../assets/scripts/dashboard-demo.js"></script>
  
</body>

</html>
