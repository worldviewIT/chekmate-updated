<?php
ob_start();
?>
<?php 
Session_Start();
if(!isset($_SESSION['rider']))
header("location:\logout.php");
?>
<!DOCTYPE html>
<html>
<head>
   
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php include "title.php"?></title>
    <!-- Core CSS - Include with every page -->
    <link href="../assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="../assets/css/style.css" rel="stylesheet" />
    <link href="../assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="../assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
	<style>
#dept_anchor{
		text-decoration:none;
	}	
#dept:hover{
	opacity:0.8;
	color:black;
}

	</style>
   </head>
<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
       <?php include "header.php" ?>
        <!-- end navbar top -->
    
        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
                  
                   <?php   
				   include "sidebar.php";
				   ?>
               
            <!-- end sidebar-collapse -->
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

        


                <!--quick info section -->
				<div class="panel-heading" align=center>
                        <h2 class="panel-titl"><b><i>Rider Profile</i></b></h2>
                    </div>
					
                <div class="row">
               <div class="col-lg-4">
				<?php
				include "conn.php";
				 $use=$_SESSION['rider_id'];
				$profile="Select * from user where id='$use'";
				if($result=$conn->query($profile)){
				$prorow=$result->fetch_assoc();
				echo'
				<form action="" method="post" enctype="multipart/form-data">
				<input type="hidden" class="form-control" name="id" value="'.$prorow['id'].'">
				<label>Name</label>
				<input type="text" class="form-control" name="name" value="'.$prorow['Name'].'" readonly>
				<label>Mobile</label>
				<input type="text" class="form-control" name="mobile" value="'.$prorow['mobile'].'" readonly>
				<label>Email</label>
				<input type="text" class="form-control" name="email" value="'.$prorow['email'].'" readonly>
				<label>Password</label>
				<input type="text" class="form-control" name="password" value="'.$prorow['password'].'" >
				</div>
				</br>
				<div class="col-lg-4">
				<img src="../assets/img/rider.png" height="120px" width="120px"  style="border-radius:50%;border:1px solid black;" placeholder="Select New Image"></img>
				<!--<input type="file" style="background-color:#354c48;color:white" name="imag" value="">-->
				</div>
				<br>
				</div>
				<div class="row">
				<div class="col-lg-6">		
				<input type="submit" class="form-control btn-success" name="update" value="Update Profile">
				<br>
				</form>
				
				</div>
				';
				}
				?>
				<?php
										if(isset($_GET['msg'])){
											echo'<p style="color:green;">'.$_GET['msg'].'</p>';
										}
										?>
                </div>
				<?php
								if(isset($_POST['update'])){
								    include "conn.php";
								$name=$_POST['name'];
							//	$depname=$_POST['department'];
								$did=$_POST['id'];
								$username=$_POST['email'];
								$pass=$_POST['password'];
							//	$bio=$_POST['bio'];
							//	$city=$_POST['city'];
							//	$desig=$_POST['designation'];
						    //	$upload_file=$_FILES["imag"]["name"];
							//	$folder="../assets/img/";
						
						/*	if(empty($upload_file)==true){*/
							    include "conn.php";
								$update="Update user set password='$pass' where id='$did'";
								if($conn->query($update)){
									header('location:profile.php?msg=Your Profile Updated Successfully');
								}else{
									echo '<p align=center style="color:red;"> Try Again Later You cannot Update Rider Record now!!!</p>';
								}
                         //   }
                       /*     elseif(!empty($upload_file)==true){
                                echo $upload_file;
                            $search="Select * from department where Did='$did'";
                            if($searchres=$conn->query($search)){
                            $srow=$searchres->fetch_assoc();
                            $file=$srow['img'];
                             unlink($folder.$file);
                           move_uploaded_file($_FILES["imag"]["tmp_name"], $folder.$_FILES["imag"]["name"]);
                            }
                        	include "conn.php";
						echo		$update="Update department set Depname='$depname',Name='$name',Username='$username',password='$pass',Designation='$desig',Bio='$bio',City='$city',img='$upload_file' where Did='$did'";
								if($conn->query($update)){
									header('location:profile.php?msg=Your Profile Updated Successfully');
								}else{
									echo '<p align=center style="color:red;"> Try Again Later You cannot Update Department Record now!!!</p>';
								}
                            }	*/
								}
								?>
                
                <!--end quick info section -->
           
         
		</div>
		</div>
        </div>
        <!-- end page-wrapper -->
<?php
    include "footer.php";
    ?>
    <!-- end wrapper -->
    <!-- Core Scripts - Include with every page -->
    <script src="../assets/plugins/jquery-1.10.2.js"></script>
    <script src="../assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../assets/plugins/pace/pace.js"></script>
    <script src="../assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="../assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="../assets/plugins/morris/morris.js"></script>
    <script src="../assets/scripts/dashboard-demo.js"></script>
</body>

</html>
