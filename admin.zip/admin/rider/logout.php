<?php
session_start();
unset($_SESSION['rider']);
unset($_SESSION['rider_id']);
header('location:../rider-login.php');
?>