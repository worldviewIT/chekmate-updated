<?php
session_start();
if(isset($_SESSION['taskid']))
{
	include "conn.php";
	if(isset($_POST['step1']))
	{
//Order Type
if(isset($_POST['ordertype']))
{
	
	$sal="Select * from report where property='Order Type' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['ordertype'])
		{
		$sql="Update report set property_value='".$_POST['ordertype']."' where taskid='".$_SESSION['taskid']."' and property='Order Type'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Order Type','".$_POST['ordertype']."')";
		$conn->query($sql);
	}
	
}
//Diagnostics 
if(isset($_POST['Diagnostics_Test']))
{
	
	$sal="Select * from report where property='Diagnostics Test' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['Diagnostics_Test'])
		{
		$sql="Update report set property_value='".$_POST['Diagnostics_Test']."' where taskid='".$_SESSION['taskid']."' and property='Diagnostics Test'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Diagnostics Test','".$_POST['Diagnostics_Test']."')";
		$conn->query($sql);
	}
	
}
//Cosmetics Script 
if(isset($_POST['Cosmetic_Test']))
{
	
	$sal="Select * from report where property='Cosmetic Test' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['Cosmetic_Test'])
		{
		$sql="Update report set property_value='".$_POST['Cosmetic_Test']."' where taskid='".$_SESSION['taskid']."' and property='Cosmetic Test'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Cosmetic Test','".$_POST['Cosmetic_Test']."')";
		$conn->query($sql);
	}
}


//Working Test Script 
if(isset($_POST['Working_Test']))
{
	
	$sal="Select * from report where property='Working Conditions' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['Working_Test'])
		{
		$sql="Update report set property_value='".$_POST['Working_Test']."' where taskid='".$_SESSION['taskid']."' and property='Working Conditions'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Working Conditions','".$_POST['Working_Test']."')";
		$conn->query($sql);
	}
}




header('location:report-form.php?#Step1');
	//step 1 close
	}
	
	
	// ======================= STEP 2 STARTED =========================
	
		if(isset($_POST['step2']))
	{
//Turn On
if(isset($_POST['turn_on']))
{
	
	$sal="Select * from report where property='Turn On' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['turn_on'])
		{
		$sql="Update report set property_value='".$_POST['turn_on']."' where taskid='".$_SESSION['taskid']."' and property='Turn On'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Turn On','".$_POST['turn_on']."')";
		$conn->query($sql);
	}
		
}

//Fully Functional
if(isset($_POST['fully_functional']))
{
	
	$sal="Select * from report where property='Fully Functional' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['fully_functional'])
		{
		$sql="Update report set property_value='".$_POST['fully_functional']."' where taskid='".$_SESSION['taskid']."' and property='Fully Functional'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Fully Functional','".$_POST['fully_functional']."')";
		$conn->query($sql);
	}
	
}

//Repair History
if(isset($_POST['repair_history']))
{
	
	$sal="Select * from report where property='Repair History' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['repair_history'])
		{
		$sql="Update report set property_value='".$_POST['repair_history']."' where taskid='".$_SESSION['taskid']."' and property='Repair History'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Repair History','".$_POST['repair_history']."')";
		$conn->query($sql);
	}
	
}

//Warrenty  Check
if(isset($_POST['warrenty']))
{
	
	$sal="Select * from report where property='Warrenty' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['warrenty'])
		{
		$sql="Update report set property_value='".$_POST['warrenty']."' where taskid='".$_SESSION['taskid']."' and property='Warrenty'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Warrenty','".$_POST['warrenty']."')";
		$conn->query($sql);
	}
}

//Battery Check
if(isset($_POST['battery_check']))
{
	
	$sal="Select * from report where property='Battery Check' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['battery_check'])
		{
		$sql="Update report set property_value='".$_POST['battery_check']."' where taskid='".$_SESSION['taskid']."' and property='Battery Check'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Battery Check','".$_POST['battery_check']."')";
		$conn->query($sql);
	}
}

//Network Check
if(isset($_POST['network_check']))
{
	
	$sal="Select * from report where property='Network Check' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['network_check'])
		{
		$sql="Update report set property_value='".$_POST['network_check']."' where taskid='".$_SESSION['taskid']."' and property='Network Check'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Network Check','".$_POST['network_check']."')";
		$conn->query($sql);
	}
}

//Audio Check
if(isset($_POST['audio_check']))
{
	
	$sal="Select * from report where property='Audio Check' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['audio_check'])
		{
		$sql="Update report set property_value='".$_POST['audio_check']."' where taskid='".$_SESSION['taskid']."' and property='Audio Check'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Audio Check','".$_POST['audio_check']."')";
		$conn->query($sql);
	}
}

//Display Check
if(isset($_POST['display_check']))
{	
	$sal="Select * from report where property='Display Check' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['display_check'])
		{
		$sql="Update report set property_value='".$_POST['display_check']."' where taskid='".$_SESSION['taskid']."' and property='Display Check'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Display Check','".$_POST['display_check']."')";
		$conn->query($sql);
	}
}

//GPS Check
if(isset($_POST['gps_check']))
{
	
	$sal="Select * from report where property='Gps Check' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['gps_check'])
		{
		$sql="Update report set property_value='".$_POST['gps_check']."' where taskid='".$_SESSION['taskid']."' and property='Gps Check'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Gps Check','".$_POST['gps_check']."')";
		$conn->query($sql);
	}
}

//Camera Check
if(isset($_POST['camera_check']))
{
	
	$sal="Select * from report where property='Camera Check' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['camera_check'])
		{
		$sql="Update report set property_value='".$_POST['camera_check']."' where taskid='".$_SESSION['taskid']."' and property='Camera Check'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Camera Check','".$_POST['camera_check']."')";
		$conn->query($sql);
	}
}

//Automated Check
if(isset($_POST['automated_check']))
{
	
	$sal="Select * from report where property='Automated Check' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['automated_check'])
		{
		$sql="Update report set property_value='".$_POST['automated_check']."' where taskid='".$_SESSION['taskid']."' and property='Automated Check'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Automated Check','".$_POST['automated_check']."')";
		$conn->query($sql);
	}
}

//Sensor Check
if(isset($_POST['sensor_check']))
{
	
	$sal="Select * from report where property='Sensor Check' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['sensor_check'])
		{
		$sql="Update report set property_value='".$_POST['sensor_check']."' where taskid='".$_SESSION['taskid']."' and property='Sensor Check'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Sensor Check','".$_POST['sensor_check']."')";
		$conn->query($sql);
	}
}

//Warrenty Charger Check
if(isset($_POST['warrenty_charger']))
{
	
	$sal="Select * from report where property='Warrenty Charger' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['warrenty_charger'])
		{
		$sql="Update report set property_value='".$_POST['warrenty_charger']."' where taskid='".$_SESSION['taskid']."' and property='Warrenty Charger'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Warrenty Charger','".$_POST['warrenty_charger']."')";
		$conn->query($sql);
	}
}
//Headphone Cover Check
if(isset($_POST['headphone_cover']))
{
	$sal="Select * from report where property='Headphone Cover' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['headphone_cover'])
		{
		$sql="Update report set property_value='".$_POST['headphone_cover']."' where taskid='".$_SESSION['taskid']."' and property='Headphone Cover'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Headphone Cover','".$_POST['headphone_cover']."')";
		$conn->query($sql);
	}
}


//Ads On Check
if(isset($_POST['ADD-ONs']))
{
	$sal="Select * from report where property='ADD-ONs' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['ADD-ONs'])
		{
		$sql="Update report set property_value='".$_POST['ADD-ONs']."' where taskid='".$_SESSION['taskid']."' and property='ADD-ONs'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','ADD-ONs','".$_POST['ADD-ONs']."')";
		$conn->query($sql);
	}
}

header('location:report-form.php?#Step2');

}
	
	// IMAGE UPLOADING SCRATCHES Cosmetic
	if(isset($_POST['save_cosmetic_scratches']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Cosmetic Scratches','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#CosmeticScratches');	
		
	}
	// IMAGE UPLOADING SCRATCHES Cosmetic
	if(isset($_POST['remove_cosmetic_scratches']))
	{
		
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
	
header('location:report-form.php?#CosmeticScratches');	
		
	}	
	
	
	
	
	// IMAGE UPLOADING DENTS
	if(isset($_POST['save_dents']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Dents','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#dent');	
	}
	// IMAGE Removing DENTS
	if(isset($_POST['remove_dents']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		
header('location:report-form.php?#dent');	
		
	}
	
	
	
	
	// IMAGE UPLOADING Discolors
	if(isset($_POST['save_discoloration']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Discoloration','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#dent');	
	}
	// IMAGE Removing Discolors
	if(isset($_POST['remove_discoloration']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#dent');	
		
	}
	
	
	
	// IMAGE UPLOADING SCUFFS
	if(isset($_POST['save_scuffs']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Scuffs','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#scuffs');	
	}
	// IMAGE Removing Scuffs
	if(isset($_POST['remove_scuffs']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#scuffs');	
		
	}
		
	
	// IMAGE UPLOADING BENDS
	if(isset($_POST['save_bends']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Bends','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#bends');	
	}
	// IMAGE Removing BENDS
	if(isset($_POST['remove_bends']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#bends');	
		
	}
		
	// IMAGE UPLOADING Cracks
	if(isset($_POST['save_cracks']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Cracks','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#cracks');	
	}
	// IMAGE Removing BENDS
	if(isset($_POST['remove_cracks']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#cracks');	
		
	}
		
		
		
		
	// IMAGE UPLOADING Faded
	if(isset($_POST['save_faded']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Faded','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#faded');	
	}
	// IMAGE Removing Faded
	if(isset($_POST['remove_faded']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#faded');	
		
	}
		
		
		
		
		
	// IMAGE UPLOADING Broken
	if(isset($_POST['save_broken']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Broken','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#broken');	
	}
	// IMAGE Removing Broken
	if(isset($_POST['remove_broken']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#broken');	
		
	}
		
		
		
		
		
		
	// IMAGE UPLOADING Broken
	if(isset($_POST['save_torn']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Torn','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#torn');	
	}
	// IMAGE Removing Broken
	if(isset($_POST['remove_torn']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#torn');	
		
	}
		
		
		
		
	
	
	// IMAGE UPLOADING Front Picture
	if(isset($_POST['save_fp']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Front-Picture','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#frontpic');	
	}
	// IMAGE Removing Discolors
	if(isset($_POST['remove_fp']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#frontpic');	
		
	}
	
	// IMAGE UPLOADING Back Picture
	if(isset($_POST['save_bp']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Back-Picture','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#backpic');	
	}
	// IMAGE Removing Back Picture
	if(isset($_POST['remove_bp']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#backpic');	
		
	}
	
	// IMAGE UPLOADING Left Picture
	if(isset($_POST['save_ls']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','LS-Picture','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#lspic');	
	}
	// IMAGE Removing Leftside Picture
	if(isset($_POST['remove_ls']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#lspic');	
		
	}
	
	// IMAGE UPLOADING Right Picture
	if(isset($_POST['save_rs']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','RS-Picture','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#lspic');	
	}
	// IMAGE Removing Right side Picture
	if(isset($_POST['remove_rs']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#rspic');	
	}
	
	
	
	// IMAGE UPLOADING Top SIde Picture
	if(isset($_POST['save_ts']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','TS-Picture','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#tspic');	
	}
	// IMAGE Removing Top side Picture
	if(isset($_POST['remove_ts']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#tspic');	
	}
		
	
	
	// IMAGE UPLOADING Bottom SIde Picture
	if(isset($_POST['save_bs']))
	{
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
	$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','BS-Picture','$picname')";
		$conn->query($sql);
	
	
header('location:report-form.php?#bspic');	
	}
	// IMAGE Removing Top side Picture
	if(isset($_POST['remove_ts']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#bspic');	
	}
	
	
	// IMAGE UPLOADING Size
	if(isset($_POST['save_size']))
	{
		
		if(!empty($_FILES['pic']['name']))
		{
		
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','True_To_Size','$picname')";
		$conn->query($sql);
		
		}
		if(isset($_POST['fheight']))
		{
			$height=$_POST['fheight'];
			
			$sal="Select * from report where property='FHeight' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['fheight'])
		{
		$sql="Update report set property_value='".$_POST['fheight']."' where taskid='".$_SESSION['taskid']."' and property='FHeight'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','FHeight','".$_POST['fheight']."')";
		$conn->query($sql);
	}
			
			
		}
		if(isset($_POST['waist']))
		{
	$width=$_POST['waist'];
			
			$sal="Select * from report where property='Waist' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['waist'])
		{
		$sql="Update report set property_value='".$_POST['waist']."' where taskid='".$_SESSION['taskid']."' and property='Waist'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Waist','".$_POST['waist']."')";
		$conn->query($sql);
	}
		}
		if(isset($_POST['fweight']))
		{
			$length=$_POST['fweight'];
					
			$sal="Select * from report where property='FWeight' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['fweight'])
		{
		$sql="Update report set property_value='".$_POST['fweight']."' where taskid='".$_SESSION['taskid']."' and property='FWeight'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','FWeight','".$_POST['fweight']."')";
		$conn->query($sql);
	}
		
		}
		if(isset($_POST['collar']))
		{
			$length=$_POST['collar'];
					
			$sal="Select * from report where property='Collar' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['collar'])
		{
		$sql="Update report set property_value='".$_POST['collar']."' where taskid='".$_SESSION['taskid']."' and property='Collar'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Collar','".$_POST['collar']."')";
		$conn->query($sql);
	}
		
		}
		if(isset($_POST['tag']))
		{
			$length=$_POST['tag'];
					
			$sal="Select * from report where property='Tag' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['tag'])
		{
		$sql="Update report set property_value='".$_POST['tag']."' where taskid='".$_SESSION['taskid']."' and property='Tag'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Tag','".$_POST['tag']."')";
		$conn->query($sql);
	}
		
		}
		if(isset($_POST['size']))
		{
			$length=$_POST['size'];
					
			$sal="Select * from report where property='Size' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['size'])
		{
		$sql="Update report set property_value='".$_POST['size']."' where taskid='".$_SESSION['taskid']."' and property='Size'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Size','".$_POST['size']."')";
		$conn->query($sql);
	}
		
		}
	
	
header('location:report-form.php?#size');	
	}
	
	
	
	
	
	
	// IMAGE UPLOADING Dimentions & DATA
	if(isset($_POST['save_dimention']))
	{
		
		if(!empty($_FILES['pic']['name']))
		{
			
		
		$picname=rand().$_FILES['pic']['name'];
		$folder="../../report-pics/";
		move_uploaded_file($_FILES['pic']['tmp_name'],$folder.$picname);
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','True_To_Dimention','$picname')";
		$conn->query($sql);
		
		}
		if(isset($_POST['height']))
		{
			$height=$_POST['height'];
			
			$sal="Select * from report where property='Height' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['height'])
		{
		$sql="Update report set property_value='".$_POST['height']."' where taskid='".$_SESSION['taskid']."' and property='Height'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Height','".$_POST['height']."')";
		$conn->query($sql);
	}
			
			
		}
		if(isset($_POST['width']))
		{
	$width=$_POST['width'];
			
			$sal="Select * from report where property='Width' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['width'])
		{
		$sql="Update report set property_value='".$_POST['width']."' where taskid='".$_SESSION['taskid']."' and property='Width'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Width','".$_POST['width']."')";
		$conn->query($sql);
	}
		}
		if(isset($_POST['length']))
		{
			$length=$_POST['length'];
					
			$sal="Select * from report where property='Length' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['length'])
		{
		$sql="Update report set property_value='".$_POST['length']."' where taskid='".$_SESSION['taskid']."' and property='Length'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Length','".$_POST['length']."')";
		$conn->query($sql);
	}
		
		}
	
	
header('location:report-form.php?#dimension');	
	}
	
	
	
	// IMAGE Removing Dimension Picture
	if(isset($_POST['remove_dimention']))
	{
		$folder="../../report-pics/";
		$pic=$folder.$_POST['pic'];
		unlink($pic);
		$sql="Delete from report where id='".$_POST['id']."'";
		$conn->query($sql);
		header('location:report-form.php?#bspic');	
	}
	
	
	
	// Saving the working  detials
	
//Working Test Script 
if(isset($_POST['working_c']))
{
	
	$sal="Select * from report where property='Working' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['Working'])
		{
		$sql="Update report set property_value='".$_POST['Working']."' where taskid='".$_SESSION['taskid']."' and property='Working'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Working','".$_POST['Working']."')";
		$conn->query($sql);
	}
	
		header('location:report-form.php?#workingc');	
}
		
//Diagnostic Test Script 
if(isset($_POST['diagnostic_network']))
{
	
	$sal="Select * from report where property='Diagnostic Network' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['diagnostic_network'])
		{
		$sql="Update report set property_value='".$_POST['diagnostic_network']."' where taskid='".$_SESSION['taskid']."' and property='Diagnostic Network'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Diagnostic Network','".$_POST['diagnostic_network']."')";
		$conn->query($sql);
	}
	
		header('location:report-form.php?#diagnostic_network');	
}
			
//Diagnostic Test Script 
if(isset($_POST['diagnostic_audio']))
{
	
	$sal="Select * from report where property='Diagnostic Audio' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['diagnostic_audio'])
		{
		$sql="Update report set property_value='".$_POST['diagnostic_audio']."' where taskid='".$_SESSION['taskid']."' and property='Diagnostic Audio'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Diagnostic Audio','".$_POST['diagnostic_audio']."')";
		$conn->query($sql);
	}
	
		header('location:report-form.php?#diagnostic_audio');	
}

			
//Diagnostic GPS Test Script 
if(isset($_POST['diagnostic_gps']))
{
	
	$sal="Select * from report where property='Diagnostic Gps' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['diagnostic_gps'])
		{
		$sql="Update report set property_value='".$_POST['diagnostic_gps']."' where taskid='".$_SESSION['taskid']."' and property='Diagnostic Gps'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Diagnostic Gps','".$_POST['diagnostic_gps']."')";
		$conn->query($sql);
	}
	
		header('location:report-form.php?#diagnostic_gps');	
}
	
	
//Diagnostic Screen Test Script 
if(isset($_POST['diagnostic_battery']))
{
	
	$sal="Select * from report where property='Diagnostic Battery' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['diagnostic_battery'])
		{
		$sql="Update report set property_value='".$_POST['diagnostic_battery']."' where taskid='".$_SESSION['taskid']."' and property='Diagnostic Battery'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Diagnostic Battery','".$_POST['diagnostic_battery']."')";
		$conn->query($sql);
	}
	
		header('location:report-form.php?#diagnostic_battery');	
}
	
	
//Diagnostic Screen Test Script 
if(isset($_POST['diagnostic_display']))
{
	
	$sal="Select * from report where property='Diagnostic Display' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['diagnostic_display'])
		{
	echo	$sql="Update report set property_value='".$_POST['diagnostic_display']."' where taskid='".$_SESSION['taskid']."' and property='Diagnostic Display'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Diagnostic Display','".$_POST['diagnostic_display']."')";
		$conn->query($sql);
	}
	
		header('location:report-form.php?#diagnostic_screen');	
}
	
	
	
//Diagnostic Camera Test Script 
if(isset($_POST['diagnostic_camera']))
{
	
	$sal="Select * from report where property='Diagnostic Camera' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['diagnostic_camera'])
		{
		$sql="Update report set property_value='".$_POST['diagnostic_camera']."' where taskid='".$_SESSION['taskid']."' and property='Diagnostic Camera'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Diagnostic Camera','".$_POST['diagnostic_camera']."')";
		$conn->query($sql);
	}
	
		header('location:report-form.php?#diagnostic_camera');	
}

	
//Diagnostic Camera Test Script 
if(isset($_POST['diagnostic_automatic']))
{
	
	$sal="Select * from report where property='Diagnostic Automatic' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['diagnostic_automatic'])
		{
		$sql="Update report set property_value='".$_POST['diagnostic_automatic']."' where taskid='".$_SESSION['taskid']."' and property='Diagnostic Automatic'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Diagnostic Automatic','".$_POST['diagnostic_automatic']."')";
		$conn->query($sql);
	}
	
		header('location:report-form.php?#diagnostic_automatic');	
}


	
//Diagnostic Sensor Test Script 
if(isset($_POST['diagnostic_sensor']))
{
	
	$sal="Select * from report where property='Diagnostic Sensor' and taskid='".$_SESSION['taskid']."'";
	$res=$conn->query($sal);
	if($res->num_rows>0)
	{
		$row=$res->fetch_assoc();
		if($row['property_value']!=$_POST['diagnostic_sensor'])
		{
		$sql="Update report set property_value='".$_POST['diagnostic_sensor']."' where taskid='".$_SESSION['taskid']."' and property='Diagnostic Sensor'";
		$conn->query($sql);
		}
	}else{
		
		$sql="Insert into report(taskid,property,property_value) value('".$_SESSION['taskid']."','Diagnostic Sensor','".$_POST['diagnostic_sensor']."')";
		$conn->query($sql);
	}
	
		header('location:report-form.php?#diagnostic_sensor');	
}





	
	
	if(isset($_POST['final']))
	{
		$final_adjusted_score='';
		include "manage-score.php";
		date_default_timezone_set("Asia/Karachi");
		$dt=date('Y-m-d h:i:sa');
		$sa="Update tasks set status='Underverification',rating='$final_adjusted_score',submission_date='$dt' where taskid='".$_SESSION['taskid']."'";
		if($conn->query($sa))
		{
			
			$usr="Select mobile,id,email from user where id='".$_POST['uid']."'";
			$rt=$conn->query($usr);
			$ro=$rt->fetch_assoc();
						
						$tid=$_SESSION['taskid'];
				
				//SMS OTP
$msisdn = "923432435000";
$password = "thisisalongenoughpassword123!";

$url = "https://telenorcsms.com.pk:27677/corporate_sms2/api/auth.jsp?msisdn=".$msisdn."&password=".$password;
$xmlResponseString = file_get_contents($url);
$xmlResponse = simplexml_load_string($xmlResponseString);
$array=json_decode(json_encode((array)$xmlResponse),True);
//$sessionID = $xmlResponse->corpsms->data;
print_r($array['data']);
$msg="Your Chekmate inspection report for Order No # $tid is ready to be viewed in the link. :(https://chekmate.worldviewit.com?order)";
$mobile=$ro['mobile'];
$url2 = "https://telenorcsms.com.pk:27677/corporate_sms2/api/sendsms.jsp?session_id=".$array['data']."&mask=CHEKMATE&to=".$mobile."&text=".urlencode($msg);
$xmlResponseString2 = file_get_contents($url2);
$xmlResponse2 = simplexml_load_string($xmlResponseString2);

			
							
	$to = $ro['email']; 
$from = 'chekmate@worldviewit.com'; 
$fromName = "Chekmate"; 
 
$subject = "Chekmate Notification"; 
 
			$htmlContent = ' 
    <!DOCTYPE html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
@media screen and (max-width: 786px) {
  .body {
    margin-left: 0px !important;
  }
  .img01 
  {
  width: 270px !important;
  height: 53px !important;
  }
  .img02
  {
  width: 270px !important;
  height: 53px !important;
  }
  .para
  {
  font-size: 11px !important;
  margin-left: 12px !important;
  }
  
}
</style>
</head>

<body class="body" style="width: 765px;margin-left: 235px;margin-top: 120px;"> 
<div style="margin: 50px;">
<a href="https://chekmate.worldviewit.com">
<img class="img01" src="https://www.worldviewit.com/chekmate/mail/Header.png" width="712" height="140px" alt="Chekmate Logo" style="display:block" title="Logo"> </a>
<p class="para" style="margin-top: 42px;margin-left: 35px;font-size: 14px;">
Your Chekmate inspection report for Order No # '.$tid.' is ready to be viewed in the link. :(https://worldviewit.com/checkmate/?order)</p>
</div>
<footer>
<div style="margin: 50px;">
<img class="img02" src="https://www.worldviewit.com/chekmate/mail/Pattiwithtext.png" width="712" height="140px" alt="Chekmate Footer" style="display:block !important; width:712px; height:140px;" title="Email Footer">
</div>
</footer>
</body>
</html>'; 
			
	// Set content-type header for sending HTML email 
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
 // Additional headers 
$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 		
			
		// Send email 
if(mail($to, $subject, $htmlContent, $headers)){ 
   // echo 'Email has sent successfully.'; 
}else{ 
 //  echo 'Email sending failed.'; 
}
			
			
			unset($_SESSION['taskid']);
			header('location:linksummary.php');
		}else{
			
		header('location:report-form.php?#diagnostic_audio');
		}
		
	}
	
	
}
?>