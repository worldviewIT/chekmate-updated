<?php
ob_start();
?>
<?php 
Session_Start();
if(!isset($_SESSION['rider']))
header("location:\logout.php");

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChekMate Report Submission </title>
    <!-- Core CSS - Include with every page -->
    <link href="../assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="../assets/css/style.css" rel="stylesheet" />
    <link href="../assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="../assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
	<style>
#dept_anchor{
		text-decoration:none;
	}	
#dept:hover{
	opacity:0.8;
	color:black;
}
#page-wrapper{
  height:100px;
  width:auto;
  overflow-y: scroll;
}
	</style>
	

   </head>
<body>
    <div id="wrapper">
    <!--  wrapper -->
      <?php include "header.php" ?> 
	  
                     
        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
				<?php   
				   include "sidebar.php";
				  ?>           
            <!-- end sidebar-collapse -->
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

          
                <!--quick info section -->
			
                <!--end quick info section -->
           <div class="row">
              
				<div class="panel-heading" align=center>
                        <h2 class="panel-titl" style="color:green;"></h2>
                </div>
				            </div>
                       
                       
				<div class="panel-heading" align=center>
                        <h2 class="panel-titl">Tasks Report</h2>
                    </div>
			<?php
			
			if(isset($_POST['tid']))
			{
			$_SESSION['taskid']=$_POST['tid'];
			}
			if(!isset($_SESSION['taskid']))
			{
			$_SESSION['taskid']=$_POST['tid'];
			}
			$producttype='';
			$ordertype='';
			$diagnosticstest='';
			$workingtest='';
			$cosmetictest='';
			$turn_on='';
			$fully_functional='';
			$repair_history='';
			$warrenty='';
			$battery_check='';
			$network_check='';
			$audio_check='';
			$display_check='';
			$gps_check='';
			$camera_check='';
			$automated_check='';
			$sensor_check='';
			$warrenty_charger='';
			$headphone_cover='';
			$productname='';
			$adds_on='';
			$working='';
			$diagnostic_network='';
			$diagnostic_automatic="";
			$diagnostic_battery="";
			$diagnostic_camera="";
			$diagnostic_display="";
			$diagnostic_gps="";
			$diagnostic_sensor="";
			$uid='';
			$height='';
			$width='';
			$length='';
			$diagnostic_audio='';
			$fheight='';
			$fweight='';
			$tag='';
			$size='';
			$collar='';
			$waist='';
			$sli='';
	$sql="Select * from tasks where taskid='".$_SESSION['taskid']."'";
	$result=$conn->query($sql);
	if($result->num_rows>0)
	{
		$row=$result->fetch_assoc();
		$uid=$row['userid'];
		$producttype=$row['product_type'];
		$productname=$row['product_name'];
		
		$fd="Select * from report where taskid='".$_SESSION['taskid']."'";
		$res=$conn->query($fd);
		if($res->num_rows>0)
		{
			while($rrow=$res->fetch_assoc())
			{
				if($rrow['property']=='Order Type')
					$ordertype=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostics Test')
					$diagnosticstest=$rrow['property_value'];
				
				if($rrow['property']=='Cosmetic Test')
					$cosmetictest=$rrow['property_value'];
				
				if($rrow['property']=='Working Conditions')
					$workingtest=$rrow['property_value'];
				
				if($rrow['property']=='Turn On')
					$turn_on=$rrow['property_value'];
				
				if($rrow['property']=='Fully Functional')
					$fully_functional=$rrow['property_value'];
				
				if($rrow['property']=='Repair History')
					$repair_history=$rrow['property_value'];
				
				if($rrow['property']=='Warrenty')
					$warrenty=$rrow['property_value'];
				
				if($rrow['property']=='Battery Check')
					$battery_check=$rrow['property_value'];
				
				if($rrow['property']=='Network Check')
					$network_check=$rrow['property_value'];
				
				if($rrow['property']=='Audio Check')
					$audio_check=$rrow['property_value'];
				
				if($rrow['property']=='Display Check')
					$display_check=$rrow['property_value'];
				
				if($rrow['property']=='Gps Check')
					$gps_check=$rrow['property_value'];
				
				if($rrow['property']=='Camera Check')
					$camera_check=$rrow['property_value'];
				
				if($rrow['property']=='Automated Check')
					$automated_check=$rrow['property_value'];
				
				if($rrow['property']=='Sensor Check')
					$sensor_check=$rrow['property_value'];
				
				if($rrow['property']=='Warrenty Charger')
					$warrenty_charger=$rrow['property_value'];
				
				if($rrow['property']=='Headphone Cover')
					$headphone_cover=$rrow['property_value'];
				if($rrow['property']=='ADD-ONs')
					$adds_on=$rrow['property_value'];	
				if($rrow['property']=='Working')
					$working=$rrow['property_value'];	
				
				if($rrow['property']=='Diagnostic Network')
					$diagnostic_network=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Audio')
					$diagnostic_audio=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Battery')
					$diagnostic_battery=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Display')
					$diagnostic_display=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Gps')
					$diagnostic_gps=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Sensor')
					$diagnostic_sensor=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Camera')
					$diagnostic_camera=$rrow['property_value'];
				
				if($rrow['property']=='Diagnostic Automatic')
					$diagnostic_automatic=$rrow['property_value'];
				
				if($rrow['property']=='Height')
					$height=$rrow['property_value'];
				
				if($rrow['property']=='Width')
					$width=$rrow['property_value'];
				
				if($rrow['property']=='Length')
					$length=$rrow['property_value'];
				
				if($rrow['property']=='FWeight')
					$fweight=$rrow['property_value'];
				
				if($rrow['property']=='FHeight')
					$fheight=$rrow['property_value'];
				
				if($rrow['property']=='Waist')
					$waist=$rrow['property_value'];
				
				if($rrow['property']=='Tag')
					$tag=$rrow['property_value'];
				
				if($rrow['property']=='Collar')
					$collar=$rrow['property_value'];
				
				if($rrow['property']=='Size')
					$size=$rrow['property_value'];
				
				
			}
			
			
		}
		
		// use of explode
$string = $row['task_condition'];
$sli = explode (",", $string); 

		
	}

			?>
					
				<div class="task col-lg-12">
				<h4><b>Rider</b></h4>
					<label class="text-dark font-weight-bold">Seller Listed Issues:
					<br>
					<?php foreach($sli as $sl){
					echo '&nbsp &nbsp ' . $sl .'<br>';	
					}?>
					</label>
					
					<br>
					<label class="text-dark font-weight-bold">Product Type:</label><br>
					
				<select class="form-control">
					<option> <?php echo $producttype;?> </option>
				</select>
				<label class="text-dark font-weight-bold">Model:</label><br>
					
				<select class="form-control">
					<option> <?php echo $productname;?> </option>
				</select>
				<form action="process.php" method="post">
				<label class="text-dark font-weight-bold">Order Type:</label><br>
				<select class="form-control" name="ordertype" required>
					<?php 
					if($ordertype!="")
					{
						echo "<option>$ordertype</option>
						<option value=''>-------------</option>";
					}
					?>
					<option>Pre Loved</option>
					<option>New</option>
				</select>
				
				<?php
				if($producttype=='Mobile Device' || $producttype=='Laptops & Computers')
				{	
				?>
				<h4><b> Diagnose Test</b></h4>
				<label class="text-dark font-weight-bold">Additional Issues:</label><br>
				<select class="form-control" name="Diagnostics_Test" required>
					<?php 
					if($diagnosticstest!="")
					{
						echo "<option>$diagnosticstest</option>
						<option value=''>-------------</option>";
					}
					?>
					<?php
					include "option.php";
					?>
				</select>
				<?php
				}
				?>
				<h4><b> Cosmetic Test</b></h4>
				<label class="text-dark font-weight-bold">Additional Issues:</label><br>
				<select class="form-control" name="Cosmetic_Test" required>
				<?php 
					if($cosmetictest!="")
					{
						echo "<option>$cosmetictest</option>
						<option value=''>-------------</option>";
					}
					?>
				<?php
					include "option.php";
				?>
				</select>
				
				<h4><b> Working Conditions</b></h4>
				<label class="text-dark font-weight-bold">Additional Issues:</label><br>
				<select class="form-control" name="Working_Test" required>
					<?php 
					if($workingtest!="")
					{
						echo "<option>$workingtest</option>
						<option value=''>-------------</option>";
					}
					?>
					<?php
					include "option.php";
					?>
				</select>
				<br>
				<input type="submit" name="step1" class="btn btn-info" value="Save Condition Score" id="Step1">
				</form>	
				<br>



		
	<div class="col-sm-12 col-md-12">		
			<hr>

<h3 class="text-dark font-weight-bold">Cosmetic Condition</h3>
<div class="table table-responsive">
<table class="table table-hovered" >
<tr>
	<td>
<form action="process.php" method="post" enctype="multipart/form-data" style="float:left;">			
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
FRONT PICTURE
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_fp" id="frontpic">
</form>
	</td>
	<td>
<form action="process.php" method="post" enctype="multipart/form-data">			
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
BACK PICTURE
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_bp" id="backpic">
</form>
	</td>
	<td>
<form action="process.php" method="post" enctype="multipart/form-data">			
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
LeftSide PICTURE
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_ls" id="lspic">
</form>
	</td>
	<td>
<form action="process.php" method="post" enctype="multipart/form-data">			
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
RightSide PICTURE
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_rs" id="rspic">
</form>
	</td>
	<td>
<form action="process.php" method="post" enctype="multipart/form-data">			
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
TopSide PICTURE
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_ts" id="tspic">
</form>
	</td>
	<td>
<form action="process.php" method="post" enctype="multipart/form-data">			
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
BottomSide PICTURE
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_bs" id="bspic">
</form>
	</td>
	</tr>
	</table>
	</div>
</div>
	<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
				$sqa="Select * from report where taskid='".$_SESSION['taskid']."' and (property='Front-Picture' || 
				property='Back-Picture' || property='LS-Picture' || property='RS-Picture' || property='TS-Picture' || property='BS-Picture')";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{
					while($crow=$re->fetch_assoc())
					{
						?>
				<div class="col-sm-4 col-md-4">
				<img src="../../report-pics/<?php echo $crow['property_value'];?>" height="200px" width="200px">
				<form action="process.php" method="post">
				<input type="hidden" name="pic" value="<?php echo $crow['property_value'];?>">
				<input type="hidden" name="id" value="<?php echo $crow['id'];?>">
				<input type="submit" class="btn btn-xs btn-danger" name="remove_discoloration" value="
				Remove <?php echo $crow['property'];?> Picture">
				</form>
				</div>
						<?php
					}
				}
			?>
		

	</div>
			

				
				<center><h4><b>Working Condition</b></h4></center>
				<form action="process.php" method="post">
				
				<label class="text-dark font-weight-bold">Does it turn on?</label><br>
				<input type="radio" name="turn_on" style="float:left" value="Yes" <?php if($turn_on=='Yes') echo 'checked';?>>
				&nbsp <b>yes</b>
				&nbsp &nbsp &nbsp &nbsp <input type="radio" name="turn_on" value="No" <?php if($turn_on=='No') echo 'checked';?>>
				<b>No</b><br><br>
				
				<label class="text-dark font-weight-bold">Fully functional and/or everything lights up correctly?</label><br>
				<input type="radio" name="fully_functional" value="Yes" style="float:left" <?php if($fully_functional=='Yes') echo 'checked';?>> 
				&nbsp <b>yes</b>
				&nbsp &nbsp &nbsp &nbsp <input type="radio" name="fully_functional" value="No" <?php if($fully_functional=='No') echo 'checked';?>>
				<b>No</b><br><br>
				
				<label class="text-dark font-weight-bold">Any repair history?</label><br>
				<input type="radio" style="float:left" name="repair_history" value="Yes" <?php if($repair_history=='Yes') echo 'checked';?>>
				&nbsp <td><b>yes</b></td>
				 &nbsp &nbsp &nbsp &nbsp <input type="radio" name="repair_history" value="No" <?php if($repair_history=='No') echo 'checked';?>>
				<b>No</b><br><br>
				
				<label class="text-dark font-weight-bold">Comes with warranty?</label><br>
				<input type="radio" style="float:left" name="warrenty" value="Yes" <?php if($warrenty=='Yes') echo 'checked';?>>
				&nbsp <td><b>yes</b></td>
				 &nbsp &nbsp &nbsp &nbsp <input type="radio" name="warrenty" value="No" <?php if($warrenty=='No') echo 'checked';?>>
				<b>No</b><br><br>
				
				
				<?php
				if($producttype=='Mobile Device' || $producttype=='Laptops & Computers')
				{
				?>
				<center><h4><b>DEEP DIAGNOSTICS</b></h4></center>
				
				
				
				<label class="text-dark font-weight-bold">Battery Check?</label><br>
				<input type="radio" style="float:left" name="battery_check" value="Yes" <?php if($battery_check=='Yes') echo 'checked';?>>
				&nbsp <b>Pass</b>
				 &nbsp &nbsp &nbsp &nbsp <input type="radio" name="battery_check" value="No" <?php if($battery_check=='No') echo 'checked';?>>
				<b>Fail</b><br><br>

				<label class="text-dark font-weight-bold">Network Check?</label><br>
				<input type="radio" style="float:left" name="network_check" value="Yes" <?php if($network_check=='Yes') echo 'checked';?>>
				&nbsp <b>Pass</b>
				 &nbsp &nbsp &nbsp &nbsp <input type="radio" name="network_check" value="No" <?php if($network_check=='No') echo 'checked';?>>
				<b>Fail</b><br><br>
				
				<label class="text-dark font-weight-bold">Audio Check?</label><br>
				<input type="radio" style="float:left" name="audio_check" value="Yes" <?php if($audio_check=='Yes') echo 'checked';?>>
				&nbsp <td><b>Pass</b></td>
				 &nbsp &nbsp &nbsp &nbsp <input type="radio" name="audio_check" value="No" <?php if($audio_check=='No') echo 'checked';?>>
				<td><b>Fail</b></td><br><br>
				
				<label class="text-dark font-weight-bold">Display Check?</label><br>
				<input type="radio" style="float:left" name="display_check" value="Yes" <?php if($display_check=='Yes') echo 'checked';?>>
				&nbsp <td><b>Pass</b></td>
				 &nbsp &nbsp &nbsp &nbsp <input type="radio" name="display_check" value="No" <?php if($display_check=='No') echo 'checked';?>>
				<td><b>Fail</b></td><br><br>
		
				<label class="text-dark font-weight-bold">GPS Check?</label><br>
				<input type="radio" style="float:left" name="gps_check" value="Yes" <?php if($gps_check=='Yes') echo 'checked';?>>
				&nbsp <td><b>Pass</b></td>
				 &nbsp &nbsp &nbsp &nbsp <input type="radio" name="gps_check" value="No" <?php if($gps_check=='No') echo 'checked';?>>
				<td><b>Fail</b></td><br><br>
				
				<label class="text-dark font-weight-bold">Camera Check?</label><br>
				<input type="radio" style="float:left" name="camera_check" value="Yes" <?php if($camera_check=='Yes') echo 'checked';?>>
				&nbsp <td><b>Pass</b></td>
				 &nbsp &nbsp &nbsp &nbsp <input type="radio" name="camera_check" value="No" <?php if($camera_check=='No') echo 'checked';?>>
				<td><b>Fail</b></td><br><br>
				
				<label class="text-dark font-weight-bold">Automated Check?</label><br>
				<input type="radio" style="float:left" name="automated_check" value="Yes" <?php if($automated_check=='Yes') echo 'checked';?>>
				&nbsp <td><b>Pass</b></td>
				 &nbsp &nbsp &nbsp &nbsp <input type="radio" name="automated_check" value="No" <?php if($automated_check=='No') echo 'checked';?>>
				<td><b>Fail</b></td><br><br>
				
				<label class="text-dark font-weight-bold">Sensor Check?</label><br>
				<input type="radio" style="float:left" name="sensor_check" value="Yes" <?php if($sensor_check=='Yes') echo 'checked';?>>
				&nbsp <td><b>Pass</b></td>
				 &nbsp &nbsp &nbsp &nbsp <input type="radio" name="sensor_check" value="No" <?php if($sensor_check=='No') echo 'checked';?>>
				<td><b>Fail</b></td><br><br>
				<?php
				}
				?>
				
				<center><h4><b>Adds ONs</b></h4></center>
				
				<textarea class="form-control" placeholder="Write ADD-ONs" name="ADD-ONs"><?php echo $adds_on; ?></textarea>
		
				<input type="submit" name="step2" value="Save Adds-On" class="btn btn-info" id="Step2">
				</form>
				
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		<?php
				if($producttype!='Mobile Device')
				{
				?>
		
				
				<center><h4><b>Dimension & Specification</b></h4></center>
				<form action="process.php" method="post" enctype="multipart/form-data">
				
				<label class="text-dark font-weight-bold">Height</label><br>
				<input type="text" name="height" class="form-control" style="float:left" value="<?php if($height!='') echo $height;?>">
				<br><br>
				<label class="text-dark font-weight-bold">Width</label><br>
				<input type="text" name="width" class="form-control" style="float:left" value="<?php if($width!='') echo $width;?>">
				<br><br>
				<label class="text-dark font-weight-bold">Length</label><br>
				<input type="text" name="length" class="form-control" style="float:left" value="<?php if($length!='') echo $length;?>">
				<br><br>
				<label class="text-dark font-weight-bold">True To Scale picture</label><br>
				<input type="file" name="pic" style="float:left;" >
				<br><br>
				<input type="submit" name="save_dimention" value="Save Dimentions" class="btn btn-info" id="dimension">
				</form>
		<?php
				}
				?>	
		<?php
				if($producttype=='Fashion,Clothing & Beauty')
				{
				?>
		
				
				<center><h4><b>Size</b></h4></center>
				<form action="process.php" method="post" enctype="multipart/form-data">
				
				<label class="text-dark font-weight-bold">Height</label><br>
				<input type="text" name="fheight" class="form-control" style="float:left" value="<?php if($fheight!='') echo $fheight;?>">
				<br><br>
				<label class="text-dark font-weight-bold">Length/Waist</label><br>
				<input type="text" name="waist" class="form-control" style="float:left" value="<?php if($waist!='') echo $waist;?>">
				<br><br>
				<label class="text-dark font-weight-bold">Collar Size</label><br>
				<input type="text" name="collar" class="form-control" style="float:left" value="<?php if($collar!='') echo $collar;?>">
				<br><br>
				<label class="text-dark font-weight-bold">Weight</label><br>
				<input type="text" name="fweight" class="form-control" style="float:left" value="<?php if($fweight!='') echo $fweight;?>">
				<br><br>
				<label class="text-dark font-weight-bold">Size as per the tag</label><br>
				<input type="text" name="tag" class="form-control" style="float:left" value="<?php if($tag!='') echo $tag;?>">
				<br><br>
				
				<label class="text-dark font-weight-bold">Size True To Description</label><br>
				Yes<input type="radio" name="size" value="Yes" <?php if($size=="Yes") echo "checked";?>>
				No<input type="radio" name="size" value="No" <?php if($size=="No") echo "checked";?>>
				<br><br>
				<label class="text-dark font-weight-bold">True To Scale picture</label><br>
				<input type="file" name="pic" style="float:left;" >
				<br><br>
				<input type="submit" name="save_size" value="Save Dimentions" class="btn btn-info" id="size">
				</form>
		<?php
				}
				?>		
				
				<center><h4><b>Defects/Issues</b></h4></center>
<form action="process.php" method="post" enctype="multipart/form-data">	
<label class="text-dark font-weight-bold">Cosmetic Scratches</label>		
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
Change Picture
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_cosmetic_scratches" id="CosmeticScratches">
</form>
</div>
			<?php
				$sqa="Select * from report where property='Cosmetic Scratches' and taskid='".$_SESSION['taskid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{

					while($crow=$re->fetch_assoc())
					{
						?>
						<div class="col-sm-4 col-md-4">
				<img src="../../report-pics/<?php echo $crow['property_value'];?>" height="200px" width="auto">
						<form action="process.php" method="post">
							<input type="hidden" name="id" value="<?php echo $crow['id'];?>">
							<input type="submit" class="btn btn-xs btn-danger" name="remove_cosmetic_scratches" value="Remove Picture">
						</form>
						</div>
						<?php
					}
				}
			?>
		


		
	<div class="col-sm-12 col-md-12">		
			<hr>

<form action="process.php" method="post" enctype="multipart/form-data">	
				<label class="text-dark font-weight-bold">Dents</label>		
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
Change Picture
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_dents" id="dent">
</form>
</div>
			<?php
				$sqa="Select * from report where property='Dents' and taskid='".$_SESSION['taskid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{

					while($crow=$re->fetch_assoc())
					{
						?>
						<div class="col-sm-4 col-md-4">
				<img src="../../report-pics/<?php echo $crow['property_value'];?>" height="200px" width="auto">
						<form action="process.php" method="post">
						
				<input type="hidden" name="pic" value="<?php echo $crow['property_value'];?>">
							<input type="hidden" name="id" value="<?php echo $crow['id'];?>">
							<input type="submit" class="btn btn-xs btn-danger" name="remove_dents" value="Remove Picture">
						</form>
						</div>
						<?php
					}
				}
			?>
		


		
	<div class="col-sm-12 col-md-12">		
			<hr>

<form action="process.php" method="post" enctype="multipart/form-data">	
<label class="text-dark font-weight-bold">Discoloration</label>		
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
Change Picture
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_discoloration" id="discolor">
</form>
</div>
	<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
				$sqa="Select * from report where property='Discoloration' and taskid='".$_SESSION['taskid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{

					while($crow=$re->fetch_assoc())
					{
						?>
						<div class="col-sm-4 col-md-4">
				<img src="../../report-pics/<?php echo $crow['property_value'];?>" height="200px" width="auto">
						<form action="process.php" method="post">
						
				<input type="hidden" name="pic" value="<?php echo $crow['property_value'];?>">
							<input type="hidden" name="id" value="<?php echo $crow['id'];?>">
							<input type="submit" class="btn btn-xs btn-danger" name="remove_discoloration" value="Remove Picture">
						</form>
						</div>
						<?php
					}
				}
			?>
		

	</div>
			


		
	<div class="col-sm-12 col-md-12">		
			<hr>

<form action="process.php" method="post" enctype="multipart/form-data">	
<label class="text-dark font-weight-bold">Scuffs</label>		
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
Choose Picture
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_scuffs" id="scuffs">
</form>
</div>
	<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
				$sqa="Select * from report where property='Scuffs' and taskid='".$_SESSION['taskid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{

					while($crow=$re->fetch_assoc())
					{
						?>
						<div class="col-sm-4 col-md-4">
				<img src="../../report-pics/<?php echo $crow['property_value'];?>" height="200px" width="auto">
						<form action="process.php" method="post">
						
				<input type="hidden" name="pic" value="<?php echo $crow['property_value'];?>">
							<input type="hidden" name="id" value="<?php echo $crow['id'];?>">
							<input type="submit" class="btn btn-xs btn-danger" name="remove_scuffs" value="Remove Picture">
						</form>
						</div>
						<?php
					}
				}
			?>
		

	</div>

		
		
		
	<div class="col-sm-12 col-md-12">		
			<hr>

<form action="process.php" method="post" enctype="multipart/form-data">	
<label class="text-dark font-weight-bold">Bends</label>		
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
Choose Picture
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_bends" id="bends">
</form>
</div>
	<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
				$sqa="Select * from report where property='Bends' and taskid='".$_SESSION['taskid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{

					while($crow=$re->fetch_assoc())
					{
						?>
						<div class="col-sm-4 col-md-4">
				<img src="../../report-pics/<?php echo $crow['property_value'];?>" height="200px" width="auto">
						<form action="process.php" method="post">
						
				<input type="hidden" name="pic" value="<?php echo $crow['property_value'];?>">
							<input type="hidden" name="id" value="<?php echo $crow['id'];?>">
							<input type="submit" class="btn btn-xs btn-danger" name="remove_bends" value="Remove Picture">
						</form>
						</div>
						<?php
					}
				}
			?>
		

	</div>
			
			
		
		
	<div class="col-sm-12 col-md-12">		
			<hr>

<form action="process.php" method="post" enctype="multipart/form-data">	
<label class="text-dark font-weight-bold">Cracks</label>		
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
Choose Picture
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_cracks" id="cracks">
</form>
</div>
	<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
				$sqa="Select * from report where property='Cracks' and taskid='".$_SESSION['taskid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{

					while($crow=$re->fetch_assoc())
					{
						?>
						<div class="col-sm-4 col-md-4">
				<img src="../../report-pics/<?php echo $crow['property_value'];?>" height="200px" width="auto">
						<form action="process.php" method="post">
						
				<input type="hidden" name="pic" value="<?php echo $crow['property_value'];?>">
							<input type="hidden" name="id" value="<?php echo $crow['id'];?>">
							<input type="submit" class="btn btn-xs btn-danger" name="remove_cracks" value="Remove Picture">
						</form>
						</div>
						<?php
					}
				}
			?>
		

	</div>
					
		
		
	<div class="col-sm-12 col-md-12">		
			<hr>

<form action="process.php" method="post" enctype="multipart/form-data">	
<label class="text-dark font-weight-bold">Faded</label>		
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
Choose Picture
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_faded" id="faded">
</form>
</div>
	<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
				$sqa="Select * from report where property='Faded' and taskid='".$_SESSION['taskid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{

					while($crow=$re->fetch_assoc())
					{
						?>
						<div class="col-sm-4 col-md-4">
				<img src="../../report-pics/<?php echo $crow['property_value'];?>" height="200px" width="auto">
						<form action="process.php" method="post">
						
				<input type="hidden" name="pic" value="<?php echo $crow['property_value'];?>">
							<input type="hidden" name="id" value="<?php echo $crow['id'];?>">
							<input type="submit" class="btn btn-xs btn-danger" name="remove_faded" value="Remove Picture">
						</form>
						</div>
						<?php
					}
				}
			?>
		

	</div>
						
		
		
	<div class="col-sm-12 col-md-12">		
			<hr>

<form action="process.php" method="post" enctype="multipart/form-data">	
<label class="text-dark font-weight-bold">Broken</label>		
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
Choose Picture
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_broken" id="broken">
</form>
</div>
	<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
				$sqa="Select * from report where property='Broken' and taskid='".$_SESSION['taskid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{

					while($crow=$re->fetch_assoc())
					{
						?>
						<div class="col-sm-4 col-md-4">
				<img src="../../report-pics/<?php echo $crow['property_value'];?>" height="200px" width="auto">
						<form action="process.php" method="post">
						
				<input type="hidden" name="pic" value="<?php echo $crow['property_value'];?>">
							<input type="hidden" name="id" value="<?php echo $crow['id'];?>">
							<input type="submit" class="btn btn-xs btn-danger" name="remove_broken" value="Remove Picture">
						</form>
						</div>
						<?php
					}
				}
			?>
		

	</div>
		
	<div class="col-sm-12 col-md-12">		
			<hr>

<form action="process.php" method="post" enctype="multipart/form-data">	
<label class="text-dark font-weight-bold">Torn</label>		
<label class="label" style="cursor: pointer;height:45px; background-color: white; color: black;">
<svg height="12" width="12" style="fill: black;" id="up-svg" viewBox="0 -1 401.52289 401" xmlns="http://www.w3.org/2000/svg"><path d="m370.589844 250.972656c-5.523438 0-10 4.476563-10 10v88.789063c-.019532 16.5625-13.4375 29.984375-30 30h-280.589844c-16.5625-.015625-29.980469-13.4375-30-30v-260.589844c.019531-16.558594 13.4375-29.980469 30-30h88.789062c5.523438 0 10-4.476563 10-10 0-5.519531-4.476562-10-10-10h-88.789062c-27.601562.03125-49.96875 22.398437-50 50v260.59375c.03125 27.601563 22.398438 49.96875 50 50h280.589844c27.601562-.03125 49.96875-22.398437 50-50v-88.792969c0-5.523437-4.476563-10-10-10zm0 0"></path><path d="m376.628906 13.441406c-17.574218-17.574218-46.066406-17.574218-63.640625 0l-178.40625 178.40625c-1.222656 1.222656-2.105469 2.738282-2.566406 4.402344l-23.460937 84.699219c-.964844 3.472656.015624 7.191406 2.5625 9.742187 2.550781 2.546875 6.269531 3.527344 9.742187 2.566406l84.699219-23.464843c1.664062-.460938 3.179687-1.34375 4.402344-2.566407l178.402343-178.410156c17.546875-17.585937 17.546875-46.054687 0-63.640625zm-220.257812 184.90625 146.011718-146.015625 47.089844 47.089844-146.015625 146.015625zm-9.40625 18.875 37.621094 37.625-52.039063 14.417969zm227.257812-142.546875-10.605468 10.605469-47.09375-47.09375 10.609374-10.605469c9.761719-9.761719 25.589844-9.761719 35.351563 0l11.738281 11.734375c9.746094 9.773438 9.746094 25.589844 0 35.359375zm0 0"></path></svg>
Choose Picture
<input type="file" size="100" class="image" name="pic" style="display:none;" required>
</label><input class="btn btn-info btn-xs" type="submit" name="save_torn" id="torn">
</form>
</div>
	<div class="col-sm-12 col-md-12 col-lg-12">
			<?php
				$sqa="Select * from report where property='Torn' and taskid='".$_SESSION['taskid']."' order by id desc";
				$re=$conn->query($sqa);
				if($re->num_rows>0)
				{

					while($crow=$re->fetch_assoc())
					{
						?>
						<div class="col-sm-4 col-md-4">
				<img src="../../report-pics/<?php echo $crow['property_value'];?>" height="200px" width="auto">
						<form action="process.php" method="post">
						
							<input type="hidden" name="pic" value="<?php echo $crow['property_value'];?>">
							<input type="hidden" name="id" value="<?php echo $crow['id'];?>">
							<input type="submit" class="btn btn-xs btn-danger" name="remove_torn" value="Remove Picture">
						</form>
						</div>
						<?php
					}
				}
			?>
		

	</div>
					
		

		<div style="clear:both;">

				<center><h4><b>Working Condition</b></h4></center>
			<form action="process.php" method="post">
				
				<textarea class="form-control" placeholder="Write ADD-ONs" name="Working"><?php echo $working; ?></textarea>
			
				<input type="submit" name="working_c" value="Save Working" class="btn btn-info" id="workingc">
				</form>
				
				<?php
				if($producttype=='Mobile Device' || $producttype=='Laptops & Computers')
				{	
				?>
				
			<center><h4><b>Diagnotics</b></h4></center>
			<form action="process.php" method="post">		
				<?php
				if($network_check=="No")
				{
				?>
				<h5><b>Network:</b></h5>				
				<textarea class="form-control" name="diagnostic_network" id="diagnostic_network"><?php echo $diagnostic_network;?> </textarea> 				
				<?php
				}
				?>
				<?php
				if($audio_check=="No")
				{
				?>
				<h5><b>Audio:</b></h5>
				<textarea class="form-control" name="diagnostic_audio" id="diagnostic_audio"><?php echo $diagnostic_audio;?> </textarea> 
				<!--<input type="submit" class="btn btn-primary" name="save_diagnostic" value="SAVE DIAGNOSTIC OBSERVATION">
				-->
			<?php
				}
				?>
				<?php
				if($display_check=="No")
				{
				?>
				<h5><b>Display:</b></h5>
				<textarea class="form-control" name="diagnostic_display" id="diagnostic_display"><?php echo $diagnostic_display;?> </textarea> 
				<!--<input type="submit" class="btn btn-primary" name="save_diagnostic" value="SAVE DIAGNOSTIC OBSERVATION">
				-->
				<?php
				}
				?>
				<?php
				if($gps_check=="No")
				{
				?>
				<h5><b>GPS:</b></h5>
				<textarea class="form-control" name="diagnostic_gps" id="diagnostic_gps"><?php echo $diagnostic_gps;?> </textarea> 
			<!--	<input type="submit" class="btn btn-primary" name="save_diagnostic" value="SAVE DIAGNOSTIC OBSERVATION">
				-->
				<?php
				}
				?>
				<?php
				if($sensor_check=="No")
				{
				?>
				<h5><b>Censor</b></h5>
				<textarea class="form-control" name="diagnostic_sensor" id="diagnostic_sensor"><?php echo $diagnostic_sensor;?> </textarea> 
			<!--	<input type="submit" class="btn btn-primary" name="save_diagnostic" value="SAVE DIAGNOSTIC OBSERVATION">
				-->
				<?php
				}
				?>
				<?php
				if($battery_check=="No")
				{
				?>
				<h5><b>Battery</b></h5>
				<textarea class="form-control" name="diagnostic_battery" id="diagnostic_battery"><?php echo $diagnostic_battery;?> </textarea> 
				<!--<input type="submit" class="btn btn-primary" name="save_diagnostic" value="SAVE DIAGNOSTIC OBSERVATION">
				-->
				<?php
				}
				?>
				<?php
				if($camera_check=="No")
				{
				?>
				<h5><b>Camera</b></h5>
				<textarea class="form-control" name="diagnostic_camera" id="diagnostic_camera"><?php echo $diagnostic_camera;?> </textarea> 
				<!--<input type="submit" class="btn btn-primary" name="save_diagnostic" value="SAVE DIAGNOSTIC OBSERVATION">
				-->
				<?php
				}
				?>
				<?php
				if($automated_check=="No")
				{
				?>
				<h5><b>Automated </b></h5>
				<textarea class="form-control" name="diagnostic_automatic" id="diagnostic_automatic"><?php echo $diagnostic_automatic;?> </textarea> 
			<!--	<input type="submit" class="btn btn-primary" name="save_diagnostic" value="SAVE DIAGNOSTIC OBSERVATION">
				-->
				<?php
				}
				?>
				<input type="submit" class="btn btn-primary" name="save_diagnostic" value="SAVE DIAGNOSTIC OBSERVATION">	
			</form>
			<?php
				}	
				?>
				
					<form action="process.php" method="post">
					<input type="hidden" name="type" value="<?php echo $producttype;?>">
					<input type="hidden" name="wc" value="<?php echo $workingtest;?>">
					<input type="hidden" name="cc" value="<?php echo $cosmetictest;?>">
					<input type="hidden" name="dc" value="<?php echo $diagnosticstest;?>">
					<input type="hidden" name="uid" value="<?php echo $uid;?>">
				<button type="submit" class="btn btn-primary" name="final" style="width:150px;margin-left:50%;margin-top:-20px;">Save & Close Report</button>
					</form>
</div>
               </div>
        <!-- end page-wrapper -->
	
    </div>
    
 <footer style="background-color:#354c48;color:white;bottom:0px;width:100%;">
        
        <p align=center>Powered By <a style="color:white;" href="https://www.worldviewit.com">WORLDVIEWIT</a></p>
        </footer>
          <!-- end wrapper -->
    <!-- Core Scripts - Include with every page -->
    <script src="../assets/plugins/jquery-1.10.2.js"></script>
    <script src="../assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../assets/plugins/pace/pace.js"></script>
    <script src="../assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="../assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="../assets/plugins/morris/morris.js"></script>
    <script src="../assets/scripts/dashboard-demo.js"></script>
  
</body>

</html>
