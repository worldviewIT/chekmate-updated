<form action="" method="post">
	<select name="type">
		<option>Mobile Device</option>
		<option>Laptops & Computers</option>
		<option>Electronic & Home Applicanes</option>
		<option>Books,Sports & Hobbies</option>
		<option>Fashion,Clothing & Beauty</option>
		<option>Spare Parts & Vehicle Accessories</option>
		<option>Other</option>
	</select>
	<select name="cc">
		<option value="" readonly>Please Select Cosmetic Score</option>
		<option value="0">0</option>
		<option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
	</select>
	<select name="wc">
		<option value="" readonly>Please Select Working Score</option>
		<option value="0">0</option>
		<option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
	</select>
	<select name="dc">
		<option value="" readonly>Please Select Diagnostic Score</option>
		<option value="0">0</option>
		<option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option><option value="5">5</option><option value="6">6</option><option value="7">7</option><option value="8">8</option><option value="9">9</option><option value="10">10</option>
	</select>
	<input type="submit" name="test" value="Test Now">
</form>
<?php
if(isset($_POST['test']))
{
	$a='';
	
	if($_POST['type']=='Fashion,Clothing & Beauty')
	{
//cosmetic condition for fashion
$final1=0;
$cc=7;
$total=10;
$ccp=$cc/$total;
$userinput_cc=$_POST['cc'];
$formula1=10-($userinput_cc*$ccp);
if($formula1==10)
{
	$ans=$formula1+=10;
	
}else{
		if($userinput_cc==0)
		{
		$ans=$formula1+10;
		}
		if($userinput_cc==1 || $userinput_cc==2)
		{
		$ans=$formula1+5;
		}
		if($userinput_cc>=3)
		{
		$ans=$formula1+0;
		}
}
$final1=$ccp*$ans;
echo "Score CC:".$final1;

//cosmetic condition for fashion

$wc=3;
$total=10;
$wcp=$wc/$total;
$userinput_wc=$_POST['wc'];
$formula1=10-($userinput_wc*$wcp);

if($formula1==10)
{
	$ans=$formula1+10;

}else{
		if($userinput_wc==0)
		{
		$ans=$formula1+10;
		
		}
		if($userinput_wc==1 || $userinput_wc==2)
		{
		$ans=$formula1+5;
		
		}
		if($userinput_wc>=3)
		{
		$ans=$formula1+0;
		
		}	
}
$final=$wcp*$ans;
echo "<br> 
Score WC:".$final;

$a=($final1+$final)*0.5;
echo "<br>Total Score:".$a;

}
		
	
	if($_POST['type']=='Other')
	{
//cosmetic condition for fashion
$final1=0;
$cc=5;
$total=10;
$ccp=$cc/$total;
$userinput_cc=$_POST['cc'];
$formula1=10-($userinput_cc*$ccp);
if($formula1==10)
{
	$ans=$formula1+=10;
	
}else{
		if($formula1==0)
		{
		$ans=$formula1+10;
		}
		if($formula1==1 || $formula1==2)
		{
		$ans=$formula1+5;
		}
		if($formula1>=3)
		{
		$ans=$formula1+0;
		}
}
$final1=$ccp*$ans;
echo "Score CC:".$final1;

//cosmetic condition for fashion

$wc=5;
$total=10;
$wcp=$wc/$total;
$userinput_wc=$_POST['wc'];
$formula1=10-($userinput_wc*$wcp);

if($formula1==10)
{
	$ans=$formula1+10;

}else{
		if($userinput_wc==0)
		{
		$ans=$formula1+10;
		
		}
		if($userinput_wc==1 || $userinput_wc==2)
		{
		$ans=$formula1+5;
		
		}
		if($userinput_wc>=3)
		{
		$ans=$formula1+0;
		
		}	
}
$final=$wcp*$ans;
echo "<br> 
Score WC:".$final;

$a=($final1+$final)*0.5;
echo "<br>Total Score:".$a;
}

	
	if($_POST['type']=='Books,Sports & Hobbies')
	{
//Books
$final1=0;
$cc=3;
$total=10;
$ccp=$cc/$total;
$userinput_cc=$_POST['cc'];
$formula1=10-($userinput_cc*$ccp);
if($formula1==10)
{
	$ans=$formula1+=10;
	
}else{
		if($formula1==0)
		{
		$ans=$formula1+10;
		}
		if($formula1==1 || $formula1==2)
		{
		$ans=$formula1+5;
		}
		if($formula1>=3)
		{
		$ans=$formula1+0;
		}
}
$final1=$ccp*$ans;
echo "Score CC:".$final1;

//working condition for books

$wc=7;
$total=10;
$wcp=$wc/$total;
$userinput_wc=$_POST['wc'];
$formula1=10-($userinput_wc*$wcp);

if($formula1==10)
{
	$ans=$formula1+10;

}else{
		if($userinput_wc==0)
		{
		$ans=$formula1+10;
		
		}
		if($userinput_wc==1 || $userinput_wc==2)
		{
		$ans=$formula1+5;
		
		}
		if($userinput_wc>=3)
		{
		$ans=$formula1+0;
		
		}	
}
$final=$wcp*$ans;
echo "<br> 
Score WC:".$final;

$a=($final1+$final)*0.5;
echo "<br>Total Score:".$a;
}



	if($_POST['type']=='Spare Parts & Vehicle Accessories')
	{
//Books
$final1=0;
$cc=3;
$total=10;
$ccp=$cc/$total;
$userinput_cc=$_POST['cc'];
$formula1=10-($userinput_cc*$ccp);
if($formula1==10)
{
	$ans=$formula1+=10;
	
}else{
		if($formula1==0)
		{
		$ans=$formula1+10;
		}
		if($formula1==1 || $formula1==2)
		{
		$ans=$formula1+5;
		}
		if($formula1>=3)
		{
		$ans=$formula1+0;
		}
}
$final1=$ccp*$ans;
echo "Score CC:".$final1;

//working condition for books

$wc=7;
$total=10;
$wcp=$wc/$total;
$userinput_wc=$_POST['wc'];
$formula1=10-($userinput_wc*$wcp);

if($formula1==10)
{
	$ans=$formula1+10;

}else{
		if($userinput_wc==0)
		{
		$ans=$formula1+10;
		
		}
		if($userinput_wc==1 || $userinput_wc==2)
		{
		$ans=$formula1+5;
		
		}
		if($userinput_wc>=3)
		{
		$ans=$formula1+0;
		
		}	
}
$final=$wcp*$ans;
echo "<br> 
Score WC:".$final;

$a=($final1+$final)*0.5;
echo "<br>Total Score:".$a;
}



	if($_POST['type']=='Electronic & Home Applicanes')
	{
//Books
$final1=0;
$cc=3;
$total=10;
$ccp=$cc/$total;
$userinput_cc=$_POST['cc'];
$formula1=10-($userinput_cc*$ccp);
if($formula1==10)
{
	$ans=$formula1+=10;
	
}else{
		if($formula1==0)
		{
		$ans=$formula1+10;
		}
		if($formula1==1 || $formula1==2)
		{
		$ans=$formula1+5;
		}
		if($formula1>=3)
		{
		$ans=$formula1+0;
		}
}
$final1=$ccp*$ans;
echo "Score CC:".$final1;

//working condition for books

$wc=7;
$total=10;
$wcp=$wc/$total;
$userinput_wc=$_POST['wc'];
$formula1=10-($userinput_wc*$wcp);

if($formula1==10)
{
	$ans=$formula1+10;

}else{
		if($userinput_wc==0)
		{
		$ans=$formula1+10;
		
		}
		if($userinput_wc==1 || $userinput_wc==2)
		{
		$ans=$formula1+5;
		
		}
		if($userinput_wc>=3)
		{
		$ans=$formula1+0;
		
		}	
}
$final=$wcp*$ans;
echo "<br> 
Score WC:".$final;

$a=($final1+$final)*0.5;
echo "<br>Total Score:".$a;
}


	if($_POST['type']=='Laptops & Computers' || $_POST['type']=='Mobile Device')
	{
//Mobiles
$final1=0;
$cc=3;
$total=10;
$ccp=$cc/$total;
$userinput_cc=$_POST['cc'];
$formula1=10-($userinput_cc*$ccp);
if($formula1==10)
{
	$ans=$formula1+=10;
	
}else{
		if($userinput_cc==0)
		{
		$ans=$formula1+10;
		}
		if($userinput_cc==1 || $userinput_cc==2)
		{
		$ans=$formula1+5;
		}
		if($userinput_cc>=3)
		{
		$ans=$formula1+0;
		}
}
$final1=$ccp*$ans;
echo "Score CC:".$final1;

//working condition for books

$wc=4;
$total=10;
$wcp=$wc/$total;
$userinput_wc=$_POST['wc'];
$formula1=10-($userinput_wc*$wcp);

if($formula1==10)
{
	$ans=$formula1+10;

}else{
		if($userinput_wc==0)
		{
		$ans=$formula1+10;
		
		}
		if($userinput_wc==1 || $userinput_wc==2)
		{
		$ans=$formula1+5;
		
		}
		if($userinput_wc>=3)
		{
		$ans=$formula1+0;
		
		}	
}
$final=$wcp*$ans;
echo "<br> 
Score WC:".$final;



//diagnotic condition for books

$dc=3;
$total=10;
$dcp=$dc/$total;
$userinput_dc=$_POST['dc'];
$formula3=10-($userinput_dc*$dcp);

if($formula3==10)
{
	$ans2=$formula3+10;

}else{
		if($userinput_dc==0)
		{
		$ans2=$formula3+10;
		
		}
		if($userinput_dc==1 || $userinput_dc==2)
		{
		$ans2=$formula3+5;
		
		}
		if($userinput_dc>=3)
		{
		$ans2=$formula3+0;
		
		}	
}
$final2=$dcp*$ans2;
echo "<br> 
Score DC:".$final2;

$a=($final1+$final+$final2)*0.5;
echo "<br>Total Score:".$a;
}



$penalty_somewhat=1;
$noscore=3;
$somewhat=1;
//No Adjusted Score
$no_adj_score=$a-(0*$noscore);
//Some What Score Adjustment
$final_adjusted_score=$no_adj_score-($somewhat*$penalty_somewhat);

echo "<br>Total:".$final_adjusted_score.'<br>Remarks:';

if($final_adjusted_score>=0 && $final_adjusted_score<=4.5)
{
	echo "POOR";
}elseif($final_adjusted_score>4.5 && $final_adjusted_score<=8.5)
{
	echo "Satisfactory";
}
elseif($final_adjusted_score>8.5 && $final_adjusted_score<=10)
{
	echo "Excellent";
}




}
?>