<?php
$server="localhost";
//$user="u989844087_utube";
//$password="u989844087_Utube";
$user="root";
$password="";
$dbname="checkmate";
$conn=new mysqli($server, $user, $password, $dbname);
if($conn->connect_error){
	die("Connection Failed: ".$conn->connect_error);
}
if(!$conn){
die("connection Failed:" .mysqli_connect_error());
}




?>