<?php
Session_Start();
Session_destroy();
header("location:../rider-login.php");
?>