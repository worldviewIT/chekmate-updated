<?php 
ob_start();
Session_Start();
if(!isset($_SESSION['admin']))
header("location:\logout.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Check Mate </title>
    <!-- Core CSS - Include with every page -->
    <link href="../assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="../assets/css/style.css" rel="stylesheet" />
    <link href="../assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="../assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
	<style>
#dept_anchor{
		text-decoration:none;
	}	
.alert-warning:hover{
    background-color:#354c48;
    color:white;
    opacity:0.9;
}
.outer{
    height:15px;
    width:100%;
    border:solid 1px black;
}
.inner{
background: rgb(63,76,107); /* Old browsers */
background: -moz-linear-gradient(top, rgba(63,76,107,1) 7%, rgba(63,76,107,1) 7%, rgba(96,108,136,1) 45%, rgba(63,76,107,1) 45%); /* FF3.6-15 */
background: -webkit-linear-gradient(top, rgba(63,76,107,1) 7%,rgba(63,76,107,1) 7%,rgba(96,108,136,1) 45%,rgba(63,76,107,1) 45%); /* Chrome10-25,Safari5.1-6 */
background: linear-gradient(to bottom, rgba(63,76,107,1) 7%,rgba(63,76,107,1) 7%,rgba(96,108,136,1) 45%,rgba(63,76,107,1) 45%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#3f4c6b', endColorstr='#3f4c6b',GradientType=0 ); /* IE6-9 */    
}
.bg-black{
	background:black;
}
.txt-black{
	color:black;
}
.txt-white{
	color:white;
}
	</style>
   </head>
<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
       <?php include "header.php" ?>
        <!-- end navbar top -->
    
        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
               
                   
                   <?php   
				   include "nav.php";
				   ?>
               
            <!-- end sidebar-collapse -->
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">
         
                <!--end quick info section -->
           <div class="row">
				<div class="panel-heading" align=center>
                        <h2 class="panel-titl "><b><i>Admin Dashboard</b></i></h2>
                    </div>
					
								<div class="col-lg-6 ">
                    <div class="text-center no-boder bg-black">
                        <div class="panel-body">
                            <i class="fa fa-user fa-3x txt-white"></i>
                            <h3 class="txt-white">
							<?php
							require "conn.php";
							$fUsercount=0;
							$fUser="Select * from user where type='User'";
							$fUserRes=$conn->query($fUser);
							while($frow=$fUserRes->fetch_assoc())
							{
								$fUsercount++;
							}
							
								echo $fUsercount;
							?> </h3>
                        </div>
                        <div class="panel-footer">
                            <span class="panel-eyecandy-title "><a href="customer.php" class="txt-black"><i><b>Total Customer</b></i></a>
                            </span>
                        </div>
                    </div>
					</div>
		
					
					
							<div class="col-lg-6 ">
                    <div class="text-center no-boder bg-black">
                        <div class="panel-body">
                            <i class="fa fa-bar-chart-o fa-3x txt-white"></i>
                            <h3 class="txt-white"><?php
							require "conn.php";
							$fUser="Select * from tasks";
							$fUserRes=$conn->query($fUser);
							$fUsercount=mysqli_num_rows($fUserRes);
								 $total=$fUsercount/100;
								echo $fUsercount;
							?> </h3>
                        </div>
                        <a href="summary.php">
                        <div class="panel-footer">
                            <span class="panel-eyecandy-title txt-black"><i> <b>Total Tasks</b></i>
                            </span>
                        </div>
                        </a>
                    </div>
					</div>
			
					
					
					
					
			   <div class="col-lg-6 pt-4">
                    <div class="text-center no-boder bg-black">
                        <div class="panel-body">
						<img src="../assets/img/rider.png" height="auto" width="50px">
							
                            <h3 class="txt-white">
								<?php
							require "conn.php";
							$fUser="Select * from user where type='rider'";
							$fUserRes=$conn->query($fUser);
							$fUsercount=mysqli_num_rows($fUserRes);
								 $total=$fUsercount/100;
								echo $fUsercount;
							?>
							</h3>
                        </div>
                        <a href="regrider.php">
                        <div class="panel-footer">
                            <span class="panel-eyecandy-title txt-black"> <i><b>Riders</b></i>
                            </span>
                        </div>
                        </a>
                    </div>
					</div> 
					
					
					<div class="col-lg-6 pt-4">
                    <div class="text-center no-boder bg-black">
                        <div class="panel-body">
						
						<img src="../assets/img/admin-1.png" height="auto" width="50px">
                            <h3 class="txt-white">
									<?php
								require "conn.php";
								$fUser="Select * from user where type='admin'";
								$fUserRes=$conn->query($fUser);
								$fUsercount=mysqli_num_rows($fUserRes);
									 $total=$fUsercount/100;
									echo $fUsercount;
								?>
							</h3>
                        </div>
                        <a href="reguser.php">
                        <div class="panel-footer">
                            <span class="panel-eyecandy-title txt-black"><i> <b>Admin Accounts</b></i>
                            </span>
                        </div>
                        </a>
                    </div>
					</div> 
				
		</div>
           

         

		</div>
        </div>
        <!-- end page-wrapper -->

    </div>
   <?php
   include "footer.php";
   ?>
    <!-- end wrapper -->
    <!-- Core Scripts - Include with every page -->
    <script src="../assets/plugins/jquery-1.10.2.js"></script>
    <script src="../assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../assets/plugins/pace/pace.js"></script>
    <script src="../assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="../assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="../assets/plugins/morris/morris.js"></script>
    <script src="../assets/scripts/dashboard-demo.js"></script>
</body>

</html>
