<?php 
ob_start();
Session_Start();
if(!isset($_SESSION['admin']))
header("location:\index.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php include "title.php" ?></title>
    <!-- Core CSS - Include with every page -->
    <link href="../assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="../assets/css/style.css" rel="stylesheet" />
    <link href="../assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="../assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
   </head>
<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <?php include "header.php" ?>
        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
                   
						
                   <?php   
				   include "nav.php";
				   ?>
               
            <!-- end sidebar-collapse -->
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                   <!-- <h1 class="page-header">Register New Users</h1>-->
                </div>
                <!--End Page Header -->
            </div>

           <!-- <div class="row">-->
                <!-- Welcome -->
              <!--  <div class="col-lg-12">
                    <div class="alert alert-info">
                        <i class="fa fa-folder-open"></i><b>&nbsp;Hello ! </b>Welcome Back <b>Jonny Deen </b>
 <i class="fa  fa-pencil"></i><b>&nbsp;2,000 </b>Support Tickets Pending to Answere. nbsp;
                    </div>
                </div>-->
                <!--end  Welcome -->
          <!--  </div>-->

                <!--quick info section -->
              <br>
              <br>
            <div class="row">
                <div class="col-lg-12">
                    <!-- Chat Panel Example-->
                    <div class="chat-panel panel bg-black">
                        <div class="panel-heading" align=center style="color:white;">
							<i class="fa fa-users" style="font-size:18px;"></i>
                         <b>  Manage Tasks</b>
              </div>
                      
                       

                    </div>
                    <!--End Chat Panel Example-->
                </div>
            </div>
                            <div class="row">
                           <div class="col-lg-12">
                                    <form action="" method="Post"  onSubmit="window.location.reload();">
                                        <div class="form-group">
                                        <label>Task#</label>
                                        <input type="number" name="id" placeholder="Task#" required>
                                     
                                        <button type="submit"  name="submit" class="btn btn-primary btn-sm">Search</button>
                                       
										</div>
										</form>
							</div>
									
							<div class="col-lg-6">
										
										<?php
										if(isset($_GET['s']))
										{
											echo '<div class="alert alert-success"><h4> Task Updated Successfully. </h4></div>';
										}
										if(isset($_GET['e']))
										{
											echo '<div class="alert alert-danger"><h4> Task Not Updated Try Again. </h4></div>';
										}
										if(isset($_GET['msg']))
										{
											echo '<div class="alert alert-info"><h4> ' . $_GET['msg'] . ' </h4></div>';
										}
										?>
										
										
										</div>
									</div>	
									 <div class="panel-body" style="overflow-x:scroll;">
									<?php	
								if(isset($_POST['update'])){
								
								//$depname=$_POST['depname'];
								$did=$_POST['id'];
								//$username=$_POST['email'];
								//$pass=$_POST['password'];
								//$mobile=$_POST['mobile'];
								//$address=$_POST['address'];
								include "conn.php";
								$we="Update tasks set seller_contact='".$_POST['seller_contact']."',seller_email='".$_POST['seller_email']."',status='".$_POST['status']."',task_condition='".$_POST['task_condition']."',task_health='".$_POST['task_health']."',product_type='".$_POST['type']."',product_name='".$_POST['product']."',address='".$_POST['addressx']."' where taskid='".$_POST['tid']."'";
								if($conn->query($we)){
									//$conn->query($we);
									header('location:?msg=Order Record Updated');
								}else{
										header('location:?msg= Try Again Later You cannot Update Order Record now!!!');
								}
									
								}
								?>
                            <div class="table table-responsive" >
                                <table class="table table-bordered" id="example" >
                                    <thead>
                                        <tr class="bg-black text-white">
                                            <th>#</th>
                                            <th>Customer Details</th>
                                            <th>Order Link </th>
                                            <th>Order Price</th>
                                            <th>Status</th>
                                            <th>Seller Listing Issue</th>
                                            <th>Listing Health</th>
                                            <th>Update</th>
										
											<th colspan=2>Remove</th>
                                        </tr>
                                    </thead>
                                    <tbody style="font-size:12px;">
                                        
									<?php
									require "conn.php";
									if(isset($_POST['submit']))
									{
										
									$viewmydep="Select * from tasks where taskid='".$_POST['id']."'";
									}else{
										
									$viewmydep="Select * from tasks order by taskid desc limit 10";
									}
									$depres=$conn->query($viewmydep);
									if($depres->num_rows>0){
									while($deprow=$depres->fetch_assoc()){
										
										$viewmy="Select * from user where type='User' and id='".$deprow['userid']."'";
										$res=$conn->query($viewmy);
										$urow=$res->fetch_assoc();
										
										echo'<tr class="success">
										<form action="" class="form-control" method="post" autocomplete="off">
										<td>'.$deprow['taskid'].'</td>
										<input type="hidden" name="tid" value="'.$deprow['taskid'].'" >
										<input type="hidden" name="id" value="'.$urow['id'].'" >
										<td>'.$urow['Name'].'<br>
										'.$urow['mobile'].'<br>'.$urow['email'].'<br>'.$urow['address'].'
										</td>
										<td><input type="text" name="link" value="'.$deprow['link'].'">
										</td>
										<td><input type="text" name="amt" value="'.$deprow['amt'].'">
										</td>
										<td>
										<select name="status" class="form-control">
										<option>'.$deprow['status'].'</option>
										<option>------------</option>
										<option>Processing</option>
										<option>Underverification</option>
										<option>Unfit To Ship</option>
										<option>Cancelled</option>
										<option>Accepted</option>
										</select>
										<select required name="type" class="form-control">';
											if($deprow['product_type']!='')
											echo '<option>'.$deprow['product_type'].'</option>';
											echo '<option value="">Choose Product Category</option>
											<option>Mobile Device</option>
											<option>Laptops & Computers</option>
											<option>Electronic & Home Applicanes</option>
											<option>Books,Sports & Hobbies</option>
											<option>Fashion,Clothing & Beauty</option>
											<option>Spare Parts & Vehicle Accessories</option>
											<option>Other</option>
										</select>
		<input type="text" class="" name="product" placeholder="Enter Product Model" value="'.$deprow['product_name'].'" required>
		<input type="text" class="" name="addressx" placeholder="Enter Seller Address" value="'.$deprow['address'].'" required>
		<input type="email"  name="seller_email" placeholder="Enter Seller Email" autocomplete="off" value="'.$deprow['seller_email'].'" required>
		<input type="text"  name="seller_contact" placeholder="Enter Seller Mobile" autocomplete="off" value="'.$deprow['seller_contact'].'" required>
				
										</td>
										<td>
											<textarea class="" name="task_condition">'.$deprow['task_condition'].'</textarea>
										</td>
										<td>
											<select name="task_health">';
												if($deprow['task_health']!='')
											echo '<option>'.$deprow['task_health'].'</option>';
												echo '<option value="">Select Listing Health</option>
												<option value="Pass">Pass</option>
												<option value="Fail">Fail</option>
											</select>
										</td>
										<td><input type="submit" class="btn-success md" name="update" value="Update Order">
										<br>
										<a href="https://api.whatsapp.com/send?phone=+92'.$urow['mobile'].'&text=Hi" class="btn btn-sm btn-warning" target="_blank" >Whatsapp Customer</a>
										</td>
										<td><input type="submit" class="btn-success md" name="del" value="Delete Order"></td>
										</form>
										</tr>';
									}	
									}
									?>
                                    </tbody>
                                </table>
								<?php
								if(isset($_POST['del']))
								{
								    $id=$_POST['tid'];
								$sql="Delete from tasks where taskid='$id'";
								if($conn->query($sql))
								{
									
								$sqli="Delete from report where taskid='$id'";
								$conn->query($sqli);
								   header('location:?msg=Order Deleted!');   
								}else{
								    header('location:?msg=Order Not Deleted!');
								}
								    
								}
								
								
								?>
                            </div>
							</div>
							</div>
							<!-- end page-wrapper -->

    </div>
    <?php
  //  include "footer.php";
    ?>
	<script>
function submit() {
  /*Put all the data posting code here*/
 document.getElementById("myForm").reset();
}
</script>
 
    <!-- end wrapper -->
    <!-- Core Scripts - Include with every page -->
    <script src="../assets/plugins/jquery-1.10.2.js"></script>
    <script src="../assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../assets/plugins/pace/pace.js"></script>
    <script src="../assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="../assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="../assets/plugins/morris/morris.js"></script>
    <script src="../assets/scripts/dashboard-demo.js"></script>
</body>

</html>
