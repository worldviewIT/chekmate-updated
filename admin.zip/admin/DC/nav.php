  <ul class="nav" id="side-menu">
  <li>
                        <!-- user image section-->
<?php
									if(isset($_SESSION['admin'])){
										$use=$_SESSION['admin'];
										$adid=$_SESSION['admin_id'];
										$n="Select * from user where id='$adid'";
										if($reslt=$conn->query($n)){
											$nrow=$reslt->fetch_assoc();
                       echo' <div class="user-section">
                            <div style="padding-left:70px;">
                                <img src="../assets/img/admin-1.png" height="90px" width="95px" style="border-radius:50%;border:2px groove white;" alt="your profile not loaded">
                            </div>
                            <div class="user-info">
                                <div>
											'.$nrow['Name']. '</div>';
												}
									}
									?>
                            </div>
                        </div>
                        <!--end user image section-->
                    </li>
                    <li class="sidebar-search">
                        <!-- search section-->
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search Dept...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <!--end search section-->
                    </li>
 <li>
                        <a href="home.php"><i class="fa fa-dashboard fa-fw"></i>Dashboard</a>
                    </li>
             
                   
                <!--    <li>
                        <a href="assign_task.php"><i class="fa fa-edit fa-fw"></i>Upload Links</a>
                    </li>
					<li>
                        <a href="pending-links.php"><i class="fa fa-edit fa-fw"></i>Approve Links</a>
                    </li>
					<li>
                        <a href="payment.php"><i class="fa fa-edit fa-fw"></i>Payments</a>
                    </li>
                     <li>
                        <a href="summary.php"><i class="fa fa-edit fa-fw"></i>Uploaded Links</a>
                        
                    </li>
					  <li>
                        <a href="assigntodepartment.php"><i class="fa fa-users fa-fw"></i>View Users</a>
                    </li>-->
						<li>
                        <a href="assign-task.php"><i class="fa fa-edit fa-fw"></i>Assign Tasks</a>
                        
                    </li>
					<li>
                        <a href="manage-task.php"><i class="fa fa-edit fa-fw"></i>Edit Tasks</a>
                        
                    </li>
                     <li>
                        <a href="summary.php"><i class="fa fa-edit fa-fw"></i>Tasks Summary</a>
                        
                    </li>
				
                     <li>
                        <a href="regrider.php"><i class="fa fa-users fa-fw"></i>Rider Management</a>
                    </li>
                     <li>
                        <a href="customer.php"><i class="fa fa-users fa-fw"></i>Customer Management</a>
                    </li>
					 <li>
                        <a href="reguser.php"><i class="fa fa-user fa-fw"></i> Admin Management</a>
                    </li>
                    <!--summary.php-->
                <!--  <li>
                        <a href="depsummary.php?departmentsummary&allsum"><i class="fa fa-edit fa-fw"></i>User Summary</a>
                        <!--depsummary.php?departmentsummary&allsum-->
                <!--    </li>-->
                            <li>
                                <a href="logout.php">Logout</a>
                            </li>
                        </ul>
                        <!-- second-level-items -->
                    </li>
                </ul>
				 <!-- end side-menu -->
            </div>