<?php 
ob_start();
Session_Start();
if(!isset($_SESSION['admin']))
header("location:\logout.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php include "title.php"?>Assign Task To Rider </title>
    <!-- Core CSS - Include with every page -->
    <link href="../assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="../assets/css/style.css" rel="stylesheet" />
    <link href="../assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="../assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
	<style>
#dept_anchor{
		text-decoration:none;
	}	
#dept:hover{
	opacity:0.8;
	color:black;
}
	</style>
	

   </head>
<body>
    <div id="wrapper">
    <!--  wrapper -->
       <?php include "header.php" ?>
    
        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
                   
                   <?php   
				   include "nav.php";
				   ?>
               
            <!-- end sidebar-collapse -->
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

          
                <!--quick info section -->
			
                <!--end quick info section -->
           <div class="row">
              
				<div class="panel-heading" align=center>
                        <h2 class="panel-titl" style="color:green;"><?php
                        if(isset($_GET['fback']))
						{
                         echo   $_GET['fback'];    
                        }        
                        ?>
						</h2>
                </div>
				            </div>
                       
                       
				<div class="panel-heading" align=center>
                        <h2 class="panel-titl">Asign Task To Rider</h2>
                    </div>
					
				  <form action="" method="post">
				  <?php
				  if(isset($_GET['user']))
				  {
					  echo "<h3 align=center class='alert-info'>Paymment Already Added <a href='?' class='btn btn-sm btn-primary'>ADD NEW PAYMENT</a></h3>";
				  }
				  ?>
				  <label>Select User:*</label>
				  <select name="user" class="form-control">
				  <?php
				  if(isset($_GET['user']))
				  {
					$sql="Select * from user where id='".$_GET['id']."' and type='Rider'";  
				  }else{
					$sql="Select * from user where type='Rider'";   
				  }
					$res=$conn->query($sql);
					if($res->num_rows>0)
					{
						while($row=$res->fetch_assoc())
						{
						echo '<option value="'.$row['id'].'">'.$row['id'].'-'.$row['mobile'].'-'.$row['Name'].'</option>';	
							
						}
					}
					?>
				  </select>	
				  <label>Task ID:*</label><br>
				  <input required type="text" name="taskid" class="form-control" placeholder="Please Enter Task ID" 
				  <?php
				  if(isset($_GET['taskid']))
				  {
					echo 'value="'.$_GET['taskid'].'"';  
				  }
					?>
						>
				  <label>Date:*</label><br>
				  <input required type="date" name="date" class="form-control" value="<?php echo date('Y-m-d');?>"  <?php
				  if(isset($_GET['user']))
				  {
					echo 'value="'.$_GET['date'].'"';  
				  }
					?>>
				  <label>Rider Instructions:</label><br>
				  <input  type="text" name="details" placeholder="Add Instruction For Rider" class="form-control"  <?php
				  if(isset($_GET['user']))
				  {
					echo 'value="'.$_GET['details'].'"';  
				  }
					?>><br>
					<?php
					if(isset($_GET['user']))
					{
						?>
				
							<input type="hidden" name="id" value="<?php echo $_GET['id'];?>">					
				  <input  type="submit" name="edit" value="Edit Task" class="btn btn-info">
						<?php
					}else{
						?>						
				  <input  type="submit" name="save" value="Assign To Rider" class="btn btn-info">
						<?php
					}
					?>
				  </form>
         
		 
			<?php
			if(isset($_POST['save']))
			{
				$taskid=$_POST['taskid'];
				$details=$_POST['details'];
				$date=$_POST['date'];
				$riderid=$_POST['user'];
				
				$sql="Select seller_contact,seller_email from tasks where taskid='".$_POST['taskid']."'
				and  `riderid` IS NULL";
				$res=$conn->query($sql);
				if($res->num_rows>0)
				{
					$rest=$res->fetch_assoc();
					$msisdn = "923432435000";
							$password = "thisisalongenoughpassword123!";

							$url = "https://telenorcsms.com.pk:27677/corporate_sms2/api/auth.jsp?msisdn=".$msisdn."&password=".$password;
							$xmlResponseString = file_get_contents($url);
							$xmlResponse = simplexml_load_string($xmlResponseString);
							$array=json_decode(json_encode((array)$xmlResponse),True);
							//$sessionID = $xmlResponse->corpsms->data;
							print_r($array['data']);
							
							$msg='A Chekmate Inspector will be at your doorstep today at the time confirmed with you earlier. If the product is "Fit to Ship" we will buy it from you immediately.';
							$mobile=$rest['seller_contact'];
							$url2 = "https://telenorcsms.com.pk:27677/corporate_sms2/api/sendsms.jsp?session_id=".$array['data']."&mask=CHEKMATE&to=".$mobile."&text=".urlencode($msg);
							$xmlResponseString2 = file_get_contents($url2);
							$xmlResponse2 = simplexml_load_string($xmlResponseString2);
					
						// use wordwrap() if lines are longer than 70 characters
							$msg='A Chekmate Inspector will be at your doorstep today at the time confirmed with you earlier. If the product is "Fit to Ship" we will buy it from you immediately.';
							$msg = wordwrap($msg,150);

							// send email
							$e=$rest['seller_email'];
							
								
							
					
	$to = $e; 
$from = 'chekmate@worldviewit.com'; 
$fromName = "Chekmate"; 
 
$subject = "Chekmate Notification"; 
 
			$htmlContent = ' 
    <!DOCTYPE html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
@media screen and (max-width: 786px) {
  .body {
    margin-left: 0px !important;
  }
  .img01 
  {
  width: 270px !important;
  height: 53px !important;
  }
  .img02
  {
  width: 270px !important;
  height: 53px !important;
  }
  .para
  {
  font-size: 11px !important;
  margin-left: 12px !important;
  }
  
}
</style>
</head>

<body class="body" style="width: 765px;margin-left: 235px;margin-top: 120px;"> 
<div style="margin: 50px;">
<a href="https://chekmate.worldviewit.com">
<img class="img01" src="https://www.worldviewit.com/chekmate/mail/Header.png" width="712" height="140px" alt="Chekmate Logo" style="display:block" title="Logo"> </a>
<p class="para" style="margin-top: 42px;margin-left: 35px;font-size: 14px;">
A Chekmate Inspector will be at your doorstep today at the time confirmed with you earlier. If the product is "Fit to Ship" we will buy it from you immediately. </p>
</div>
<footer>
<div style="margin: 50px;">
<img class="img02" src="https://www.worldviewit.com/chekmate/mail/Pattiwithtext.png" width="712" height="140px" alt="Chekmate Footer" style="display:block !important; width:712px; height:140px;" title="Email Footer">
</div>
</footer>
</body>
</html>'; 
			
	// Set content-type header for sending HTML email 
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
 // Additional headers 
$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 		
			
		// Send email 
if(mail($to, $subject, $htmlContent, $headers)){ 
   // echo 'Email has sent successfully.'; 
}else{ 
 //  echo 'Email sending failed.'; 
}
				
					//		mail($e,"ChekMate",$msg);
					
					
				$update="Update tasks set riderid='$riderid',assign_date='$date',details='$details' where taskid='$taskid'";
				if($conn->query($update))
				{					
					
					
					echo '<h3 align=center class="alert-info">Task Assigned Successfully!!!</h3>';
				}
				}else{
							echo '<h3 align=center class="alert-danger">Please Check Task ID. <br> Your Entered TASKID is Already Assigned or Incorrect!</h3>';
				
				}
			}
			?>
			  <div class="col-lg-12">
			  
                    <h1 class="page-header"><b><i>Assigned Task Summary</i></b></h1>
					
					<form action="" method="post" class="form-inline">
						<label class="h5"><b>Choose Date</b></label>
							<input type="date" name="sd" class="form-control" style="width:30%;" value="<?php echo date('Y-m-d');?>">
							<input type="date" name="ed" class="form-control" style="width:30%;" value="">
							<button type="submit" name="search" class="btn btn-info text-dark"><b>Generate Report </b></button>
					</form>
					<br>
<!--<button id="btnExport" onclick="exportReportToExcel(this)" class="btn btn-xs btn-info">EXPORT REPORT <i class="fa fa-print"></i></button>
-->
                </div>
		<div class="table table-responsive">
			<table class="table table-bordered">
				 <thead>
                                        <tr>
                                            <th>Task ID:</th>
                                            <th>Date</th>
                                            <th>Rider ID:</th>
                                            <th>Link</th>
                                            <th>User Mobile</th>
                                            <th>Email</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php
										include "conn.php";
											$subscribed=0;
											$subscriber=0;
							if(isset($_POST['sd']) && !empty($_POST['ed']))
							{
								$sd=strtotime($_POST['sd']);
								$sd=date('d-m-Y',$sd);
								$ed=strtotime($_POST['ed']);
								$ed=date('d-m-Y',$ed);
								
								$all="Select * from tasks where riderid='' taskdate between '$sd' and '$ed' order by taskdate asc";
							}else{
								$all="Select * from tasks where riderid!='' order by taskid desc";
							}

										if($res=$conn->query($all)){
										while($row=$res->fetch_assoc()){
										echo' <tr>
										<td> '.$row['taskid'].'</td>
										<td> ' . $row['taskdate'] . ' </td>
										<td> ' . $row['riderid'] . ' </td>
										<td> ' . $row['link'] . ' </td>
										<td> ' . $row['contact'] . ' </td>
										<td> ' . $row['email'] . ' </td>
										<td> ' . $row['amt'] . ' </td>
										<td> ' . $row['status'] . ' </td>';
										echo'</tr>';		
										}
										}
										
										?>
									  
                                    </tbody>
                                </table>

			</table>
		</div>
			
			
		 </div>
               
        <!-- end page-wrapper -->

    </div>
    <?php
    include "footer.php";
    ?>
    <!-- end wrapper -->
    <!-- Core Scripts - Include with every page -->
    <script src="../assets/plugins/jquery-1.10.2.js"></script>
    <script src="../assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../assets/plugins/pace/pace.js"></script>
    <script src="../assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="../assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="../assets/plugins/morris/morris.js"></script>
    <script src="../assets/scripts/dashboard-demo.js"></script>
  
</body>

</html>
