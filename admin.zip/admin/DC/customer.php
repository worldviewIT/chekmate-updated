<?php 
ob_start();
Session_Start();
if(!isset($_SESSION['admin']))
header("location:\index.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php include "title.php" ?></title>
    <!-- Core CSS - Include with every page -->
    <link href="../assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="../assets/css/style.css" rel="stylesheet" />
    <link href="../assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="../assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
   </head>
<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <?php include "header.php" ?>
        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
                   
						
                   <?php   
				   include "nav.php";
				   ?>
               
            <!-- end sidebar-collapse -->
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                   <!-- <h1 class="page-header">Register New Users</h1>-->
                </div>
                <!--End Page Header -->
            </div>

           <!-- <div class="row">-->
                <!-- Welcome -->
              <!--  <div class="col-lg-12">
                    <div class="alert alert-info">
                        <i class="fa fa-folder-open"></i><b>&nbsp;Hello ! </b>Welcome Back <b>Jonny Deen </b>
 <i class="fa  fa-pencil"></i><b>&nbsp;2,000 </b>Support Tickets Pending to Answere. nbsp;
                    </div>
                </div>-->
                <!--end  Welcome -->
          <!--  </div>-->

                <!--quick info section -->
              <br>
              <br>
            <div class="row">
                <div class="col-lg-12">
                    <!-- Chat Panel Example-->
                    <div class="chat-panel panel bg-black">
                        <div class="panel-heading" align=center style="color:white;">
							<i class="fa fa-users" style="font-size:18px;"></i>
                         <b>  Manage Customers</b>
              </div>
                      
                       

                    </div>
                    <!--End Chat Panel Example-->
                </div>
            </div>
                            <div class="row">
                           <div class="col-lg-6">
                                    <form action="" method="Post"  onSubmit="window.location.reload();">
                                        <div class="form-group">
                                        <label>Customer ID</label>
                                        <input type="number" name="id" placeholder="Enter Customer ID To Search" required>
                                     
                                        <button type="submit"  name="submit" class="btn btn-primary btn-sm">Find Customer</button>
                                       
										</div>
										</form>
										</div>
									
										<div class="col-lg-6">
										
										<?php
										if(isset($_GET['s']))
										{
											echo '<div class="alert alert-success"><h4> New Admin Account Created. </h4></div>';
										}
										if(isset($_GET['e']))
										{
											echo '<div class="alert alert-danger"><h4> New Admin Account Not Created Try Again. </h4>';
										}
										if(isset($_GET['msg']))
										{
											echo '<div class="alert alert-info"><h4> ' . $_GET['msg'] . ' </h4>';
										}
										?>
										
										</div>
										</div>
										
										
										<div class="row">
										<div class="col-lg-12">
										<div class="table-responsive" >
                                <table class="table" border=1>
                                    <thead>
                                        <tr class="bg-black text-white">
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Contact</th>
                                            <th>Email</th>
                                            <th>Password</th>
                                            <th>Arrears</th>
                                            <th>Address</th>
										
											<th colspan=4>Change</th>
                                        </tr>
                                    </thead>
                                    <tbody style="font-size:12px;">
                                        
									<?php
									require "conn.php";
									if(isset($_POST['submit']))
									{
										
									$viewmydep="Select * from user where type='User' and id='".$_POST['id']."'";
									}else{
										
									$viewmydep="Select * from user where type='User' order by id desc limit 10";
									}
									$depres=$conn->query($viewmydep);
									if($depres->num_rows>0){
									while($deprow=$depres->fetch_assoc()){
										echo'<tr class="success">
										<form action="" class="form-control" method="post" autocomplete="off">
										<td>'.$deprow['id'].'</td>
										<input type="hidden" name="id" value="'.$deprow['id'].'" >
										<td><input type="text" class="form-control" name="depname" value="'.$deprow['Name'].'" autocomplete="off"></td>
										<td><input type="text" class="form-control" name="mobile" value="'.$deprow['mobile'].'" autocomplete="off"></td>
										<td><input type="text" class="form-control" name="email" value="'.$deprow['email'].'" autocomplete="off"></td>
										<td><input type="text" class="form-control" name="password" value="'.$deprow['password'].'" autocomplete="off"></td>
										<td><input type="text" class="form-control" name="arrears" value="'.$deprow['arrears'].'" autocomplete="off"></td>
										<td><textarea type="text" class="form-control" name="address" autocomplete="off">'.$deprow['address'].'</textarea></td>
										<td>
										';
										if($deprow['account_hold']!="yes")
										{
										echo'<td><input type="submit" class="btn-success md" name="account_hold" value="Account Hold"></td>
										';
										}else{
										echo'<td><input type="submit" class="btn-success md" name="account_unhold" value="Account Unhold"></td>
										';
										}
										echo '
										</td>
										<td><input type="submit" class="btn-success md" name="update" value="Update"></td>
											<td><input type="submit" class="btn-danger md" name="del" value="Delete"></td>
										</form>
										</tr>';
									}	
									}
									?>
                                    </tbody>
                                </table>
								<?php
								if(isset($_POST['del']))
								{
								    $id=$_POST['id'];
								$sql="Delete from user where id='$id'";
								if($conn->query($sql))
								{
								    header('location:?msg=Customer Account Deleted!');   
								}else{
								    header('location:?msg=Customer Account Not Deleted!');
								}
								    
								}
								if(isset($_POST['account_hold']))
								{
								    $id=$_POST['id'];
								$sql="Update user set account_hold='yes' where id='$id'";
								if($conn->query($sql))
								{
								    header('location:?msg=Customer Account On Hold');   
								}else{
								    header('location:?msg=Customer Account Not On Hold Try Again');
								}
								    
								}
								if(isset($_POST['account_unhold']))
								{
								    $id=$_POST['id'];
								$sql="Update user set account_hold='' where id='$id'";
								if($conn->query($sql))
								{
								    header('location:?msg=Customer Account UnHold');   
								}else{
								    header('location:?msg=Customer Account Not UnHold Try Again');
								}
								    
								}
								
								
								if(isset($_POST['update'])){
								
								$depname=$_POST['depname'];
								$did=$_POST['id'];
								$username=$_POST['email'];
								$pass=$_POST['password'];
								$mobile=$_POST['mobile'];
								$address=$_POST['address'];
								$arrears=$_POST['arrears'];
								include "conn.php";
								$update="Update user set Name='$depname',email='$username',password='$pass',arrears='$arrears',mobile='$mobile',address='$address' where id='$did'";
								if($conn->query($update)){
									header('location:customer.php?msg=Customer Record Updated');
								}else{
										header('location:customer.php?msg= Try Again Later You cannot Update Customer Record now!!!');
								}
									
								}
								?>
                            </div>
							</div>
							</div>
							<!-- end page-wrapper -->

    </div>
    <?php
  //  include "footer.php";
    ?>
	<script>
function submit() {
  /*Put all the data posting code here*/
 document.getElementById("myForm").reset();
}
</script>
 
    <!-- end wrapper -->
    <!-- Core Scripts - Include with every page -->
    <script src="../assets/plugins/jquery-1.10.2.js"></script>
    <script src="../assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../assets/plugins/pace/pace.js"></script>
    <script src="../assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="../assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="../assets/plugins/morris/morris.js"></script>
    <script src="../assets/scripts/dashboard-demo.js"></script>
</body>

</html>
