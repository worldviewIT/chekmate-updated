<?php 
ob_start();
Session_Start();
if(!isset($_SESSION['admin']))
header("location:\logout.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php include "title.php";?></title>
    <!-- Core CSS - Include with every page -->
    <link href="../assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="../assets/css/style.css" rel="stylesheet" />
    <link href="../assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="../assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
	
  <script src="https://cdn.jsdelivr.net/gh/linways/table-to-excel@v1.0.4/dist/tableToExcel.js"></script>
   </head>
<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
             <?php include "header.php" ?>
        <!-- end navbar top -->
    
        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
                  
                   <?php   
				   include "nav.php";
				   ?>
               
            <!-- end sidebar-collapse -->
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header"><b><i>New Task Summary</i></b></h1>
					
					<form action="" method="post" class="form-inline">
						<label class="h5"><b>Choose Date</b></label>
							<input type="date" name="sd" class="form-control" style="width:30%;" value="<?php echo date('Y-m-d');?>">
							<input type="date" name="ed" class="form-control" style="width:30%;" value="">
							<button type="submit" name="search" class="btn btn-info text-dark"><b>Generate Report </b></button>
					</form>
					<br>
<button id="btnExport" onclick="exportReportToExcel(this)" class="btn btn-xs btn-info">EXPORT REPORT <i class="fa fa-print"></i></button>

                </div>
                <!--End Page Header -->
            </div>

      
					   <div class="panel-body" style="overflow-x:scroll;">
				<?php
					include "conn.php";
									
				if(isset($_POST['edit']))
				{
					$asd="Select taskid,seller_contact,seller_email from tasks where taskid='".$_POST['id']."'";
					$rest=$conn->query($asd);
					if($rest->num_rows>0)
					{
						$rowt=$rest->fetch_assoc();
						if($rowt['seller_email']!=$_POST['seller_email'])
						{
							
							// use wordwrap() if lines are longer than 70 characters
							$msg="Greeting From Chekmate. Someone is interested in your product listing. We'll be in touch with you for details shortly.";
							$msg = wordwrap($msg,150);

							// send email
							$e=$_POST['seller_email'];
							
							
							
					
	$to = $e; 
$from = 'chekmate@worldviewit.com'; 
$fromName = "Chekmate"; 
 
$subject = "Chekmate Notification"; 
 
			$htmlContent = ' 
    <!DOCTYPE html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
@media screen and (max-width: 786px) {
  .body {
    margin-left: 0px !important;
  }
  .img01 
  {
  width: 270px !important;
  height: 53px !important;
  }
  .img02
  {
  width: 270px !important;
  height: 53px !important;
  }
  .para
  {
  font-size: 11px !important;
  margin-left: 12px !important;
  }
  
}
</style>
</head>

<body class="body" style="width: 765px;margin-left: 235px;margin-top: 120px;"> 
<div style="margin: 50px;">
<a href="https://chekmate.worldviewit.com">
<img class="img01" src="https://www.worldviewit.com/chekmate/mail/Header.png" width="712" height="140px" alt="Chekmate Logo" style="display:block" title="Logo"> </a>
<p class="para" style="margin-top: 42px;margin-left: 35px;font-size: 14px;">
 Greetings From Chekmate. Someone is interested in your product listing. We will be in touch with you for details shortly. </p>
</div>
<footer>
<div style="margin: 50px;">
<img class="img02" src="https://www.worldviewit.com/chekmate/mail/Pattiwithtext.png" width="712" height="140px" alt="Chekmate Footer" style="display:block !important; width:712px; height:140px;" title="Email Footer">
</div>
</footer>
</body>
</html>'; 
			
	// Set content-type header for sending HTML email 
$headers = "MIME-Version: 1.0" . "\r\n"; 
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
 // Additional headers 
$headers .= 'From: '.$fromName.'<'.$from.'>' . "\r\n"; 		
			
		// Send email 
if(mail($to, $subject, $htmlContent, $headers)){ 
   // echo 'Email has sent successfully.'; 
}else{ 
 //  echo 'Email sending failed.'; 
}
	
	//	mail($e,"ChekMate",$msg);
							
							
							
							
				
						}
						if($rowt['seller_contact']!=$_POST['seller_contact'])
						{
							//SMS OTP
							$msisdn = "923432435000";
							$password = "thisisalongenoughpassword123!";

							$url = "https://telenorcsms.com.pk:27677/corporate_sms2/api/auth.jsp?msisdn=".$msisdn."&password=".$password;
							$xmlResponseString = file_get_contents($url);
							$xmlResponse = simplexml_load_string($xmlResponseString);
							$array=json_decode(json_encode((array)$xmlResponse),True);
							//$sessionID = $xmlResponse->corpsms->data;
							print_r($array['data']);
							
							$msg="Greetings From Chekmate. Someone is interested in your product listing. We'll be in touch with you for details shortly.";
							 $mobile=$_POST['seller_contact'];
							$url2 = "https://telenorcsms.com.pk:27677/corporate_sms2/api/sendsms.jsp?session_id=".$array['data']."&mask=CHEKMATE&to=".$mobile."&text=".urlencode($msg);
							$xmlResponseString2 = file_get_contents($url2);
							$xmlResponse2 = simplexml_load_string($xmlResponseString2);

						}
				$sa="Update tasks set seller_email='".$_POST['seller_email']."',
				 seller_contact='".$_POST['seller_contact']."',task_condition='".$_POST['task_condition']."',task_health='".$_POST['task_health']."',details='".$_POST['details']."',product_type='".$_POST['type']."',
				product_name='".$_POST['product']."',address='".$_POST['address']."' where taskid='".$_POST['id']."'";
				$conn->query($sa);
					}
				}
				?>
                            <div class="table table-responsive" >
                                <table class="table table-bordered" id="example" >
                                    <thead>
                                        <tr>
                                            <th>Order ID:</th>
                                            <th>Order Date</th>
                                            <th>Customer Details</th>
                                            <th>Order Link</th>
                                            <th>Order Price</th>
                                            <th>Order Status</th>
                                            <th style="width:40px;">Customer Address</th>
                                         <!--   <th>Task Details</th>-->
                                            <th>Task Category</th>
                                            <th>Seller Listing Issues</th>
                                            <th>Listing Health</th>
                                            <th>Controls</th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php
											$subscribed=0;
											$subscriber=0;
							if(isset($_POST['sd']) && !empty($_POST['ed']))
							{
								$sd=strtotime($_POST['sd']);
								$sd=date('d-m-Y',$sd);
								$ed=strtotime($_POST['ed']);
								$ed=date('d-m-Y',$ed);
								
								$all="Select * from tasks where riderid is Null and taskdate between '$sd' and '$ed'";
							}else{
								$all="Select * from tasks where riderid='' or riderid is NULL and status='Processing' order by taskid desc";
							}

										if($res=$conn->query($all)){
										while($row=$res->fetch_assoc()){
											$sq="Select * from user where id='".$row['userid']."'";
											$ref=$conn->query($sq);
											$urow=$ref->fetch_assoc();
											$count='';
											$ft="SELECT COUNT(userid) as t FROM tasks WHERE userid='".$row['userid']."'";
											$rt=$conn->query($ft);
											if($rt->num_rows>0)
											{
											$count=$rt->fetch_assoc();
											$count=$count['t'];
											}
										echo
										' <form action="" method="post" autocomplete="off"><tr>
										<td><input type="text" name="id" value="'.$row['taskid'].'" readonly style="width:40px;border:0px;background:transparent;"></td>
										<td> ' . $row['taskdate'] . ' </td>
										
										<td> ' . $urow['id'] . ':' . $urow['Name'] . '<br>';
											while($count>0)
											{
												echo "<span style='font-size:15px;font-weight:800;'>*</span>";
												$count--;
											}
										
										echo  '<br>'. $row['contact'] . ' <br> ' . $row['email'] . ' 
										</td>
										<td> 
										' . $row['link'] . ' </td>
								
										<td> ' . $row['amt'] . ' </td>
										<td> ' . $row['status'] . ' </td>
										<td> ';
										if($urow['address']=='')
										 echo "<span style='color:red;font-weight:bold;'>Customer Address Missing.Please Enter Customer Address.
<a href='customer.php' class='btn btn-sm btn-danger'>Manage Customer Details</a></span>";
										else
											echo $urow['address'];
										echo' </td>
			<!--	<td> <textarea name="details" hidden class="">' . $row['details'] . ' </textarea></td>-->
			<input type="hidden" name="details" value="'.$row['details'].'">
										<td>
										<select required name="type" >';
											if($row['product_type']!='')
											echo '<option>'.$row['product_type'].'</option>';
											echo '<option value="">Choose Product Category</option>
											<option>Mobile Device</option>
											<option>Laptops & Computers</option>
											<option>Electronic & Home Applicanes</option>
											<option>Books,Sports & Hobbies</option>
											<option>Fashion,Clothing & Beauty</option>
											<option>Spare Parts & Vehicle Accessories</option>
											<option>Other</option>
										</select>
		<input type="text" class="" name="product" placeholder="Enter Product Model" value="'.$row['product_name'].'" required>
		<input type="text" class="" name="address" placeholder="Enter Seller Address" value="'.$row['address'].'" required>
		<input type="email"  name="seller_email" placeholder="Enter Seller Email" autocomplete="off" value="'.$row['seller_email'].'" required>
		<input type="text"  name="seller_contact" placeholder="Enter Seller Mobile" autocomplete="off" value="'.$row['seller_contact'].'" required>
										</td>
											<td>
											<textarea class="" name="task_condition">'.$row['task_condition'].'</textarea>
										</td>
										<td>
											<select name="task_health">';
												if($row['task_health']!='')
											echo '<option>'.$row['task_health'].'</option>';
												echo '<option value="">Select Listing Health</option>
												<option value="Pass">Pass</option>
												<option value="Fail">Fail</option>
											</select>
										</td>
										
										<td><br><input type="submit" class="btn btn-info" name="edit" value="Update">';
										echo'</tr></form>';		
										}
										}
										
										?>
									  
                                    </tbody>
                                </table>
                            </div>
                 
                        </div>
                    </div>


		</div>
        </div>
        <!-- end page-wrapper -->

    <?php
    include "footer.php";
    ?>
    <!-- end wrapper -->
    <!-- Core Scripts - Include with every page -->
    <script src="../assets/plugins/jquery-1.10.2.js"></script>
    <script src="../assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../assets/plugins/pace/pace.js"></script>
    <script src="../assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="../assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="../assets/plugins/morris/morris.js"></script>
    <script src="../assets/scripts/dashboard-demo.js"></script>
 <script>
function exportReportToExcel() {
  let table = document.getElementsByTagName("table"); // you can use document.getElementById('tableId') as well by providing id to the table tag
  TableToExcel.convert(table[0], { // html code may contain multiple tables so here we are refering to 1st table tag
    name: `Task Sheet.xlsx`, // fileName you could use any name
    sheet: {
      name: 'Order Sheet' // sheetName
    }
  });
}
</script>
</body>

</html>
