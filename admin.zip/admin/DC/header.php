 <nav class="navbar navbar-default navbar-fixed-top" role="navigation" id="navbar">
            <!-- navbar-header -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
             <a class="navbar-brand" href="index.php" style="color:white;">
				
                   <img src="../assets/img/logo.png" alt="ChekMate"/>
                </a>
            </div>
            <!-- end navbar-header -->
            <!-- navbar-top-links -->
            <ul class="nav navbar-top-links navbar-right">
               
             <!--   <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <span class="top-label label label-danger">
						<?php
								require "conn.php";
								$pendingtask="Select * from tasks where Status='2'";
								$penres=$conn->query($pendingtask);
								$total=mysqli_num_rows($penres);
								echo $total;
						?>
						</span><i class="fa fa-check fa-3x"></i>
                    </a>
                  
                    <ul class="dropdown-menu dropdown-messages">
                      
								<?php
							
										echo' 
											<li style="background-color:#04B173;">
											<a href="">
											<div>
											<strong><span class=" label label-danger">--</span></strong>
											<span class="pull-right text-muted">
											<em>--</em>
											</span>
											</div>
											<div>--</div>
											</a>
											</li>';
								?>
                                  
                    </ul>
                   
                </li>

                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <span class="top-label label label-success">
					
						</span>  <i class="fa fa-clock-o fa-3x"></i>
                    </a>
                   
                     <ul class="dropdown-menu dropdown-messages">
                      
								<?php
							
										echo' 
											<li style="background-color:yellow;">
											<a href="#">
											<div>
											<strong><span class=" label label-danger">--</span></strong>
											<span class="pull-right text-muted">
											<em>--</em>
											</span>
											</div>
											<div>-- </div>
											</a>
											</li>';
								?>
                                  
                                  
                                  
                    </ul>
                  
                </li>
                
                 <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <span class="top-label label label-success">
					
						</span>  <i class="fa fa-envelope fa-3x"></i>
                    </a>
                  
                     <ul class="dropdown-menu dropdown-messages">
                      
								<?php
						
										echo ' 
											<li style="background-color:#04B173;">
											<a href="">
											<div>
											<strong><span class="label label-danger">--</span></strong>
											<span class="pull-right text-muted">
											<em>--</em>
											</span>
											</div>
											<div>--</div>
											</a>
											</li>';
								
								echo "<a align=center href='viewallmsg.php?all'>View All Message</a>";
								?>
                                  
                                  
                                  
                    </ul>
                  
                </li>-->

                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-3x"></i>
                    </a>
                    <!-- dropdown user-->
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="profile.php"><i class="fa fa-user fa-fw"></i>User Profile</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i>Logout</a>
                        </li>
                    </ul>
                    <!-- end dropdown-user -->
                </li>
                <!-- end main dropdown -->
            </ul>
            
			
			<!-- end navbar-top-links -->

        </nav>