<?php 
ob_start();
Session_Start();
if(!isset($_SESSION['admin']))
header("location:\logout.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php include "title.php";?></title>
    <!-- Core CSS - Include with every page -->
    <link href="../assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="../assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="../assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="../assets/css/style.css" rel="stylesheet" />
    <link href="../assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="../assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
   </head>
<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
             <?php include "header.php" ?>
        <!-- end navbar top -->
    
        <!-- navbar side -->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
                  
                   <?php   
				   include "nav.php";
				   ?>
               
            <!-- end sidebar-collapse -->
        </nav>
        <!-- end navbar side -->
        <!--  page-wrapper -->
        <div id="page-wrapper">

            <div class="row">
                <!-- Page Header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Recently Watched Links</h1>
					<a href="reject-links.php" class="btn btn-sm  btn-info">REJECTED LINKS</a>
					<a href="accepted-link.php" class="btn btn-sm  btn-info">ACCEPTED LINKS</a>
                 <!--   <a class="alert-warning btn btn-warning" href="export.php?task">Export Table</a>-->
                </div>
                <!--End Page Header -->
            </div>

              
            <div class="row">
               
            </div>
					   <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-hover table-striped">
                                    <thead>
                                        <tr>
                                            <th>Link ID:</th>
                                            <th>Watched Date</th>
                                            <th>Video ID:</th>
                                            <th>UserName</th>
                                            <th>Point</th>
											<th>Picture </th>
                                        </tr>
                                    </thead>
                                    <tbody>
										<?php
										if(isset($_POST['confirm']))
										{
											$dp="Update taskdone set status='confirm',`des`='".$_POST['des']."' where tdid='".$_POST['id']."'";
											$conn->query($dp)
											?>
											<script>alert('Points Confirmed!!');</script>
											<?php
										}
										if(isset($_POST['reject']))
										{
											$dp="Update taskdone set status='reject',`des`='".$_POST['des']."' where tdid='".$_POST['id']."'";
											$conn->query($dp)
											?>
											<script>alert('Points Rejected!!');</script>
											<?php
										}
										include "conn.php";
											$subscribed=0;
											$subscriber=0;

										$all="Select * from taskdone where status='pending'";
										if($res=$conn->query($all)){
										while($row=$res->fetch_assoc()){
											$sq="Select * from department where Did='".$row['userid']."'";
											$re=$conn->query($sq);
											$ro=$re->fetch_assoc();
										echo' <tr><td> '.$row['tid'].'</td>
										<td> ' . $row['datetime'] . ' </td>
										<td> ' . $row['link'] . ' </td>
										<td> ' . $ro['Depname']. ' </td>
										<td> ' . $row['points'].' </td>
										<td> <img src="../assets/files/'.$row['file'].'" height="50px" width="auto"><br>
											<a href="../assets/files/'.$row['file'].'" class="btn-xs btn-danger" target="_blank">View Full Image</a>
										</td>
										<td>
										<form action="" method="post">
										<input type="text" name="des" placeholder="Enter Details If" class="form-control"><br>
											<input type="hidden" name="id" value="'.$row['tdid'].'">
											<button name="confirm" type="submit" class="btn-xs btn-success ">Confirm </button> &nbsp &nbsp &nbsp
											<button name="reject" type="submit" class="btn-xs btn-danger "> Reject </button> 
										</form>
										</td>
										';
										echo'</tr>';		
										}
										
										}
										
										?>
									  
                                    </tbody>
                                </table>
                            </div>
                 
                        </div>
                    </div>


		</div>
        </div>
        <!-- end page-wrapper -->

    </div>
    <?php
    include "footer.php";
    ?>
    <!-- end wrapper -->
    <!-- Core Scripts - Include with every page -->
    <script src="../assets/plugins/jquery-1.10.2.js"></script>
    <script src="../assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="../assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="../assets/plugins/pace/pace.js"></script>
    <script src="../assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="../assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="../assets/plugins/morris/morris.js"></script>
    <script src="../assets/scripts/dashboard-demo.js"></script>
    <script>
Morris.Bar({
 element : 'chart',
 data:[<?php echo $chart_data; ?>],
 xkey:'Year',
 ykeys:['Seen', 'NotSeen', 'Completed', 'Confirmed'],
 labels:['Seen', 'NotSeen', 'Completed', 'Confirmed'],
 hideHover:'auto',
 
});
</script>
</body>

</html>
