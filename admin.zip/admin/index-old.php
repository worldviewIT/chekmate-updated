<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php include "title.php"; ?></title>
    <!-- Core CSS - Include with every page -->
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
   <link href="assets/css/style.css" rel="stylesheet" />
      <link href="assets/css/main-style.css" rel="stylesheet" />
</head>

<body>
<div class="body-Login-back">
<img src="assets/img/bg.jpg" height=100% width=100% />
</div>
    <div class="container">
        
        <div class="row" id="formf">
            
            <div class="col-md-10 col-md-offset-5 text-center logo-margin" style="text-shadow: 2px 2px white;color:#000;font-weight:800px;">
            <span><h1 style="font-weight:bold;"> Checkmate Admin Login</h1></span>
            </div>
               
            <div class="col-md-8 col-md-offset-6 text-center">
                <div class="login-panel panel panel-default" style="height:0px;">                  
                    
                    <div class="panel-body">
                        <form action="" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control"  placeholder="Login ID" name="email" type="text" autofocus required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" required>
                                </div>
								<div class="form-group">
                                    <input class="form-control btn-success" value="Login" name="log" type="submit" >
                                </div>
                            
                                <!-- Change this to a button or input when using this as a form -->
                            
                                <p style="color:black;"><a href="rider-login.php" style="color:black;font-size:18px;font-weight:bold;text-shadow:1px 1px white;color:#000;"> <u>Rider Login</u></a></p>    
                              </fieldset>
                        </form>
						<?php
						if(isset($_POST['log'])){
							include"conn.php";
						$u=$_POST['email'];
						$p=$_POST['password'];
						$mysql="Select * from user where email='$u' and password='$p' and type='admin'";
						if($res=$conn->query($mysql)){
							Session_Start();
							$row=$res->fetch_assoc();
							
							$_SESSION['admin']=$row['Name'];
							$_SESSION['admin_id']=$row['id'];
							header('location:DC/home.php');
							}else{
									echo"<p style='color:black;' align=center>You are Not Able to login</p>";
							}
							
						
						}
						?>
                    </div>
                </div>
            </div>
        </div>
        <amp-auto-ads type="adsense"
              data-ad-client="ca-pub-9558982913422036">
</amp-auto-ads>
    </div>

     <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>

</body>

</html>
