<?php
ob_start();
session_start();
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php include "title.php"; ?> Enter OTP CODE</title>
    <!-- Core CSS - Include with every page -->
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
   <link href="assets/css/style.css" rel="stylesheet" />
      <link href="assets/css/main-style.css" rel="stylesheet" />

</head>

<body>
<div class="body-Login-back">
<img src="assets/img/bg.jpg" height=100% width=100% />
</div>
    <div class="container">
        
        <div class="row" id="formf">
            
            <div class="col-md-10 col-md-offset-5 text-center logo-margin" style="text-shadow: 2px 2px black;color:#5cb85c;">
            <span><h1> MF SOURCE </h1></span>
            <h3>ONLINE WORK</h3>
                </div>
               
            <div class="col-md-8 col-md-offset-6 text-center">
                <div class="login-panel panel panel-default" style="height:0px;">                  
                    <div class="panel-heading">
                         <br>
                        <h3 class="panel-title"><b><a href="index.php">User Sign In</a></b></h3>
                    </div>
                    <div class="panel-body">
                        <form action="" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" readonly  placeholder="" value="<?php echo $_SESSION['user-email']; ?>" name="email" type="text" autofocus required>
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Enter OTP Received in Your Email" name="otp" type="text" required>
                                </div>
                               
								<div class="form-group">
                                    <input class="form-control btn-success" value="Login" name="log" type="submit" >
                                </div>
                            
                                <!-- Change this to a button or input when using this as a form -->
                               
                                <p style="color:black;" align=center>&nbsp &nbsp Copyright<a href="#" style="color:black;font-size:16px;"> <u>Mf-Source</u> </a>. &nbsp &nbsp &nbsp</p> 
                                </fieldset>
                        </form>
						<?php
						if(isset($_POST['log'])){
							include"conn.php";
						$u=$_POST['email'];
						$mysql="Select * from department where Username='$u' and otp IS NOT NULL";
						$res=$conn->query($mysql);
						if($res->num_rows>0){
							$sql="Select * from department where otp='".$_POST['otp']."'";
							$r=$conn->query($sql);
							if($r->num_rows>0)
							{
								$ores=$r->fetch_assoc();
								$active="Update department set otp='NULL' where Did='".$ores['Did']."'";
								$conn->query($active);
									$_SESSION['user']=$row['Did'];
							header('location:index.php');
							}else{
								echo '<h3 class="alert alert-info">Otp DoesNot Matched</h3>';
							}
							
							
						}else{
								echo '<h3 class="alert alert-info">Please Signup First <a href="signup.php">Signup Now</a></h3>';
						}
						}
						?>
                    </div>
                </div>
            </div>
        </div>
        <amp-auto-ads type="adsense"
              data-ad-client="ca-pub-9558982913422036">
</amp-auto-ads>
    </div>

     <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>

</body>

</html>
